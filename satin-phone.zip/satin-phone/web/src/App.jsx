import { useEffect, useState } from 'react';
import { get, post, onUnauthorized } from './api.js';
import { store, useStore } from './store.js';
import { startPhone, stopPhone } from './phone.js';
import { startLive, stopLive, refreshStats } from './live.js';
import { unlockAudio } from './sounds.js';
import { IPhone, IVoicemail, IUser, IMic, IFlow, IUsers, ISliders, IGrid, ILogout } from './icons.jsx';
import { IncomingCard, CallBar, CallScreen, useIsMobile } from './components/Call.jsx';
import { StatusButton } from './components/Header.jsx';
import CallsPage from './pages/Calls.jsx';
import KeypadPage from './pages/Keypad.jsx';
import VoicemailPage from './pages/Voicemail.jsx';
import CustomersPage from './pages/Customers.jsx';
import FlowPage from './pages/Flow.jsx';
import TeamPage from './pages/Team.jsx';
import SettingsPage, { logout } from './pages/Settings.jsx';

const useHash = () => {
  const [h, setH] = useState(location.hash || '#/calls');
  useEffect(() => {
    const on = () => setH(location.hash || '#/calls');
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return h.replace(/^#\/?/, '') || 'calls';
};

export default function App() {
  const me = useStore((s) => s.me);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    get('/api/me').then((m) => store.set({ me: m })).catch(() => {}).finally(() => setChecked(true));
    return onUnauthorized(() => store.set({ me: null }));
  }, []);

  useEffect(() => {
    if (!me?.sip) return undefined;
    startPhone(me.sip);
    startLive();
    refreshStats();
    return () => { stopPhone(); stopLive(); };
  }, [me?.sip?.username]);

  if (!checked) return null;
  if (!me) return <Login />;
  return <Shell />;
}

function Login() {
  const [f, setF] = useState({ username: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    unlockAudio();
    setBusy(true); setErr('');
    try {
      await post('/api/auth/login', f);
      store.set({ me: await get('/api/me') });
      if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().catch(() => {});
    } catch (ex) {
      setErr(ex.message);
    } finally { setBusy(false); }
  };
  return (
    <div className="login">
      <form className="card" onSubmit={submit}>
        <div className="brand" style={{ padding: 0 }}>
          <div className="brand-mark">S</div>
          <div><div className="brand-name">Satin Phone</div><div className="brand-sub">Satin Auto Wrap</div></div>
        </div>
        <h1>Sign in</h1>
        <label className="field">Username<input autoFocus autoComplete="username" value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} /></label>
        <label className="field">Password<input type="password" autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></label>
        {err && <div className="notice red">{err}</div>}
        <button type="submit" className="btn primary block" disabled={busy || !f.username || !f.password}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </div>
  );
}

const NAV = [
  { id: 'calls', label: 'Calls', icon: IPhone },
  { id: 'voicemail', label: 'Voicemail', icon: IVoicemail, badge: 'vm' },
  { id: 'customers', label: 'Customers', icon: IUser },
  { id: 'recordings', label: 'Recordings', icon: IMic },
  { id: 'flow', label: 'Call flow & hours', icon: IFlow },
  { id: 'team', label: 'Team & devices', icon: IUsers, admin: true },
  { id: 'settings', label: 'Settings', icon: ISliders },
];
const TABS = [
  { id: 'calls', label: 'Calls', icon: IPhone },
  { id: 'keypad', label: 'Keypad', icon: IGrid },
  { id: 'voicemail', label: 'Voicemail', icon: IVoicemail, badge: 'vm' },
  { id: 'customers', label: 'Customers', icon: IUser },
  { id: 'more', label: 'More', icon: ISliders },
];

function Shell() {
  const me = useStore((s) => s.me);
  const stats = useStore((s) => s.stats);
  const presence = useStore((s) => s.presence);
  const phone = useStore((s) => s.phone);
  const call = useStore((s) => s.call);
  const incoming = useStore((s) => s.incoming);
  const route = useHash();
  const mobile = useIsMobile();
  const isAdmin = me.user.role === 'admin';
  const vm = stats?.newVoicemails || 0;
  const onlineDevices = Object.values(presence.devices || {}).filter(Boolean).length;

  useEffect(() => {
    document.title = incoming ? 'Incoming call · Satin Phone' : call ? 'On a call · Satin Phone' : vm ? `(${vm}) Satin Phone` : 'Satin Phone';
  }, [incoming, call, vm]);

  const doLogout = async () => { await stopPhone(); stopLive(); await logout(); location.hash = '#/calls'; };

  let page;
  switch (route) {
    case 'voicemail': page = <VoicemailPage />; break;
    case 'customers': page = <CustomersPage />; break;
    case 'recordings': page = <CallsPage preset="recorded" title="Recordings" />; break;
    case 'flow': page = <FlowPage />; break;
    case 'team': page = <TeamPage />; break;
    case 'settings': page = <SettingsPage onLogout={doLogout} />; break;
    case 'keypad': page = <KeypadPage />; break;
    case 'more': page = <MorePage isAdmin={isAdmin} onLogout={doLogout} />; break;
    default: page = <CallsPage />;
  }

  const lineOk = presence.trunk === 'registered';
  return (
    <div className="app">
      <nav className="sidebar" aria-label="Main menu">
        <div className="brand">
          <div className="brand-mark">S</div>
          <div><div className="brand-name">Satin Phone</div><div className="brand-sub">{me.company}</div></div>
        </div>
        <div className="line-card">
          <span className="eyebrow">Main line</span>
          <span className="line-number">{me.mainNumberFormatted}</span>
          <span className="status-line">
            <span className={`dot ${lineOk ? '' : 'warn'}`} />
            {lineOk ? `Online · ${onlineDevices} device${onlineDevices === 1 ? '' : 's'}` : presence.asterisk ? 'Line not connected' : 'Connecting…'}
          </span>
        </div>
        <div className="nav">
          {NAV.filter((n) => !n.admin || isAdmin).map((n) => (
            <a key={n.id} href={`#/${n.id}`} className={route === n.id ? 'active' : ''} aria-current={route === n.id ? 'page' : undefined}>
              <n.icon size={18} /><span className="grow">{n.label}</span>
              {n.badge === 'vm' && vm > 0 && <span className="badge">{vm}</span>}
            </a>
          ))}
        </div>
        <div className="me-card">
          <span className="avatar dark">{me.user.name.slice(0, 1).toUpperCase()}</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>{me.user.name}</div>
            <div className="status-line" style={{ fontSize: 12 }}>
              <span className={`dot ${phone.status === 'registered' ? (me.user.status === 'dnd' ? 'red' : '') : 'warn'}`} />
              {phone.status !== 'registered' ? 'Connecting…' : me.user.status === 'dnd' ? 'Do not disturb' : 'Available'}
            </div>
          </div>
        </div>
      </nav>

      <main className="main">
        {!mobile && call && route !== 'calls' && <CallBar />}
        {page}
      </main>

      <nav className="tabbar" aria-label="Tabs">
        {TABS.map((t) => (
          <a key={t.id} href={`#/${t.id}`} className={route === t.id || (t.id === 'more' && ['flow', 'team', 'settings', 'recordings'].includes(route)) ? 'active' : ''}>
            <t.icon size={24} />{t.label}
            {t.badge === 'vm' && vm > 0 && <span className="badge">{vm}</span>}
          </a>
        ))}
      </nav>

      {mobile ? <CallScreen /> : <IncomingCard />}
      <Toasts />
    </div>
  );
}

function MorePage({ isAdmin, onLogout }) {
  const items = [
    { id: 'recordings', label: 'Recordings', icon: IMic },
    { id: 'flow', label: 'Call flow & hours', icon: IFlow },
    ...(isAdmin ? [{ id: 'team', label: 'Team & devices', icon: IUsers }] : []),
    { id: 'settings', label: 'Settings', icon: ISliders },
  ];
  return (
    <>
      <div className="page-head">
        <div><span className="eyebrow">Satin Phone</span><h1>More</h1></div>
        <StatusButton />
      </div>
      <section className="card list">
        <div className="nav">
          {items.map((i) => <a key={i.id} href={`#/${i.id}`}><i.icon size={20} /><span className="grow">{i.label}</span></a>)}
          <a href="#/calls" onClick={(e) => { e.preventDefault(); onLogout(); }}><ILogout size={20} /><span className="grow">Sign out</span></a>
        </div>
      </section>
    </>
  );
}

function Toasts() {
  const toasts = useStore((s) => s.toasts);
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => <div key={t.id} className={`toast ${t.kind === 'error' ? 'error' : ''}`}>{t.text}</div>)}
    </div>
  );
}
