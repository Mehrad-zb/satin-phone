// Live updates from the server (new calls, voicemails, who's online) over a WebSocket.
import { store } from './store.js';
import { get } from './api.js';

let ws = null;
let stopped = false;
let delay = 1000;

async function refreshStats() {
  try { store.set({ stats: await get('/api/stats') }); } catch { /* ignore */ }
}

function onMessage({ type, data }) {
  switch (type) {
    case 'hello':
      store.set({ presence: data.presence, liveCalls: data.calls });
      break;
    case 'presence':
      store.set({ presence: data });
      break;
    case 'call.started':
      store.set((s) => ({ liveCalls: [...s.liveCalls.filter((c) => c.id !== data.id), data], version: s.version + 1 }));
      break;
    case 'call.updated':
      store.set((s) => ({ liveCalls: s.liveCalls.map((c) => (c.id === data.id ? data : c)), version: s.version + 1 }));
      break;
    case 'call.ended':
      store.set((s) => ({ liveCalls: s.liveCalls.filter((c) => c.id !== data.id), version: s.version + 1 }));
      refreshStats();
      break;
    case 'call.transcript':
      store.set((s) => ({ version: s.version + 1 }));
      break;
    case 'voicemail.new':
    case 'voicemail.updated':
    case 'voicemail.deleted':
      store.set((s) => ({ vmVersion: s.vmVersion + 1 }));
      refreshStats();
      break;
    case 'settings.changed':
      store.set((s) => (s.me ? { me: { ...s.me, business: data.business } } : {}));
      break;
    default:
  }
}

export function startLive() {
  stopped = false;
  const url = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/api/live`;
  ws = new WebSocket(url);
  ws.onopen = () => { delay = 1000; refreshStats(); };
  ws.onmessage = (ev) => { try { onMessage(JSON.parse(ev.data)); } catch { /* ignore */ } };
  ws.onclose = () => {
    ws = null;
    if (!stopped) setTimeout(startLive, delay);
    delay = Math.min(delay * 2, 15000);
  };
}

export function stopLive() {
  stopped = true;
  ws?.close();
}

export { refreshStats };
