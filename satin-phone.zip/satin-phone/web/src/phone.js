// The softphone: registers this browser with Asterisk over WebRTC (SIP.js) and handles calls.
import { Web, SessionState } from 'sip.js';
import { store, toast } from './store.js';
import { startRinging, stopRinging, keyTone } from './sounds.js';
import { fmtPhone } from './format.js';

let sm = null;
let cfg = null;
let remoteAudio = null;

const REJECT_TEXT = {
  403: 'That number is blocked (premium or international).',
  404: 'That number doesn’t exist.',
  408: 'No answer.',
  480: 'No answer.',
  484: 'The number is incomplete.',
  486: 'The line is busy.',
  487: '',
  503: 'The call couldn’t go through. Try again in a moment.',
  603: 'The call was declined.',
};

const setPhone = (patch) => store.set((s) => ({ phone: { ...s.phone, ...patch } }));
const setCall = (patch) => store.set((s) => (s.call ? { call: { ...s.call, ...patch } } : {}));

function partyOf(session) {
  const id = session.remoteIdentity;
  const number = id?.uri?.user || '';
  const name = id?.displayName && id.displayName !== number ? id.displayName : '';
  return { number, name };
}

function notify(title, body) {
  try {
    if (document.visibilityState === 'visible' || !('Notification' in window) || Notification.permission !== 'granted') return null;
    const n = new Notification(title, { body, tag: 'satin-call', renotify: true, requireInteraction: true });
    n.onclick = () => { window.focus(); n.close(); };
    return n;
  } catch { return null; }
}

export function phoneReady() { return !!sm && store.get().phone.status === 'registered'; }

export async function startPhone(sipCfg) {
  if (sm) return;
  cfg = sipCfg;
  remoteAudio = document.getElementById('remote-audio');
  if (!remoteAudio) {
    remoteAudio = document.createElement('audio');
    remoteAudio.id = 'remote-audio';
    remoteAudio.autoplay = true;
    document.body.appendChild(remoteAudio);
  }
  sm = new Web.SessionManager(cfg.wsUrl, {
    aor: `sip:${cfg.username}@${cfg.domain}`,
    userAgentOptions: {
      authorizationUsername: cfg.username,
      authorizationPassword: cfg.password,
      displayName: cfg.displayName,
      logLevel: 'error',
      transportOptions: { server: cfg.wsUrl, keepAliveInterval: 25 },
      sessionDescriptionHandlerFactoryOptions: {
        peerConnectionConfiguration: { iceServers: cfg.iceServers || [], iceTransportPolicy: cfg.iceTransportPolicy || 'all' },
        iceGatheringTimeout: cfg.iceTransportPolicy === 'relay' ? 3000 : 1500,
      },
    },
    media: { constraints: { audio: true, video: false }, remote: { audio: remoteAudio } },
    maxSimultaneousSessions: 2,
    reconnectionAttempts: 1e6,
    reconnectionDelay: 4,
    registrationRetry: true,
    registrationRetryInterval: 5,
    registererOptions: { expires: 300 },
    sendDTMFUsingSessionDescriptionHandler: true,
    delegate: {
      onServerConnect: () => setPhone({ status: 'connecting', error: '' }),
      onServerDisconnect: (err) => setPhone({ status: 'offline', error: err ? 'Lost connection to the phone server. Reconnecting…' : '' }),
      onRegistered: () => setPhone({ status: 'registered', error: '' }),
      onUnregistered: () => setPhone({ status: 'connecting' }),
      onCallReceived: onIncoming,
      onCallAnswered: (session) => {
        const s = store.get();
        if (s.incoming?.session === session) {
          store.set({ call: { ...s.incoming, state: 'active', answeredAt: Date.now() }, incoming: null });
        } else if (s.call?.session === session) {
          setCall({ state: 'active', answeredAt: Date.now() });
        }
      },
      onCallHangup: (session) => {
        const s = store.get();
        if (s.incoming?.session === session) {
          stopRinging();
          s.incoming.notification?.close();
          store.set({ incoming: null });
        }
        if (s.call?.session === session) {
          if (s.call.endReason) toast(s.call.endReason);
          store.set({ call: null });
        }
      },
      onCallHold: (session, held) => {
        if (store.get().call?.session === session) setCall({ held });
      },
    },
  });
  // For troubleshooting from the browser console: satinPhone().managedSessions …
  window.satinPhone = () => sm;
  setPhone({ status: 'connecting', error: '' });
  try {
    await sm.connect();
    await sm.register();
  } catch (e) {
    setPhone({ status: 'offline', error: 'Can’t reach the phone server. Retrying…' });
  }
}

export async function stopPhone() {
  if (!sm) return;
  const m = sm;
  sm = null;
  try { await m.unregister(); } catch { /* ignore */ }
  try { await m.disconnect(); } catch { /* ignore */ }
  setPhone({ status: 'idle' });
}

function onIncoming(session) {
  const s = store.get();
  // Already on a call (or another one ringing): say "busy" so the team's other devices keep ringing.
  if (s.call || s.incoming) {
    session.reject({ statusCode: 486 }).catch(() => {});
    return;
  }
  const { number, name } = partyOf(session);
  const label = name || fmtPhone(number) || 'Unknown caller';
  const incoming = { id: session.id, session, direction: 'in', number, name, state: 'ringing', startedAt: Date.now(), muted: false, held: false };
  incoming.notification = notify(`Incoming call · ${label}`, 'Satin Auto Wrap line');
  store.set({ incoming });
  startRinging();
  session.stateChange.addListener((state) => {
    if (state !== SessionState.Initial) stopRinging();
  });
}

export async function answer() {
  const inc = store.get().incoming;
  if (!inc) return;
  stopRinging();
  inc.notification?.close();
  try {
    await sm.answer(inc.session);
  } catch (e) {
    store.set({ incoming: null });
    toast(/Permission|NotAllowed/i.test(String(e)) ? 'Allow microphone access in your browser to answer calls.' : 'Couldn’t answer the call.', 'error', 6000);
  }
}

export async function decline() {
  const inc = store.get().incoming;
  if (!inc) return;
  stopRinging();
  inc.notification?.close();
  store.set({ incoming: null });
  try { await inc.session.reject({ statusCode: 486 }); } catch { /* already gone */ }
}

export async function dial(raw) {
  let target = String(raw || '').replace(/[^0-9*#+]/g, '');
  if (!target) return;
  if (!sm || store.get().phone.status !== 'registered') {
    toast('The phone isn’t connected yet. Wait a moment and try again.', 'error');
    return;
  }
  if (store.get().call) { toast('Finish the current call first.'); return; }
  if (/^\d{11}$/.test(target) && target.startsWith('1')) target = target.slice(1);
  const meta = { id: `out-${Date.now()}`, session: null, direction: 'out', number: target, name: '', state: 'connecting', startedAt: Date.now(), muted: false, held: false };
  store.set({ call: meta });
  try {
    const inviter = await sm.call(`sip:${target}@${cfg.domain}`, {}, {
      requestDelegate: {
        onProgress: () => setCall({ state: 'ringing' }),
        onReject: (res) => setCall({ endReason: REJECT_TEXT[res.message.statusCode] ?? `The call ended (${res.message.reasonPhrase}).` }),
      },
    });
    if (store.get().call?.id === meta.id) setCall({ session: inviter });
    inviter.stateChange.addListener((st) => {
      if (st === SessionState.Terminated && store.get().call?.session === inviter) {
        const reason = store.get().call.endReason;
        store.set({ call: null });
        if (reason) toast(reason);
      }
    });
  } catch (e) {
    store.set({ call: null });
    toast(/Permission|NotAllowed/i.test(String(e)) ? 'Allow microphone access in your browser to make calls.' : 'Couldn’t start the call.', 'error', 6000);
  }
}

export async function hangup() {
  const c = store.get().call;
  if (!c) return;
  if (!c.session) { store.set({ call: null }); return; }
  try { await sm.hangup(c.session); } catch { store.set({ call: null }); }
}

export function toggleMute() {
  const c = store.get().call;
  if (!c?.session) return;
  if (c.muted) sm.unmute(c.session); else sm.mute(c.session);
  setCall({ muted: !c.muted });
}

export async function toggleHold() {
  const c = store.get().call;
  if (!c?.session || c.state !== 'active') return;
  try {
    if (c.held) await sm.unhold(c.session); else await sm.hold(c.session);
    setCall({ held: !c.held });
  } catch {
    toast('Couldn’t change hold. Try again.', 'error');
  }
}

export function sendDigit(d) {
  const c = store.get().call;
  keyTone(d);
  if (!c?.session || c.state !== 'active') return;
  sm.sendDTMF(c.session, d).catch(() => {});
}

export async function transfer(target) {
  const c = store.get().call;
  const t = String(target || '').replace(/[^0-9*#+]/g, '');
  if (!c?.session || !t) return;
  try {
    await sm.transfer(c.session, `sip:${t}@${cfg.domain}`);
    toast(`Transferred to ${t === '100' ? 'everyone' : t.length >= 7 ? fmtPhone(t) : `extension ${t}`}`);
    // Blind transfer: once the server accepts it, our side of the call ends.
    setTimeout(() => {
      if (store.get().call?.session === c.session) sm.hangup(c.session).catch(() => store.set({ call: null }));
    }, 600);
  } catch {
    toast('The transfer didn’t work.', 'error');
  }
}
