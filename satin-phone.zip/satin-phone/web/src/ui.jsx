// Small shared UI pieces.
import { useEffect, useMemo, useRef, useState } from 'react';
import { IPlay, IPause, IIn, IOut, IX, IVoicemail, IUser, ICopy, ICheck } from './icons.jsx';
import { dur, initials } from './format.js';
import { toast } from './store.js';

export function Switch({ checked, onChange, label, disabled }) {
  return (
    <button type="button" role="switch" aria-checked={!!checked} aria-label={label} className="switch" disabled={disabled}
      onClick={() => onChange(!checked)}>
      <span className="track"><span className="knob" /></span>
    </button>
  );
}

export function Avatar({ name, size = '', dark = false }) {
  const ini = initials(name);
  if (!ini) return <span className={`avatar unknown ${size}`}><IUser size={size === 'xl' ? 34 : size === 'lg' ? 24 : 18} /></span>;
  return <span className={`avatar ${size} ${dark ? 'dark' : ''}`}>{ini}</span>;
}

export function Segmented({ options, value, onChange, label }) {
  return (
    <div className="segmented" role="group" aria-label={label}>
      {options.map((o) => (
        <button key={o.value} type="button" aria-pressed={value === o.value} onClick={() => onChange(o.value)}>
          {o.label}{o.count !== undefined && <span className="count">{o.count}</span>}
        </button>
      ))}
    </div>
  );
}

export function Modal({ title, children, onClose, footer }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal" role="dialog" aria-modal="true" aria-label={title}>
        <div className="card-head">
          <h2>{title}</h2>
          <button type="button" className="icon-btn" aria-label="Close" onClick={onClose}><IX /></button>
        </div>
        {children}
        {footer && <div className="foot">{footer}</div>}
      </div>
    </div>
  );
}

export function KindIcon({ kind, size = 15 }) {
  if (kind === 'out') return <IOut size={size} />;
  if (kind === 'missed') return <IX size={size} />;
  if (kind === 'vm') return <IVoicemail size={size} sw={2} />;
  return <IIn size={size} />;
}

const hash = (s) => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };

/** Play/pause with a simple waveform-style progress bar (click to seek). */
export function AudioPlayer({ src, label, length, seed }) {
  const ref = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const [total, setTotal] = useState(length || 0);
  const bars = useMemo(() => {
    let h = hash(seed || src);
    return Array.from({ length: 36 }, () => { h = (h * 1103515245 + 12345) >>> 0; return 6 + (h % 22); });
  }, [seed, src]);

  useEffect(() => {
    setPlaying(false); setPos(0);
    const a = ref.current;
    if (a) { a.pause(); a.load(); }
  }, [src]);

  const toggle = () => {
    const a = ref.current;
    if (!a) return;
    if (a.paused) a.play().catch(() => toast('Couldn’t play this audio.', 'error'));
    else a.pause();
  };
  const seek = (e) => {
    const a = ref.current;
    if (!a || !total) return;
    const r = e.currentTarget.getBoundingClientRect();
    a.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * total;
  };
  const frac = total ? pos / total : 0;
  return (
    <div className="player">
      <audio ref={ref} src={src} preload="metadata"
        onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => { setPlaying(false); setPos(0); }}
        onTimeUpdate={(e) => setPos(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => { if (Number.isFinite(e.currentTarget.duration)) setTotal(e.currentTarget.duration); }} />
      <button type="button" className="play" aria-label={`${playing ? 'Pause' : 'Play'} ${label}`} onClick={toggle}>
        {playing ? <IPause size={16} /> : <IPlay size={16} />}
      </button>
      <div className="track">
        <span className="eyebrow">{label}</span>
        <div className="bar" onClick={seek} role="presentation">
          {bars.map((h, i) => <span key={i} className={i / bars.length < frac ? 'on' : ''} style={{ height: h }} />)}
        </div>
      </div>
      <span className="len tabular">{playing || pos ? dur(pos) : dur(total)}</span>
    </div>
  );
}

export function CopyButton({ text, label = 'Copy' }) {
  const [done, setDone] = useState(false);
  return (
    <button type="button" className="icon-btn" aria-label={label} title={label}
      onClick={async () => {
        try { await navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 1500); }
        catch { toast('Copy didn’t work — select the text instead.'); }
      }}>
      {done ? <ICheck /> : <ICopy />}
    </button>
  );
}

export function Empty({ children }) {
  return <div className="empty">{children}</div>;
}
