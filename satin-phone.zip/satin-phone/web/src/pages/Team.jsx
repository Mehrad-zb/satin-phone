import { useEffect, useState } from 'react';
import { get, post, patch, del } from '../api.js';
import { toast, useStore } from '../store.js';
import { Avatar, Modal, Switch, CopyButton } from '../ui.jsx';
import { IMonitor, IMobile, IPlus, IEdit, ITrash } from '../icons.jsx';

export default function TeamPage() {
  const me = useStore((s) => s.me);
  const presence = useStore((s) => s.presence);
  const [team, setTeam] = useState(null);
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState(null);
  const [creds, setCreds] = useState(null);

  const load = () => get('/api/team').then(setTeam).catch((e) => toast(e.message, 'error'));
  useEffect(() => { load(); }, [presence]);

  if (me?.user?.role !== 'admin') return <div className="card"><div className="empty">Only admins can manage the team.</div></div>;
  if (!team) return <div className="empty">Loading…</div>;

  const act = async (fn, msg) => { try { setTeam(await fn()); if (msg) toast(msg); } catch (e) { toast(e.message, 'error'); } };
  const addDevice = async (u, kind) => {
    try {
      const t = await post(`/api/team/users/${u.id}/devices`, { kind, label: kind === 'desk' ? 'Desk phone' : 'Phone (Groundwire)' });
      setTeam(t);
      const nu = t.users.find((x) => x.id === u.id);
      setCreds({ user: nu, device: nu.devices[nu.devices.length - 1] });
    } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <>
      <div className="page-head">
        <div>
          <span className="eyebrow">Phone system</span>
          <h1>Team &amp; devices</h1>
          <p>Everyone here can answer the shop line. Each person can have the app plus phones or desk phones.</p>
        </div>
        <button type="button" className="btn primary" onClick={() => setAdding(true)}><IPlus size={16} /> Add a person</button>
      </div>

      <section className="card" style={{ maxWidth: 900, gap: 0 }}>
        {team.users.map((u) => (
          <div key={u.id} className="person">
            <div className="row">
              <Avatar name={u.name} />
              <div className="grow">
                <strong>{u.name}</strong>{!u.active && <span className="pill" style={{ marginLeft: 8 }}>Turned off</span>}
                <div className="row-sub">@{u.username} · extension {u.ext} · {u.role === 'admin' ? 'Admin' : 'Team member'}{u.status === 'dnd' ? ' · do not disturb' : ''}</div>
              </div>
              <button type="button" className="btn sm" onClick={() => setEditing(u)}><IEdit size={14} /> Edit</button>
            </div>
            {u.devices.map((d) => (
              <div key={d.id} className="device">
                {d.kind === 'web' ? <IMonitor size={18} /> : <IMobile size={18} />}
                <span className="grow">{d.label}<div className="row-sub">{d.online ? 'Online now' : 'Offline'} · {d.sipUser}</div></span>
                <span className={`dot ${d.online ? '' : 'off'}`} />
                {d.kind !== 'web' && <button type="button" className="btn sm" onClick={() => setCreds({ user: u, device: d })}>Setup</button>}
                <Switch checked={d.ring} label={`Ring ${d.label}`} onChange={(v) => act(() => patch(`/api/team/devices/${d.id}`, { ring: v }))} />
              </div>
            ))}
            <div className="device" style={{ gap: 8 }}>
              <button type="button" className="btn dashed sm" onClick={() => addDevice(u, 'mobile')}><IPlus size={14} /> Add a phone</button>
              <button type="button" className="btn dashed sm" onClick={() => addDevice(u, 'desk')}><IPlus size={14} /> Add a desk phone</button>
            </div>
          </div>
        ))}
      </section>

      {adding && <AddPerson onClose={() => setAdding(false)} onDone={(t) => { setTeam(t); setAdding(false); }} />}
      {editing && <EditPerson user={editing} self={editing.id === me.user.id} onClose={() => setEditing(null)} onDone={(t) => { setTeam(t); setEditing(null); }} />}
      {creds && <DeviceSetup creds={creds} server={team.sipServer} onClose={() => setCreds(null)}
        onChange={(t) => { setTeam(t); const nu = t.users.find((x) => x.id === creds.user.id); const nd = nu?.devices.find((x) => x.id === creds.device.id); if (nd) setCreds({ user: nu, device: nd }); else setCreds(null); }} />}
    </>
  );
}

function AddPerson({ onClose, onDone }) {
  const [f, setF] = useState({ name: '', username: '', password: '', role: 'staff' });
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try { onDone(await post('/api/team/users', f)); toast(`${f.name} can now sign in and answer calls`); } catch (e) { toast(e.message, 'error'); } finally { setBusy(false); }
  };
  return (
    <Modal title="Add a person" onClose={onClose} footer={<><button type="button" className="btn" onClick={onClose}>Cancel</button>
      <button type="button" className="btn primary" disabled={busy || !f.name || !f.username || f.password.length < 8} onClick={save}>Add</button></>}>
      <label className="field">Name<input autoFocus value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="e.g. Front desk" /></label>
      <label className="field">Username<input value={f.username} onChange={(e) => setF({ ...f, username: e.target.value.toLowerCase().replace(/[^a-z0-9._-]/g, '') })} placeholder="e.g. desk" /></label>
      <label className="field">Password <small>(8+ characters — they can change it later)</small><input type="text" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></label>
      <label className="field">Role
        <select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>
          <option value="staff">Team member — answers and makes calls</option>
          <option value="admin">Admin — also changes hours, greetings and the team</option>
        </select>
      </label>
    </Modal>
  );
}

function EditPerson({ user, self, onClose, onDone }) {
  const [f, setF] = useState({ name: user.name, role: user.role, active: user.active, password: '' });
  const save = async () => {
    const body = { name: f.name, role: f.role, active: f.active };
    if (f.password) body.password = f.password;
    try { onDone(await patch(`/api/team/users/${user.id}`, body)); toast('Saved'); } catch (e) { toast(e.message, 'error'); }
  };
  const remove = async () => {
    if (!window.confirm(`Delete ${user.name}? Their call history stays.`)) return;
    try { onDone(await del(`/api/team/users/${user.id}`)); } catch (e) { toast(e.message, 'error'); }
  };
  return (
    <Modal title={`Edit ${user.name}`} onClose={onClose} footer={<>
      {!self && <button type="button" className="btn" style={{ marginRight: 'auto', color: 'var(--red)' }} onClick={remove}><ITrash size={16} /> Delete</button>}
      <button type="button" className="btn" onClick={onClose}>Cancel</button>
      <button type="button" className="btn primary" disabled={!f.name || (f.password && f.password.length < 8)} onClick={save}>Save</button></>}>
      <label className="field">Name<input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
      <label className="field">Role
        <select value={f.role} disabled={self} onChange={(e) => setF({ ...f, role: e.target.value })}>
          <option value="staff">Team member</option><option value="admin">Admin</option>
        </select>
      </label>
      <label className="field">New password <small>(leave empty to keep the current one)</small><input type="text" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></label>
      {!self && <div className="row"><span className="grow">Account turned on</span><Switch checked={f.active} label="Account on" onChange={(v) => setF({ ...f, active: v })} /></div>}
    </Modal>
  );
}

function DeviceSetup({ creds, server, onClose, onChange }) {
  const { device: d, user: u } = creds;
  const reset = async () => {
    if (!window.confirm('Make a new password? The phone stops working until you enter the new one.')) return;
    try { onChange(await patch(`/api/team/devices/${d.id}`, { resetPassword: true })); toast('New password made'); } catch (e) { toast(e.message, 'error'); }
  };
  const remove = async () => {
    if (!window.confirm(`Remove ${d.label}?`)) return;
    try { onChange(await del(`/api/team/devices/${d.id}`)); } catch (e) { toast(e.message, 'error'); }
  };
  const rows = [
    ['Username', d.sipUser],
    ['Password', d.password],
    ['Domain', server.domain],
    ['Transport', server.tls ? `TLS · port ${server.tlsPort}` : `UDP · port ${server.udpPort}`],
  ];
  return (
    <Modal title={`${d.label} · ${u.name}`} onClose={onClose} footer={<>
      <button type="button" className="btn" style={{ marginRight: 'auto', color: 'var(--red)' }} onClick={remove}><ITrash size={16} /> Remove</button>
      <button type="button" className="btn" onClick={reset}>New password</button>
      <button type="button" className="btn primary" onClick={onClose}>Done</button></>}>
      <p style={{ margin: 0, color: 'var(--soft)', lineHeight: 1.55 }}>
        {d.kind === 'desk'
          ? 'Enter these in the desk phone’s SIP account settings.'
          : 'On the iPhone or Android phone, install Groundwire (it rings even when the phone is locked), choose “Add account → Generic SIP account” and enter:'}
      </p>
      <div className="creds">
        {rows.map(([k, v]) => (
          <div key={k} style={{ display: 'contents' }}>
            <span>{k}</span><code>{v}</code><CopyButton text={String(v)} label={`Copy ${k}`} />
          </div>
        ))}
      </div>
      <p style={{ margin: 0, color: 'var(--muted)', fontSize: 13, lineHeight: 1.5 }}>
        In Groundwire, also set Media encryption (SRTP) to “Optional”, and turn on Push notifications.
        Keep this password private — anyone who has it can make calls on the shop line.
      </p>
    </Modal>
  );
}
