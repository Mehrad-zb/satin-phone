import { useCallback, useEffect, useMemo, useState } from 'react';
import { get, put, patch, post } from '../api.js';
import { toast, useStore } from '../store.js';
import { Switch, Segmented } from '../ui.jsx';
import { IPhone, IClock, IMonitor, IMobile, IPlus, IX } from '../icons.jsx';
import Prompt from '../components/Prompt.jsx';
import DeptMenu from '../components/DeptMenu.jsx';

const DAYS = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']];
const SHORT = { mon: 'Mon', tue: 'Tue', wed: 'Wed', thu: 'Thu', fri: 'Fri', sat: 'Sat', sun: 'Sun' };

const SCRIPTS = {
  greeting: ['Thanks for calling Satin Graphic. For English, press 1.', 'برای فارسی، عدد ۲ را فشار دهید.'],
  closed: ['You’ve reached Satin Auto Wrap. We’re open Monday to Friday 9 to 5, and Saturday 10 to 3, at 50 Viceroy Road, Unit 22, in Vaughan. Please leave a message after the tone.', 'با ستین اتو رپ تماس گرفتید. لطفاً بعد از صدای بوق پیام بگذارید.'],
  'vm-en': ['Sorry we missed you. Please leave your name, number and what you need after the tone.'],
  'vm-fa': ['متأسفیم که نتونستیم جواب بدیم. لطفاً بعد از صدای بوق اسم، شماره و کارتون رو بگید.'],
  'recnotice-en': ['This call may be recorded for quality.'],
  'recnotice-fa': ['این تماس ممکن است برای کیفیت ضبط شود.'],
};

const to12 = (t) => {
  const [h, m] = t.split(':').map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`;
};

function hoursSummary(hours) {
  const groups = [];
  for (const [d] of DAYS) {
    const h = hours[d];
    const label = h.open ? `${to12(h.from)} – ${to12(h.to)}` : 'Closed';
    const last = groups[groups.length - 1];
    if (last && last.label === label) last.days.push(d); else groups.push({ label, days: [d] });
  }
  return groups.map((g) => `${g.days.length > 2 ? `${SHORT[g.days[0]]}–${SHORT[g.days[g.days.length - 1]]}` : g.days.map((d) => SHORT[d]).join(', ')} · ${g.label}`);
}

export default function FlowPage() {
  const me = useStore((s) => s.me);
  const isAdmin = me?.user?.role === 'admin';
  const [view, setView] = useState(null);
  const [form, setForm] = useState(null);
  const [team, setTeam] = useState(null);
  const [saving, setSaving] = useState(false);
  const [newDate, setNewDate] = useState('');
  const [promptVer, setPromptVer] = useState(Date.now());

  const load = useCallback(async () => {
    const v = await get('/api/settings');
    setView(v);
    setForm(structuredClone(v.settings));
    if (isAdmin) get('/api/team').then(setTeam).catch(() => {});
  }, [isAdmin]);
  useEffect(() => { load().catch((e) => toast(e.message, 'error')); }, [load]);

  const dirty = useMemo(() => view && form && JSON.stringify(view.settings) !== JSON.stringify(form), [view, form]);
  if (!view || !form) return <div className="empty">Loading…</div>;

  const set = (patch) => setForm((f) => ({ ...f, ...patch }));
  const setDay = (d, patch) => setForm((f) => ({ ...f, hours: { ...f.hours, [d]: { ...f.hours[d], ...patch } } }));
  const p = view.prompts;
  const onPrompt = (res) => { if (res?.prompts) setView((v) => ({ ...v, prompts: res.prompts })); setPromptVer(Date.now()); };

  const save = async () => {
    setSaving(true);
    try {
      const v = await put('/api/settings', form);
      setView(v);
      setForm(structuredClone(v.settings));
      toast('Saved. New calls follow these settings right away.');
    } catch (e) {
      toast(e.message, 'error');
    } finally {
      setSaving(false);
    }
  };
  const testCall = async () => {
    try { const r = await post('/api/calls/test'); toast(r.message, 'info', 6000); } catch (e) { toast(e.message, 'error'); }
  };
  const toggleRing = async (device, ring) => {
    try { setTeam(await patch(`/api/team/devices/${device.id}`, { ring })); } catch (e) { toast(e.message, 'error'); }
  };

  const menuOn = form.languageMenu && p.greeting;
  const deptOn = form.departmentMenu && (form.departments || []).length > 0 && (p['menu-en'] || p['menu-fa']);
  const afterLang = deptOn ? 'Phone menu' : 'Ring all devices';
  const ringDevices = (team?.users || []).filter((u) => u.active).flatMap((u) => u.devices.map((d) => ({ ...d, userName: u.name, dnd: u.status === 'dnd' })));

  return (
    <>
      <div className="page-head">
        <div>
          <span className="eyebrow">Phone system</span>
          <h1>Call flow &amp; hours</h1>
          <p>What happens, step by step, when someone calls {view.mainNumberFormatted}.</p>
        </div>
        <div className="head-actions">
          <button type="button" className="btn" onClick={testCall}><IPhone size={16} sw={2} /> Place a test call</button>
          {isAdmin && <button type="button" className="btn primary" disabled={!dirty || saving} onClick={save}>{saving ? 'Saving…' : dirty ? 'Save changes' : 'Saved'}</button>}
        </div>
      </div>
      {!isAdmin && <div className="notice blue">Only admins can change the call flow. You can still listen and place a test call.</div>}

      <div className="cols">
        <section className="flow col-main" aria-label="Call flow">
          <div className="step">
            <div className="step-head">
              <span className="step-icon"><IPhone size={20} /></span>
              <div style={{ flex: 1 }}><span className="eyebrow">Step 1</span><div className="step-title">Someone calls {view.mainNumberFormatted}</div></div>
              <span className={`pill ${view.business.open ? 'green' : ''}`}><span className={`dot ${view.business.open ? '' : 'off'}`} />{view.business.reason}</span>
            </div>
          </div>
          <div className="connector" />
          <div className="step">
            <div className="step-head">
              <span className="step-icon"><IClock size={20} /></span>
              <div style={{ flex: 1 }}><span className="eyebrow">Step 2</span><div className="step-title">Is the shop open right now?</div></div>
            </div>
            <div className="chips indent">
              {hoursSummary(form.hours).map((s) => <span key={s} className="pill">{s}</span>)}
              {form.closeOnHolidays && <span className="pill">Closed on Ontario holidays</span>}
            </div>
            <div className="indent">
              <Segmented label="Open or closed" value={form.override} onChange={(v) => isAdmin && set({ override: v })}
                options={[{ value: 'auto', label: 'Follow hours' }, { value: 'open', label: 'Force open' }, { value: 'closed', label: 'Force closed' }]} />
            </div>
          </div>
          <div className="connector" />

          <div className="lanes">
            <div className="lane">
              <span className="pill green"><span className="dot" />Open · during business hours</span>
              <div className="connector short" />
              <div className="step">
                <div className="row" style={{ minHeight: 0 }}>
                  <span className="step-title grow">Welcome greeting &amp; language menu</span>
                  <Switch checked={form.languageMenu} disabled={!isAdmin} label="Language menu" onChange={(v) => set({ languageMenu: v })} />
                </div>
                {!p.greeting && <span className="row-sub">Record a greeting to turn on the menu. Until then, calls go straight to ringing.</span>}
                {menuOn && (
                  <>
                    <div className="row"><span className="key-chip">1</span><span className="grow">English</span><span className="row-sub">→ {afterLang}</span></div>
                    <div className="row"><span className="key-chip">2</span><span className="grow fa">فارسی</span><span className="row-sub">→ {afterLang}</span></div>
                    <span className="row-sub">No key pressed in {form.menuTimeout} seconds → {form.defaultLanguage === 'fa' ? 'Farsi' : 'English'}</span>
                  </>
                )}
                <Prompt name="greeting" label="Greeting" script={SCRIPTS.greeting} exists={p.greeting} version={promptVer} disabled={!isAdmin} onSaved={onPrompt} />
              </div>
              <div className="connector" />
              <DeptMenu form={form} set={set} team={view.team} prompts={p} promptVer={promptVer} onPrompt={onPrompt} disabled={!isAdmin} />
              <div className="connector" />
              <div className="step">
                <div className="row" style={{ minHeight: 0 }}>
                  <span className="step-title grow">{deptOn ? 'Ring the chosen people (no key: everyone)' : 'Ring all devices'}</span>
                  <label className="row-sub" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>for
                    <select className="input" style={{ width: 'auto', height: 36 }} value={form.ringSeconds} disabled={!isAdmin}
                      onChange={(e) => set({ ringSeconds: Number(e.target.value) })}>
                      {[15, 20, 25, 30, 40, 60].map((n) => <option key={n} value={n}>{n} seconds</option>)}
                    </select>
                  </label>
                </div>
                {isAdmin ? ringDevices.map((d) => (
                  <div key={d.id} className="row">
                    {d.kind === 'web' ? <IMonitor size={18} /> : <IMobile size={18} />}
                    <span className="grow">{d.userName} · {d.label}{d.dnd && <span className="row-sub"> · do not disturb</span>}</span>
                    <span className={`dot ${d.online ? '' : 'off'}`} title={d.online ? 'Online' : 'Offline'} />
                    <Switch checked={d.ring} label={`Ring ${d.userName} ${d.label}`} onChange={(v) => toggleRing(d, v)} />
                  </div>
                )) : <span className="row-sub">Every team device that’s online rings at once.</span>}
              </div>
              <div className="connector" />
              <div className="step">
                <span className="step-title">No answer → Voicemail</span>
                <span className="row-sub">Saved in the app{form.voicemailEmail ? ` and emailed to ${form.voicemailEmail}` : ''}{form.transcribe ? ', with a written transcript' : ''}.</span>
                <Prompt name="vm-en" label="Voicemail prompt · English" script={SCRIPTS['vm-en']} exists={p['vm-en']} version={promptVer} disabled={!isAdmin} onSaved={onPrompt} />
                <Prompt name="vm-fa" label="Voicemail prompt · Farsi" script={SCRIPTS['vm-fa']} exists={p['vm-fa']} version={promptVer} disabled={!isAdmin} onSaved={onPrompt} />
              </div>
            </div>

            <div className="lane">
              <span className="pill"><span className="dot off" />Closed · after hours &amp; holidays</span>
              <div className="connector short" />
              <div className="step">
                <span className="step-title">After-hours message</span>
                <Prompt name="closed" label="After-hours message" script={SCRIPTS.closed} exists={p.closed} version={promptVer} disabled={!isAdmin} onSaved={onPrompt} />
              </div>
              <div className="connector" />
              <div className="step">
                <span className="step-title">Voicemail</span>
                <span className="row-sub">You’ll see it in Voicemail{form.voicemailEmail ? ' and get an email' : ''} as soon as it comes in.</span>
              </div>
            </div>
          </div>
        </section>

        <aside className="col-side" aria-label="Settings">
          <section className="card" style={{ gap: 4 }}>
            <h2 style={{ marginBottom: 8 }}>Business hours</h2>
            {DAYS.map(([d, name]) => (
              <div key={d} className="hours-row">
                <div className="day">
                  <span style={{ fontWeight: 500 }}>{name}</span>
                  <span className="times">
                    {form.hours[d].open ? (
                      <>
                        <input type="time" aria-label={`${name} opens`} value={form.hours[d].from} disabled={!isAdmin} onChange={(e) => setDay(d, { from: e.target.value })} />
                        <span className="row-sub">to</span>
                        <input type="time" aria-label={`${name} closes`} value={form.hours[d].to} disabled={!isAdmin} onChange={(e) => setDay(d, { to: e.target.value })} />
                      </>
                    ) : <span className="closed">Closed</span>}
                  </span>
                </div>
                <Switch checked={form.hours[d].open} disabled={!isAdmin} label={`${name} open`} onChange={(v) => setDay(d, { open: v })} />
              </div>
            ))}
            <div className="divider" />
            <div className="row">
              <span className="grow">Closed on Ontario statutory holidays</span>
              <Switch checked={form.closeOnHolidays} disabled={!isAdmin} label="Closed on holidays" onChange={(v) => set({ closeOnHolidays: v })} />
            </div>
            {form.closeOnHolidays && (
              <div className="chips" style={{ paddingBottom: 8 }}>
                {view.holidays.map((h) => <span key={h.date} className="pill" title={h.date}>{h.name} · {new Date(`${h.date}T12:00`).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>)}
              </div>
            )}
            <span className="row-sub" style={{ marginTop: 6 }}>Other days you’re closed (vacation, Christmas Eve…)</span>
            <div className="chips" style={{ padding: '8px 0' }}>
              {form.closedDates.map((d) => (
                <span key={d} className="chip-x">{new Date(`${d}T12:00`).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                  {isAdmin && <button type="button" aria-label={`Remove ${d}`} onClick={() => set({ closedDates: form.closedDates.filter((x) => x !== d) })}><IX size={14} /></button>}
                </span>
              ))}
            </div>
            {isAdmin && (
              <div className="row" style={{ gap: 8 }}>
                <input className="input" type="date" aria-label="Add a closed day" value={newDate} onChange={(e) => setNewDate(e.target.value)} style={{ width: 'auto' }} />
                <button type="button" className="btn sm" disabled={!newDate} onClick={() => { set({ closedDates: [...new Set([...form.closedDates, newDate])].sort() }); setNewDate(''); }}><IPlus size={14} /> Add</button>
              </div>
            )}
          </section>

          <section className="card" style={{ gap: 10 }}>
            <h2>Voicemail &amp; recording</h2>
            <label className="field">Send voicemail to (email)
              <input type="email" placeholder="you@satinautowrap.com" value={form.voicemailEmail} disabled={!isAdmin} onChange={(e) => set({ voicemailEmail: e.target.value })} />
              <small>Separate several addresses with commas.</small>
            </label>
            <div className="row"><span className="grow">Write voicemail transcripts (English &amp; Farsi)</span><Switch checked={form.transcribe} disabled={!isAdmin} label="Transcripts" onChange={(v) => set({ transcribe: v })} /></div>
            <div className="row">
              <span className="grow">Write transcripts of recorded calls<div className="row-sub">{view.transcriptsAvailable ? 'Shown under each call. Search finds words people said.' : 'Needs an OpenAI API key on the server (OPENAI_API_KEY).'}</div></span>
              <Switch checked={form.transcribeCalls} disabled={!isAdmin} label="Call transcripts" onChange={(v) => set({ transcribeCalls: v })} />
            </div>
            <div className="divider" />
            <div className="row">
              <span className="grow">Record incoming calls<div className="row-sub">Only the conversation is recorded, not the ringing.</div></span>
              <Switch checked={form.recordCalls} disabled={!isAdmin} label="Record calls" onChange={(v) => set({ recordCalls: v })} />
            </div>
            {form.recordCalls && (
              <>
                <div className="row"><span className="grow">Also record outgoing calls</span><Switch checked={form.recordOutgoing} disabled={!isAdmin} label="Record outgoing" onChange={(v) => set({ recordOutgoing: v })} /></div>
                <div className="row">
                  <span className="grow">Tell callers the call may be recorded<div className="row-sub">Recommended: Canadian privacy law expects you to tell customers.</div></span>
                  <Switch checked={form.recordingNotice} disabled={!isAdmin} label="Recording notice" onChange={(v) => set({ recordingNotice: v })} />
                </div>
                {form.recordingNotice && (
                  <>
                    <Prompt name="recnotice-en" label="Recording notice · English" script={SCRIPTS['recnotice-en']} exists={p['recnotice-en']} version={promptVer} disabled={!isAdmin} onSaved={onPrompt} />
                    <Prompt name="recnotice-fa" label="Recording notice · Farsi" script={SCRIPTS['recnotice-fa']} exists={p['recnotice-fa']} version={promptVer} disabled={!isAdmin} onSaved={onPrompt} />
                  </>
                )}
                <label className="field">Who can listen to recordings
                  <select value={form.recordingsVisibleTo} disabled={!isAdmin} onChange={(e) => set({ recordingsVisibleTo: e.target.value })}>
                    <option value="admin">Admins only</option>
                    <option value="all">Everyone on the team</option>
                  </select>
                </label>
              </>
            )}
            <label className="field">Keep recordings and voicemail for
              <select value={form.retentionDays} disabled={!isAdmin} onChange={(e) => set({ retentionDays: Number(e.target.value) })}>
                {[[30, '30 days'], [90, '3 months'], [180, '6 months'], [365, '1 year'], [730, '2 years'], [1825, '5 years']].map(([v, l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </label>
          </section>

          <section className="card" style={{ gap: 10 }}>
            <h2>Menu &amp; calling</h2>
            <label className="field">If the caller doesn’t press a key
              <select value={form.defaultLanguage} disabled={!isAdmin} onChange={(e) => set({ defaultLanguage: e.target.value })}>
                <option value="en">Continue in English</option>
                <option value="fa">Continue in Farsi</option>
              </select>
            </label>
            <label className="field">Wait for a key press
              <select value={form.menuTimeout} disabled={!isAdmin} onChange={(e) => set({ menuTimeout: Number(e.target.value) })}>
                {[3, 4, 5, 7, 10].map((n) => <option key={n} value={n}>{n} seconds</option>)}
              </select>
            </label>
            <div className="row">
              <span className="grow">Allow international &amp; Caribbean calls<div className="row-sub">Off protects you from expensive fraud calls. 1-900 numbers stay blocked.</div></span>
              <Switch checked={form.allowInternational} disabled={!isAdmin} label="Allow international" onChange={(v) => set({ allowInternational: v })} />
            </div>
          </section>
          {isAdmin && dirty && <button type="button" className="btn primary block" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save changes'}</button>}
        </aside>
      </div>
    </>
  );
}
