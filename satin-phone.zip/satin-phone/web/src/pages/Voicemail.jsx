import { useCallback, useEffect, useState } from 'react';
import { get, patch, del } from '../api.js';
import { toast, useStore } from '../store.js';
import { AudioPlayer, Avatar, Empty, Segmented } from '../ui.jsx';
import { dur, timeLabel } from '../format.js';
import { IPhone, ITrash, ICheck, IUser } from '../icons.jsx';
import { dial } from '../phone.js';
import ContactModal from '../components/ContactModal.jsx';

export default function VoicemailPage() {
  const vmVersion = useStore((s) => s.vmVersion);
  const [filter, setFilter] = useState('all');
  const [items, setItems] = useState(null);
  const [saving, setSaving] = useState(null);

  const load = useCallback(() => {
    get(`/api/voicemails?filter=${filter}`).then((d) => setItems(d.voicemails)).catch((e) => toast(e.message, 'error'));
  }, [filter]);
  useEffect(() => { load(); }, [load, vmVersion]);

  const setListened = async (v, listened) => {
    try { await patch(`/api/voicemails/${v.id}`, { listened }); load(); } catch (e) { toast(e.message, 'error'); }
  };
  const remove = async (v) => {
    if (!window.confirm('Delete this voicemail? This can’t be undone.')) return;
    try { await del(`/api/voicemails/${v.id}`); load(); } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <>
      <div className="page-head">
        <div>
          <span className="eyebrow">Main line</span>
          <h1>Voicemail</h1>
        </div>
        <Segmented label="Filter voicemail" value={filter} onChange={setFilter}
          options={[{ value: 'all', label: 'All' }, { value: 'new', label: 'New' }]} />
      </div>
      {items && !items.length && (
        <div className="card"><Empty>{filter === 'new' ? 'No new voicemail. You’re all caught up.' : 'No voicemail yet. Messages people leave after hours or when nobody answers show up here.'}</Empty></div>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 820 }}>
        {(items || []).map((v) => (
          <section key={v.id} className="card" aria-label={`Voicemail from ${v.contact?.name || v.numberFormatted}`}>
            <div className="details-top">
              <Avatar name={v.contact?.name} size="lg" />
              <div style={{ flex: 1, minWidth: 0 }}>
                <h2 style={{ fontSize: 19 }}>{v.test ? 'Test call' : v.contact?.name || v.numberFormatted}</h2>
                <span className="row-sub">{v.contact ? `${v.numberFormatted} · ` : ''}{timeLabel(v.createdAt)} · {dur(v.duration)}</span>
              </div>
              {!v.listened && <span className="pill blue">New</span>}
            </div>
            <div onClick={() => { if (!v.listened) setListened(v, true); }} role="presentation">
              <AudioPlayer src={`/api/voicemails/${v.id}/audio`} label="Voicemail" length={v.duration} seed={`vm${v.id}`} />
            </div>
            {v.transcript && (
              <div className="transcript">
                <span className="eyebrow">Transcript{v.lang === 'fa' ? ' · Farsi' : ''}</span>
                <p dir={v.lang === 'fa' ? 'rtl' : 'auto'} lang={v.lang || undefined}>{v.transcript}</p>
              </div>
            )}
            <div className="actions">
              {v.number && <button type="button" className="btn primary" onClick={() => dial(v.number)}><IPhone size={16} sw={2} /> Call back</button>}
              {v.number && !v.contact && <button type="button" className="btn" onClick={() => setSaving(v)}><IUser size={16} /> Save as customer</button>}
              <button type="button" className="btn" onClick={() => setListened(v, !v.listened)}><ICheck size={16} /> {v.listened ? 'Mark as new' : 'Mark as heard'}</button>
              <button type="button" className="btn" style={{ color: 'var(--red)' }} onClick={() => remove(v)}><ITrash size={16} /> Delete</button>
            </div>
          </section>
        ))}
      </div>
      {saving && <ContactModal presetPhone={saving.number} onClose={() => setSaving(null)} onSaved={load} />}
    </>
  );
}
