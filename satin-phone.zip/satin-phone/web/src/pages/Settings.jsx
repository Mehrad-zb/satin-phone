import { useEffect, useRef, useState } from 'react';
import { get, post, del } from '../api.js';
import { store, toast, useStore } from '../store.js';
import { CopyButton, Modal } from '../ui.jsx';
import { ILogout, IBell, IMic, IPlus, ITrash } from '../icons.jsx';

export default function SettingsPage({ onLogout }) {
  const me = useStore((s) => s.me);
  const phone = useStore((s) => s.phone);
  const isAdmin = me?.user?.role === 'admin';
  return (
    <>
      <div className="page-head">
        <div><span className="eyebrow">Satin Phone</span><h1>Settings</h1></div>
        <button type="button" className="btn" onClick={onLogout}><ILogout size={16} /> Sign out</button>
      </div>
      <div className="cols">
        <div className="col-main" style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <Account me={me} />
          <ThisBrowser phone={phone} />
        </div>
        {isAdmin && <div className="col-side"><SystemStatus /></div>}
      </div>
    </>
  );
}

function Account({ me }) {
  const [f, setF] = useState({ current: '', next: '' });
  const change = async () => {
    try { await post('/api/me/password', f); setF({ current: '', next: '' }); toast('Password changed'); } catch (e) { toast(e.message, 'error'); }
  };
  return (
    <section className="card">
      <h2>Your account</h2>
      <dl className="kv">
        <dt>Name</dt><dd>{me.user.name}</dd>
        <dt>Username</dt><dd>@{me.user.username}</dd>
        <dt>Extension</dt><dd>{me.user.ext} <span className="row-sub">(teammates can transfer calls to you with this)</span></dd>
        <dt>Role</dt><dd>{me.user.role === 'admin' ? 'Admin' : 'Team member'}</dd>
      </dl>
      <div className="divider" />
      <strong>Change password</strong>
      <label className="field">Current password<input type="password" autoComplete="current-password" value={f.current} onChange={(e) => setF({ ...f, current: e.target.value })} /></label>
      <label className="field">New password <small>(8+ characters)</small><input type="password" autoComplete="new-password" value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} /></label>
      <div><button type="button" className="btn primary" disabled={!f.current || f.next.length < 8} onClick={change}>Change password</button></div>
    </section>
  );
}

function ThisBrowser({ phone }) {
  const [perm, setPerm] = useState(() => ('Notification' in window ? Notification.permission : 'unsupported'));
  const [level, setLevel] = useState(null);
  const stopRef = useRef(null);
  useEffect(() => () => stopRef.current?.(), []);

  const testMic = async () => {
    if (stopRef.current) { stopRef.current(); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ac = new AudioContext();
      const an = ac.createAnalyser();
      ac.createMediaStreamSource(stream).connect(an);
      const buf = new Uint8Array(an.fftSize);
      let raf;
      const tick = () => {
        an.getByteTimeDomainData(buf);
        let peak = 0;
        for (const v of buf) peak = Math.max(peak, Math.abs(v - 128));
        setLevel(Math.min(1, peak / 64));
        raf = requestAnimationFrame(tick);
      };
      tick();
      stopRef.current = () => { cancelAnimationFrame(raf); stream.getTracks().forEach((t) => t.stop()); ac.close(); stopRef.current = null; setLevel(null); };
    } catch {
      toast('Allow microphone access for this site in your browser settings.', 'error');
    }
  };
  const statusText = { registered: 'Connected — this browser rings for shop calls', connecting: 'Connecting…', offline: 'Not connected — retrying', idle: 'Not started', error: 'Error' }[phone.status];
  return (
    <section className="card">
      <h2>This browser</h2>
      <div className="row"><span className={`dot ${phone.status === 'registered' ? '' : 'warn'}`} /><span className="grow">{statusText}</span></div>
      <div className="row">
        <IBell size={18} />
        <span className="grow">Notifications for incoming calls<div className="row-sub">So you see calls even when this tab is in the background.</div></span>
        {perm === 'granted' ? <span className="pill green">On</span> : perm === 'denied' ? <span className="pill">Blocked in browser</span> : perm === 'unsupported' ? <span className="pill">Not supported</span> : (
          <button type="button" className="btn sm" onClick={async () => setPerm(await Notification.requestPermission())}>Turn on</button>
        )}
      </div>
      <div className="row">
        <IMic size={18} />
        <span className="grow">Microphone check
          {level !== null && <div style={{ height: 8, borderRadius: 4, background: 'var(--chip)', marginTop: 8, overflow: 'hidden' }}><div style={{ width: `${Math.round(level * 100)}%`, height: '100%', background: 'var(--green)', transition: 'width 0.08s' }} /></div>}
        </span>
        <button type="button" className="btn sm" onClick={testMic}>{level === null ? 'Test' : 'Stop'}</button>
      </div>
      <p className="row-sub" style={{ margin: 0, lineHeight: 1.5 }}>
        Tip: on a phone, add this page to your home screen for an app-like window. For calls while your phone is locked, use Groundwire (see Team &amp; devices).
      </p>
    </section>
  );
}

function SystemStatus() {
  const presence = useStore((s) => s.presence);
  const [sys, setSys] = useState(null);
  const [hook, setHook] = useState(null);
  const [newHook, setNewHook] = useState('');
  const load = () => get('/api/system').then(setSys).catch(() => {});
  useEffect(() => { load(); }, [presence]);
  if (!sys) return null;
  const trunk = sys.presence.trunk;
  const trunkText = !sys.voipmsConfigured ? 'Not set up yet (add VoIP.ms details to satin.env)' : trunk === 'registered' ? `Connected to VoIP.ms (${sys.voipmsServer})` : `Not connected (${trunk})`;
  const testEmail = async () => { try { await post('/api/system/test-email'); toast('Test email sent'); } catch (e) { toast(e.message, 'error'); } };
  const addHook = async () => {
    try { const r = await post('/api/webhooks', { url: newHook }); setHook(r.secret); setNewHook(''); load(); } catch (e) { toast(e.message, 'error'); }
  };
  return (
    <section className="card">
      <h2>System</h2>
      <dl className="kv">
        <dt>Phone line</dt><dd><span className={`dot ${trunk === 'registered' ? '' : 'warn'}`} style={{ display: 'inline-block', marginRight: 8 }} />{trunkText}</dd>
        <dt>Phone server</dt><dd>{sys.presence.asterisk ? `Running · Asterisk ${sys.presence.version}` : 'Not connected'}</dd>
        <dt>Secure phones (TLS)</dt><dd>{sys.tls ? 'On' : 'Not yet — the installer adds it with your domain'}</dd>
        <dt>Voicemail email</dt><dd>{sys.smtpConfigured ? <button type="button" className="btn sm" onClick={testEmail}>Send a test email</button> : 'Add SMTP details to satin.env'}</dd>
        <dt>Transcripts</dt><dd>{sys.transcriptionConfigured ? 'On' : 'Add OPENAI_API_KEY to satin.env to turn on'}</dd>
        {sys.disk && <><dt>Disk space</dt><dd>{sys.disk.freeGb} GB free of {sys.disk.totalGb} GB</dd></>}
      </dl>
      <div className="divider" />
      <strong>Website admin panel connection</strong>
      <span className="row-sub">The admin panel uses this key to sync customers and start calls. Keep it secret.</span>
      {sys.apiKey ? (
        <div className="creds"><span>API key</span><code>{sys.apiKey}</code><CopyButton text={sys.apiKey} label="Copy API key" /></div>
      ) : <span className="row-sub">No API key set (API_KEY in satin.env).</span>}
      <span className="row-sub">Webhooks — we POST call and voicemail events to these addresses:</span>
      {sys.webhooks.map((w) => (
        <div key={w.id} className="row"><code className="grow" style={{ overflowWrap: 'anywhere', fontSize: 13 }}>{w.url}</code>
          <button type="button" className="icon-btn" aria-label="Remove webhook" onClick={async () => { await del(`/api/webhooks/${w.id}`); load(); }}><ITrash /></button></div>
      ))}
      <div className="row" style={{ gap: 8 }}>
        <input className="input" placeholder="https://satingraphic.ca/admin/api/phone-events" value={newHook} onChange={(e) => setNewHook(e.target.value)} />
        <button type="button" className="btn sm" disabled={!/^https?:\/\//.test(newHook)} onClick={addHook}><IPlus size={14} /> Add</button>
      </div>
      {hook && (
        <Modal title="Webhook secret" onClose={() => setHook(null)} footer={<button type="button" className="btn primary" onClick={() => setHook(null)}>Done</button>}>
          <p style={{ margin: 0 }}>Copy this now — it’s shown only once. The admin panel uses it to check that events really come from Satin Phone.</p>
          <div className="creds"><span>Secret</span><code>{hook}</code><CopyButton text={hook} /></div>
        </Modal>
      )}
    </section>
  );
}

export async function logout() {
  try { await post('/api/auth/logout'); } catch { /* ignore */ }
  store.set({ me: null });
}
