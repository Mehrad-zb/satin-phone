import { useCallback, useEffect, useMemo, useState } from 'react';
import { get } from '../api.js';
import { useStore } from '../store.js';
import { callKind, callTitle, dur, timeLabel, dayGroup, LANG } from '../format.js';
import { Avatar, KindIcon, Segmented, Modal, Empty } from '../ui.jsx';
import { ISearch } from '../icons.jsx';
import { Dialer, useIsMobile } from '../components/Call.jsx';
import CallDetails from '../components/CallDetails.jsx';
import { StatusButton, todayEyebrow } from '../components/Header.jsx';

const FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'missed', label: 'Missed' },
  { value: 'voicemail', label: 'Voicemail' },
  { value: 'recorded', label: 'Recorded' },
];

export default function CallsPage({ preset = 'all', title = 'Calls' }) {
  const me = useStore((s) => s.me);
  const stats = useStore((s) => s.stats);
  const version = useStore((s) => s.version);
  const mobile = useIsMobile();
  const [filter, setFilter] = useState(preset);
  const [q, setQ] = useState('');
  const [query, setQuery] = useState('');
  const [data, setData] = useState({ calls: [], counts: {} });
  const [more, setMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState(null);
  const [sheet, setSheet] = useState(null);
  const [number, setNumber] = useState('');

  useEffect(() => setFilter(preset), [preset]);
  useEffect(() => { const t = setTimeout(() => setQuery(q.trim()), 250); return () => clearTimeout(t); }, [q]);

  const load = useCallback(async () => {
    const p = new URLSearchParams({ filter, limit: '50' });
    if (query) p.set('q', query);
    try {
      const d = await get(`/api/calls?${p}`);
      setData(d);
      setMore(d.calls.length === 50);
    } finally {
      setLoading(false);
    }
  }, [filter, query]);

  useEffect(() => { load(); }, [load, version]);

  const loadMore = async () => {
    const last = data.calls[data.calls.length - 1];
    if (!last) return;
    const p = new URLSearchParams({ filter, limit: '50', before: String(last.startedAt) });
    if (query) p.set('q', query);
    const d = await get(`/api/calls?${p}`);
    setData((old) => ({ ...old, calls: [...old.calls, ...d.calls] }));
    setMore(d.calls.length === 50);
  };

  const calls = data.calls;
  const selected = calls.find((c) => c.id === selectedId) || (mobile ? null : calls[0]) || null;
  const counts = data.counts || {};
  const tabs = FILTERS.map((f) => ({ ...f, count: counts[f.value] }));

  const grouped = useMemo(() => {
    const out = [];
    let last = '';
    for (const c of calls) {
      const g = dayGroup(c.startedAt);
      if (g !== last) { out.push({ group: g }); last = g; }
      out.push({ call: c });
    }
    return out;
  }, [calls]);

  const pick = (c) => { setSelectedId(c.id); if (mobile) setSheet(c.id); };

  return (
    <>
      <div className="page-head">
        <div>
          <span className="eyebrow">{todayEyebrow()}</span>
          <h1>{title}</h1>
        </div>
        <div className="head-actions">
          <label className="search">
            <ISearch size={16} />
            <input type="search" aria-label="Search calls" placeholder="Search name, number or note" value={q} onChange={(e) => setQ(e.target.value)} />
          </label>
          {!mobile && <StatusButton />}
        </div>
      </div>

      {stats && (
        <div className="stats">
          <div className="stat"><span>Calls today</span><strong>{stats.calls}</strong></div>
          <div className="stat"><span>Missed today</span><strong style={{ color: stats.missed ? 'var(--red)' : undefined }}>{stats.missed}</strong></div>
          <div className="stat"><span>New voicemail</span><strong>{stats.newVoicemails}</strong></div>
          <div className="stat"><span>Talk time today</span><strong className="tabular">{dur(stats.talk)}</strong></div>
        </div>
      )}

      <div className="cols">
        <section className="card list col-main" aria-label="Recent calls">
          <div className="card-head">
            <h2>Recent</h2>
            <Segmented label="Filter calls" options={tabs} value={filter} onChange={(v) => { setFilter(v); setSelectedId(null); }} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {grouped.map((item, i) => item.group
              ? (mobile ? <div key={`g${i}`} className="group-label">{item.group}</div> : null)
              : <CallRow key={item.call.id} call={item.call} selected={!mobile && selected?.id === item.call.id} onPick={pick} />)}
            {!loading && !calls.length && (
              <Empty>{query ? 'No calls match your search.' : filter === 'all' ? 'No calls yet. Calls to the shop line show up here.' : 'Nothing here yet.'}</Empty>
            )}
            {more && calls.length > 0 && (
              <div className="load-more"><button type="button" className="btn ghost" onClick={loadMore}>Show older calls</button></div>
            )}
          </div>
        </section>

        <div className="col-side desktop-only">
          <CallDetails call={selected} onChanged={load} />
          <Dialer number={number} setNumber={setNumber} mainNumberFormatted={me?.mainNumberFormatted} />
        </div>
      </div>

      {mobile && sheet && (
        <Modal title="Call details" onClose={() => setSheet(null)}>
          <CallDetails bare call={calls.find((c) => c.id === sheet)} onChanged={load} />
        </Modal>
      )}
    </>
  );
}

function CallRow({ call, selected, onPick }) {
  const kind = callKind(call);
  const sub = [call.contact ? call.numberFormatted : null, call.contact?.company || call.note || (call.contact ? null : 'Not in customers')].filter(Boolean).join(' · ');
  return (
    <button type="button" className="call-row" aria-pressed={selected} onClick={() => onPick(call)}>
      <Avatar name={call.contact?.name} />
      <span className="who">
        <span className={`name ${kind.key === 'missed' ? 'missed' : ''}`}>{callTitle(call)}</span>
        <span className="sub">{sub}</span>
      </span>
      {call.lang && call.direction === 'in' && <span className="lang">{LANG[call.lang] || call.lang}</span>}
      <span className={`kind ${kind.key === 'missed' ? 'missed' : ''}`}>
        <KindIcon kind={kind.key} />
        <span className="label">{kind.label}</span>
      </span>
      <span className="time">{timeLabel(call.startedAt)}</span>
    </button>
  );
}
