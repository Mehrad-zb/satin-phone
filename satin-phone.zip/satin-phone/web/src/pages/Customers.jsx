import { useCallback, useEffect, useState } from 'react';
import { get } from '../api.js';
import { toast } from '../store.js';
import { Avatar, Empty } from '../ui.jsx';
import { IPhone, IPlus, ISearch, IEdit } from '../icons.jsx';
import { dial } from '../phone.js';
import ContactModal from '../components/ContactModal.jsx';

export default function CustomersPage() {
  const [q, setQ] = useState('');
  const [list, setList] = useState(null);
  const [edit, setEdit] = useState(null);

  const load = useCallback(() => {
    get(`/api/contacts?q=${encodeURIComponent(q.trim())}`).then((d) => setList(d.contacts)).catch((e) => toast(e.message, 'error'));
  }, [q]);
  useEffect(() => { const t = setTimeout(load, 200); return () => clearTimeout(t); }, [load]);

  return (
    <>
      <div className="page-head">
        <div>
          <span className="eyebrow">Caller ID</span>
          <h1>Customers</h1>
          <p>When a saved customer calls, their name shows on every device.</p>
        </div>
        <div className="head-actions">
          <label className="search">
            <ISearch size={16} />
            <input type="search" aria-label="Search customers" placeholder="Search name, company or number" value={q} onChange={(e) => setQ(e.target.value)} />
          </label>
          <button type="button" className="btn primary" onClick={() => setEdit({})}><IPlus size={16} /> New customer</button>
        </div>
      </div>
      <section className="card list" aria-label="Customer list" style={{ maxWidth: 900 }}>
        {list && !list.length && <Empty>{q ? 'No customers match.' : 'No customers yet. Save callers from the Calls page, or add them here.'}</Empty>}
        {(list || []).map((c) => (
          <div key={c.id} className="call-row" style={{ cursor: 'default' }}>
            <Avatar name={c.name} />
            <span className="who">
              <span className="name">{c.name}</span>
              <span className="sub">{[c.phoneFormatted, c.company, c.source === 'admin' ? 'from website' : null].filter(Boolean).join(' · ')}</span>
            </span>
            <button type="button" className="icon-btn" aria-label={`Call ${c.name}`} onClick={() => dial(c.phone)}><IPhone /></button>
            <button type="button" className="icon-btn" aria-label={`Edit ${c.name}`} onClick={() => setEdit(c)}><IEdit /></button>
          </div>
        ))}
      </section>
      {edit && <ContactModal contact={edit.id ? edit : null} onClose={() => setEdit(null)} onSaved={load} />}
    </>
  );
}
