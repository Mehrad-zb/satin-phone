import { useState } from 'react';
import { useStore } from '../store.js';
import { dial } from '../phone.js';
import { keyTone, unlockAudio } from '../sounds.js';
import { fmtTyping } from '../format.js';
import { IPhoneFill, IBack } from '../icons.jsx';
import { KEYS, PhoneStatus } from '../components/Call.jsx';

export default function KeypadPage() {
  const me = useStore((s) => s.me);
  const phone = useStore((s) => s.phone);
  const [number, setNumber] = useState('');
  const press = (k) => { unlockAudio(); keyTone(k); setNumber((n) => (n + k).slice(0, 20)); };
  return (
    <div className="mobile-dial">
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
        <span className="eyebrow">Calling as</span>
        <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--ink-2)' }}>{me?.company} · {me?.mainNumberFormatted}</span>
      </div>
      <div style={{ width: '100%' }}><PhoneStatus phone={phone} /></div>
      <input className="number" aria-label="Number to call" placeholder="Enter a number" inputMode="tel" value={fmtTyping(number)}
        onChange={(e) => setNumber(e.target.value.replace(/[^0-9*#+]/g, ''))} onKeyDown={(e) => { if (e.key === 'Enter') dial(number); }} />
      <div className="mobile-keys">
        {KEYS.map(([k, sub]) => (
          <button key={k} type="button" className="key" onClick={() => press(k)}><b>{k}</b><small>{sub}</small></button>
        ))}
      </div>
      <div className="mobile-call-row">
        <span />
        <button type="button" className="round green" aria-label="Call" disabled={!number || phone.status !== 'registered'}
          onClick={() => { unlockAudio(); dial(number); }}><IPhoneFill size={30} /></button>
        {number ? (
          <button type="button" className="icon-btn" style={{ width: 60, height: 60, borderRadius: '50%' }} aria-label="Delete last digit"
            onClick={() => setNumber((n) => n.slice(0, -1))}><IBack size={28} sw={1.6} /></button>
        ) : <span />}
      </div>
    </div>
  );
}
