// A tiny global store (no extra libraries) + React hook.
import { useSyncExternalStore } from 'react';

const state = {
  me: null,
  presence: { devices: {}, trunk: 'unknown', asterisk: false },
  stats: null,
  phone: { status: 'idle', error: '' },   // idle | connecting | registered | offline | error
  call: null,       // the active/outgoing call shown in the UI
  incoming: null,   // a ringing incoming call
  toasts: [],
  liveCalls: [],
  version: 0,       // bumps when call history changes
  vmVersion: 0,     // bumps when voicemail changes
};
const subs = new Set();

export const store = {
  get: () => state,
  set(patch) {
    Object.assign(state, typeof patch === 'function' ? patch(state) : patch);
    subs.forEach((fn) => fn());
  },
  subscribe(fn) { subs.add(fn); return () => subs.delete(fn); },
};

// Snapshot identity must change when state changes, so we hand out shallow copies.
let snap = { ...state };
store.subscribe(() => { snap = { ...state }; });

export function useStore(selector = (s) => s) {
  return selector(useSyncExternalStore(store.subscribe, () => snap));
}

let toastId = 0;
export function toast(text, kind = 'info', ms = 4000) {
  const id = ++toastId;
  store.set((s) => ({ toasts: [...s.toasts, { id, text, kind }] }));
  setTimeout(() => store.set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })), ms);
}
