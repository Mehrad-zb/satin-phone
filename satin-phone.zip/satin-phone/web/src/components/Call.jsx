// Dialer, in-call controls, incoming-call card and the mobile full-screen call view.
import { useEffect, useState } from 'react';
import { useStore } from '../store.js';
import { get } from '../api.js';
import { dial, hangup, answer, decline, toggleMute, toggleHold, sendDigit, transfer } from '../phone.js';
import { keyTone, unlockAudio } from '../sounds.js';
import { fmtPhone, fmtTyping, dur } from '../format.js';
import { Avatar } from '../ui.jsx';
import { IPhone, IPhoneFill, IHangup, IBack, IMicOff, IGrid, IPause, ITransfer, IX } from '../icons.jsx';

export const KEYS = [['1', ''], ['2', 'ABC'], ['3', 'DEF'], ['4', 'GHI'], ['5', 'JKL'], ['6', 'MNO'], ['7', 'PQRS'], ['8', 'TUV'], ['9', 'WXYZ'], ['*', ''], ['0', '+'], ['#', '']];

export function useTimer(since) {
  const [, tick] = useState(0);
  useEffect(() => {
    if (!since) return undefined;
    const t = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, [since]);
  return since ? (Date.now() - since) / 1000 : 0;
}

export function useIsMobile() {
  const q = '(max-width: 860px)';
  const [m, setM] = useState(() => window.matchMedia(q).matches);
  useEffect(() => {
    const mq = window.matchMedia(q);
    const on = () => setM(mq.matches);
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);
  return m;
}

/** Contact info for a number, from what the server told us about live calls. */
export function useCaller(number, sipName) {
  const live = useStore((s) => s.liveCalls);
  const n = String(number || '').replace(/\D/g, '').replace(/^1(\d{10})$/, '$1');
  const hit = live.find((c) => c.number === n && c.contact);
  return {
    name: hit?.contact?.name || sipName || '',
    company: hit?.contact?.company || '',
    notes: hit?.contact?.notes || '',
    number: n.length >= 7 ? fmtPhone(n) : (n ? `Extension ${n}` : 'Unknown number'),
    isTest: sipName === 'Test call',
  };
}

function stateText(call, seconds) {
  if (call.state === 'connecting') return 'Connecting…';
  if (call.state === 'ringing') return 'Ringing…';
  if (call.held) return `On hold · ${dur(seconds)}`;
  return dur(seconds);
}

// ------------------------------------------------------------ desktop dialer card
export function Dialer({ number, setNumber, mainNumberFormatted }) {
  const call = useStore((s) => s.call);
  const phone = useStore((s) => s.phone);
  if (call) return <InCallPanel call={call} />;

  const press = (k) => { unlockAudio(); keyTone(k); setNumber((n) => (n + k).slice(0, 20)); };
  const start = () => { unlockAudio(); dial(number); };
  return (
    <section className="card" aria-label="Dialer">
      <div className="card-head">
        <h2>Dialer</h2>
        <span className="row-sub">Calling as {mainNumberFormatted}</span>
      </div>
      <PhoneStatus phone={phone} />
      <div className="dial-display">
        <input aria-label="Number to call" placeholder="Type or tap a number" inputMode="tel" value={fmtTyping(number)}
          onChange={(e) => setNumber(e.target.value.replace(/[^0-9*#+]/g, '').slice(0, 20))}
          onKeyDown={(e) => { if (e.key === 'Enter') start(); }} />
        {number && (
          <button type="button" className="icon-btn" aria-label="Delete last digit" onClick={() => setNumber((n) => n.slice(0, -1))}><IBack size={22} /></button>
        )}
      </div>
      <div className="keypad">
        {KEYS.map(([k, sub]) => (
          <button key={k} type="button" className="key" onClick={() => press(k)}><b>{k}</b><small>{sub}</small></button>
        ))}
      </div>
      <button type="button" className="call-btn" onClick={start} disabled={!number || phone.status !== 'registered'}>
        <IPhone size={18} sw={2} /> Call
      </button>
    </section>
  );
}

export function PhoneStatus({ phone }) {
  if (phone.status === 'registered') return null;
  if (phone.status === 'connecting' || phone.status === 'idle') return <div className="notice blue">Connecting this browser to the phone line…</div>;
  return <div className="notice warn">{phone.error || 'This browser isn’t connected to the phone line right now.'}</div>;
}

// ------------------------------------------------------------ in-call panel (desktop)
function InCallPanel({ call }) {
  const who = useCaller(call.number, call.name);
  const seconds = useTimer(call.answeredAt);
  const [pad, setPad] = useState(false);
  const [xfer, setXfer] = useState(false);
  const active = call.state === 'active';
  return (
    <section className="card incall" aria-label="Current call">
      <div className="incall-head">
        <Avatar name={who.name} size="lg" />
        <div className="grow" style={{ flex: 1, minWidth: 0 }}>
          <h2 style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{who.name || who.number}</h2>
          <div className="row-sub">{who.name ? who.number : (call.direction === 'out' ? 'Outgoing call' : 'Incoming call')}</div>
        </div>
        <span className={`pill ${active ? 'green' : 'blue'}`}><span className="tabular">{stateText(call, seconds)}</span></span>
      </div>
      {(who.company || who.notes) && <div className="quote">{[who.company, who.notes].filter(Boolean).join(' · ')}</div>}
      {pad ? <DtmfPad onClose={() => setPad(false)} /> : xfer ? <TransferPicker onClose={() => setXfer(false)} /> : (
        <div className="ctrl-grid">
          <button type="button" className="ctrl" aria-pressed={call.muted} onClick={toggleMute} disabled={!call.session}>
            <span className="ring"><IMicOff size={24} /></span>Mute
          </button>
          <button type="button" className="ctrl" onClick={() => setPad(true)} disabled={!active}>
            <span className="ring"><IGrid size={22} /></span>Keypad
          </button>
          <button type="button" className="ctrl" aria-pressed={call.held} onClick={toggleHold} disabled={!active}>
            <span className="ring"><IPause size={22} /></span>Hold
          </button>
        </div>
      )}
      {!pad && !xfer && (
        <button type="button" className="btn" onClick={() => setXfer(true)} disabled={!active}><ITransfer size={18} /> Transfer</button>
      )}
      <button type="button" className="call-btn end" onClick={hangup}><IHangup size={18} /> End call</button>
    </section>
  );
}

function DtmfPad({ onClose }) {
  const [sent, setSent] = useState('');
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div className="dial-display"><input readOnly aria-label="Digits sent" value={sent} placeholder="Digits you press are sent" />
        <button type="button" className="icon-btn" aria-label="Hide keypad" onClick={onClose}><IX /></button></div>
      <div className="keypad">
        {KEYS.map(([k, sub]) => (
          <button key={k} type="button" className="key" onClick={() => { sendDigit(k); setSent((s) => (s + k).slice(-20)); }}><b>{k}</b><small>{sub}</small></button>
        ))}
      </div>
    </div>
  );
}

export function TransferPicker({ onClose }) {
  const [people, setPeople] = useState([]);
  const [num, setNum] = useState('');
  const me = useStore((s) => s.me);
  useEffect(() => { get('/api/directory').then((d) => setPeople(d.people)).catch(() => {}); }, []);
  const go = async (t) => { await transfer(t); onClose(); };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div className="row"><strong className="grow">Transfer to</strong><button type="button" className="icon-btn" aria-label="Cancel transfer" onClick={onClose}><IX /></button></div>
      <button type="button" className="btn" style={{ justifyContent: 'flex-start' }} onClick={() => go('100')}>Everyone (rings all devices)</button>
      {people.filter((p) => p.id !== me?.user?.id).map((p) => (
        <button key={p.id} type="button" className="btn" style={{ justifyContent: 'flex-start' }} onClick={() => go(p.ext)}>
          <span className={`dot ${p.online ? '' : 'off'}`} />{p.name} <span className="row-sub">· {p.ext}</span>
        </button>
      ))}
      <div className="row" style={{ gap: 8 }}>
        <input className="input" placeholder="Or a phone number" inputMode="tel" value={fmtTyping(num)} onChange={(e) => setNum(e.target.value.replace(/\D/g, ''))} />
        <button type="button" className="btn primary" disabled={num.length < 3} onClick={() => go(num)}>Send</button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------ incoming call (desktop card)
export function IncomingCard() {
  const inc = useStore((s) => s.incoming);
  const who = useCaller(inc?.number, inc?.name);
  if (!inc) return null;
  return (
    <div className="incoming" role="alertdialog" aria-label="Incoming call">
      <span className="eyebrow">{who.isTest ? 'Test call' : 'Incoming call · Satin Auto Wrap line'}</span>
      <div className="who">
        <span className="pulse" style={{ borderRadius: '50%' }}><Avatar name={who.name} size="lg" /></span>
        <div style={{ minWidth: 0 }}>
          <strong>{who.name || who.number}</strong>
          <span className="row-sub">{who.name ? who.number : 'Not in your customers yet'}</span>
        </div>
      </div>
      {(who.company || who.notes) && <div className="quote">{[who.company, who.notes].filter(Boolean).join(' · ')}</div>}
      <div className="btns">
        <button type="button" className="btn danger" onClick={decline}><IHangup size={18} /> Decline</button>
        <button type="button" className="btn green" onClick={() => { unlockAudio(); answer(); }}><IPhoneFill size={18} /> Answer</button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------ call bar (desktop, other pages)
export function CallBar() {
  const call = useStore((s) => s.call);
  const who = useCaller(call?.number, call?.name);
  const seconds = useTimer(call?.answeredAt);
  if (!call) return null;
  return (
    <div className="callbar" role="status">
      <span className="dot" />
      <div className="grow">
        <strong>{who.name || who.number}</strong> <span style={{ opacity: 0.75 }} className="tabular">· {stateText(call, seconds)}</span>
      </div>
      <button type="button" className="icon-btn" aria-label={call.muted ? 'Unmute' : 'Mute'} aria-pressed={call.muted} onClick={toggleMute}><IMicOff /></button>
      <button type="button" className="icon-btn" aria-label={call.held ? 'Resume' : 'Hold'} aria-pressed={call.held} onClick={toggleHold}><IPause /></button>
      <button type="button" className="btn sm danger" onClick={hangup}><IHangup size={16} /> End</button>
    </div>
  );
}

// ------------------------------------------------------------ mobile full screen
export function CallScreen() {
  const call = useStore((s) => s.call);
  const inc = useStore((s) => s.incoming);
  const c = call || inc;
  const who = useCaller(c?.number, c?.name);
  const seconds = useTimer(call?.answeredAt);
  const [pad, setPad] = useState(false);
  const [xfer, setXfer] = useState(false);
  if (!c) return null;
  const ringing = !call && !!inc;
  const active = call?.state === 'active';
  return (
    <div className="callscreen" role="dialog" aria-label={ringing ? 'Incoming call' : 'Current call'}>
      <div className="row" style={{ minHeight: 32 }}>
        <span className="row-sub grow">{who.isTest ? 'Test call' : 'Satin Auto Wrap line'}</span>
      </div>
      <div className="caller">
        <span className={ringing ? 'pulse' : ''} style={{ borderRadius: '50%', marginBottom: 8 }}><Avatar name={who.name} size="xl" /></span>
        <strong>{who.name || who.number}</strong>
        <span className="row-sub" style={{ fontSize: 15 }}>{who.name ? who.number : ''}</span>
        <span className="tabular" style={{ fontSize: 17, fontWeight: 500, color: 'var(--ink-2)' }}>
          {ringing ? 'Incoming call…' : stateText(call, seconds)}
        </span>
      </div>
      {(who.company || who.notes) && (
        <div className="card" style={{ marginTop: 24, padding: '16px 18px', gap: 6 }}>
          <span className="eyebrow">Customer</span>
          <span style={{ fontWeight: 600 }}>{[who.company, who.notes].filter(Boolean).join(' · ')}</span>
        </div>
      )}
      <div style={{ flex: 1, minHeight: 24 }} />
      {ringing ? (
        <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: 24 }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <button type="button" className="round red" aria-label="Decline" onClick={decline}><IHangup size={30} /></button>Decline
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <button type="button" className="round green" aria-label="Answer" onClick={() => { unlockAudio(); answer(); }}><IPhoneFill size={30} /></button>Answer
          </div>
        </div>
      ) : (
        <>
          {pad ? <DtmfPad onClose={() => setPad(false)} /> : xfer ? <TransferPicker onClose={() => setXfer(false)} /> : (
            <div className="big-ctrls">
              <button type="button" className="ctrl" aria-pressed={call.muted} onClick={toggleMute} disabled={!call.session}><span className="ring"><IMicOff size={26} /></span>Mute</button>
              <button type="button" className="ctrl" onClick={() => setPad(true)} disabled={!active}><span className="ring"><IGrid size={24} /></span>Keypad</button>
              <button type="button" className="ctrl" aria-pressed={call.held} onClick={toggleHold} disabled={!active}><span className="ring"><IPause size={24} /></span>Hold</button>
              <button type="button" className="ctrl" onClick={() => setXfer(true)} disabled={!active}><span className="ring"><ITransfer size={26} /></span>Transfer</button>
            </div>
          )}
          <button type="button" className="round red" aria-label="End call" style={{ alignSelf: 'center', marginTop: 28 }} onClick={hangup}><IHangup size={30} /></button>
        </>
      )}
    </div>
  );
}
