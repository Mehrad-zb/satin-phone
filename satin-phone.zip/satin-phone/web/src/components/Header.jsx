import { useEffect, useRef, useState } from 'react';
import { patch } from '../api.js';
import { store, toast, useStore } from '../store.js';
import { IChevron } from '../icons.jsx';

export function StatusButton() {
  const me = useStore((s) => s.me);
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const close = (e) => { if (!ref.current?.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);
  if (!me) return null;
  const dnd = me.user.status === 'dnd';
  const pick = async (status) => {
    setOpen(false);
    try {
      const r = await patch('/api/me', { status });
      store.set((s) => ({ me: { ...s.me, user: r.user } }));
      toast(status === 'dnd' ? 'Do not disturb: your devices won’t ring for shop calls' : 'You’re available again');
    } catch (e) { toast(e.message, 'error'); }
  };
  return (
    <div ref={ref} style={{ position: 'relative' }}>
      <button type="button" className="btn" aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span className={`dot ${dnd ? 'red' : ''}`} />{dnd ? 'Do not disturb' : 'Available'}<IChevron size={14} />
      </button>
      {open && (
        <div role="menu" className="card" style={{ position: 'absolute', right: 0, top: 50, zIndex: 20, width: 260, padding: 8, gap: 2 }}>
          <button type="button" role="menuitem" className="btn" style={{ border: 0, justifyContent: 'flex-start' }} onClick={() => pick('available')}>
            <span className="dot" />Available<span className="row-sub" style={{ marginLeft: 'auto' }}>rings</span>
          </button>
          <button type="button" role="menuitem" className="btn" style={{ border: 0, justifyContent: 'flex-start' }} onClick={() => pick('dnd')}>
            <span className="dot red" />Do not disturb<span className="row-sub" style={{ marginLeft: 'auto' }}>silent</span>
          </button>
        </div>
      )}
    </div>
  );
}

export function todayEyebrow() {
  return new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' }).replace(',', ' ·');
}
