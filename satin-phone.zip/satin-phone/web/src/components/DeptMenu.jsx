// Phone menu editor: "For sales press 1, design press 2 …" — each key rings the people you pick.
import { Switch } from '../ui.jsx';
import { IPlus, ITrash } from '../icons.jsx';
import Prompt from './Prompt.jsx';

const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const faNum = (d) => String(d).replace(/\d/g, (x) => FA_DIGITS[x]);

export function menuScripts(departments) {
  const list = departments.filter((d) => d.name?.trim());
  return {
    en: list.length ? list.map((d) => `For ${d.name.trim()}, press ${d.digit}.`).concat('To reach someone directly, dial their extension.') : [],
    fa: list.length ? list.map((d) => `برای ${d.name.trim()}، عدد ${faNum(d.digit)} را بگیرید.`) : [],
  };
}

export default function DeptMenu({ form, set, team, prompts, promptVer, onPrompt, disabled }) {
  const depts = form.departments || [];
  const update = (i, patch) => set({ departments: depts.map((d, j) => (j === i ? { ...d, ...patch } : d)) });
  const remove = (i) => set({ departments: depts.filter((_, j) => j !== i) });
  const freeDigit = () => ['1', '2', '3', '4', '5', '6', '7', '8', '9'].find((k) => !depts.some((d) => d.digit === k));
  const add = () => { const digit = freeDigit(); if (digit) set({ departments: [...depts, { digit, name: '', members: [] }] }); };
  const toggleMember = (i, id) => {
    const m = depts[i].members || [];
    update(i, { members: m.includes(id) ? m.filter((x) => x !== id) : [...m, id] });
  };
  const recorded = prompts['menu-en'] || prompts['menu-fa'];
  const scripts = menuScripts(depts);

  return (
    <div className="step">
      <div className="row" style={{ minHeight: 0 }}>
        <span className="step-title grow">Phone menu</span>
        <Switch checked={form.departmentMenu} disabled={disabled} label="Phone menu" onChange={(v) => set({ departmentMenu: v })} />
      </div>
      {!form.departmentMenu && <span className="row-sub">Off: every call rings the whole team.</span>}
      {form.departmentMenu && (
        <>
          <span className="row-sub">Each key rings the people you pick. Nobody picked = the whole team.</span>
          {depts.map((d, i) => (
            <div key={i} className="dept">
              <div className="row" style={{ gap: 8 }}>
                <select className="input key-select" aria-label="Key" value={d.digit} disabled={disabled}
                  onChange={(e) => update(i, { digit: e.target.value })}>
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((k) => (
                    <option key={k} value={k} disabled={k !== d.digit && depts.some((x) => x.digit === k)}>{k}</option>
                  ))}
                </select>
                <input className="input grow" aria-label={`Name for key ${d.digit}`} placeholder="e.g. Sales" dir="auto" maxLength={40}
                  value={d.name} disabled={disabled} onChange={(e) => update(i, { name: e.target.value })} />
                {!disabled && <button type="button" className="icon-btn" aria-label={`Remove key ${d.digit}`} onClick={() => remove(i)}><ITrash size={16} /></button>}
              </div>
              <div className="chips" style={{ paddingLeft: 2 }}>
                {(team || []).map((u) => {
                  const on = (d.members || []).includes(u.id);
                  return (
                    <button key={u.id} type="button" className={`pill ${on ? 'blue' : ''}`} aria-pressed={on} disabled={disabled}
                      onClick={() => toggleMember(i, u.id)}>
                      {u.name} · {u.ext}
                    </button>
                  );
                })}
                {!(d.members || []).length && <span className="row-sub">→ rings everyone</span>}
              </div>
            </div>
          ))}
          {!disabled && depts.length < 9 && <button type="button" className="btn sm" onClick={add}><IPlus size={14} /> Add an option</button>}
          {!recorded && <div className="notice warn">Record the menu message below. Until then, calls ring the whole team.</div>}
          <Prompt name="menu-en" label="Menu message · English" script={scripts.en} exists={prompts['menu-en']} version={promptVer} disabled={disabled} onSaved={onPrompt} />
          <Prompt name="menu-fa" label="Menu message · Farsi" script={scripts.fa} exists={prompts['menu-fa']} version={promptVer} disabled={disabled} onSaved={onPrompt} />
        </>
      )}
      <div className="divider" />
      <div className="row">
        <span className="grow">Callers can dial an extension<div className="row-sub">Typing 101, 102 … during the greeting rings that person directly.</div></span>
        <Switch checked={form.dialByExtension} disabled={disabled} label="Dial by extension" onChange={(v) => set({ dialByExtension: v })} />
      </div>
    </div>
  );
}
