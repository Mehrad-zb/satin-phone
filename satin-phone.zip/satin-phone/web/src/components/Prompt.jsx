// Record (in the browser) or upload a greeting, preview it, save it to the phone system.
import { useEffect, useRef, useState } from 'react';
import { api, del } from '../api.js';
import { toast } from '../store.js';
import { AudioPlayer } from '../ui.jsx';
import { IMic, IUpload, ITrash } from '../icons.jsx';
import { dur } from '../format.js';

function pickMime() {
  const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
  return types.find((t) => window.MediaRecorder?.isTypeSupported?.(t)) || '';
}

export default function Prompt({ name, label, script = [], exists, version, disabled, onSaved }) {
  const [mode, setMode] = useState('idle'); // idle | recording | preview | saving
  const [blob, setBlob] = useState(null);
  const [url, setUrl] = useState('');
  const [secs, setSecs] = useState(0);
  const rec = useRef(null);
  const timer = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => () => { clearInterval(timer.current); if (url) URL.revokeObjectURL(url); }, [url]);

  const start = async () => {
    if (!window.MediaRecorder) { toast('This browser can’t record. Upload an audio file instead.', 'error'); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      const mime = pickMime();
      const r = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      const chunks = [];
      r.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
      r.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const b = new Blob(chunks, { type: r.mimeType || mime || 'audio/webm' });
        setBlob(b);
        setUrl(URL.createObjectURL(b));
        setMode('preview');
      };
      rec.current = r;
      r.start();
      setSecs(0);
      setMode('recording');
      const t0 = Date.now();
      timer.current = setInterval(() => {
        const s = (Date.now() - t0) / 1000;
        setSecs(s);
        if (s > 120) stop();
      }, 250);
    } catch {
      toast('Allow microphone access to record.', 'error');
    }
  };
  const stop = () => { clearInterval(timer.current); rec.current?.state === 'recording' && rec.current.stop(); };

  const upload = async (b) => {
    setMode('saving');
    try {
      const res = await api(`/api/prompts/${name}`, { method: 'PUT', raw: b });
      toast(`${label} saved (${dur(res.seconds)}). Callers hear it right away.`);
      setBlob(null); setUrl(''); setMode('idle');
      onSaved?.(res);
    } catch (e) {
      toast(e.message, 'error');
      setMode(blob ? 'preview' : 'idle');
    }
  };
  const remove = async () => {
    if (!window.confirm(`Delete the “${label}” recording?`)) return;
    try { onSaved?.(await del(`/api/prompts/${name}`)); } catch (e) { toast(e.message, 'error'); }
  };

  return (
    <div className="prompt-row">
      <div className="row" style={{ minHeight: 0 }}>
        <strong className="grow" style={{ fontSize: 15 }}>{label}</strong>
        {exists ? <span className="pill green">Recorded</span> : <span className="pill">Not recorded</span>}
      </div>
      {script.length > 0 && (
        <div className="quote" style={{ fontSize: 14, color: 'var(--ink-2)', display: 'flex', flexDirection: 'column', gap: 6 }}>
          <span className="eyebrow">Suggested script</span>
          {script.map((line) => <span key={line} dir="auto">“{line}”</span>)}
        </div>
      )}
      {mode === 'recording' && (
        <div className="notice red"><span className="rec-dot" /> Recording… <span className="tabular">{dur(secs)}</span>
          <button type="button" className="btn sm" style={{ marginLeft: 'auto' }} onClick={stop}>Stop</button></div>
      )}
      {mode === 'preview' && url && (
        <>
          <AudioPlayer src={url} label="New recording" seed={url} />
          <div className="actions">
            <button type="button" className="btn primary sm" onClick={() => upload(blob)}>Use this recording</button>
            <button type="button" className="btn sm" onClick={() => { setBlob(null); setUrl(''); setMode('idle'); }}>Discard</button>
          </div>
        </>
      )}
      {mode === 'saving' && <div className="notice blue">Saving…</div>}
      {mode === 'idle' && (
        <>
          {exists && <AudioPlayer src={`/api/prompts/${name}/audio?v=${version}`} label={label} seed={name + version} />}
          {!disabled && (
            <div className="actions">
              <button type="button" className="btn sm" onClick={start}><IMic size={16} /> {exists ? 'Re-record' : 'Record'}</button>
              <button type="button" className="btn sm" onClick={() => fileRef.current?.click()}><IUpload size={16} /> Upload file</button>
              {exists && <button type="button" className="btn sm" style={{ color: 'var(--red)' }} onClick={remove}><ITrash size={16} /> Delete</button>}
              <input ref={fileRef} type="file" accept="audio/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) upload(f); }} />
            </div>
          )}
        </>
      )}
    </div>
  );
}
