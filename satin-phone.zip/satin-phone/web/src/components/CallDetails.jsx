import { useEffect, useState } from 'react';
import { get, patch, post } from '../api.js';
import { toast, useStore } from '../store.js';
import { AudioPlayer, Avatar } from '../ui.jsx';
import { callKind, callTitle, fullTime } from '../format.js';
import { IPhone, IUser, IEdit } from '../icons.jsx';
import { dial } from '../phone.js';
import ContactModal from './ContactModal.jsx';

const LANGS = { en: 'English', fa: 'فارسی' };

function menuText(c) {
  if (c.direction === 'out') return 'Outgoing call';
  if (c.test) return 'Test call from the app';
  if (c.period === 'closed') return 'After hours → Voicemail';
  const lang = LANGS[c.lang] || 'English';
  const where = c.dept || 'Ring all';
  if (c.status === 'voicemail') return `${lang} → ${c.dept ? `${c.dept} → ` : ''}Voicemail`;
  return `${lang} → ${where}`;
}

function handledText(c) {
  if (c.direction === 'out') return c.placedBy?.name ? `${c.placedBy.name}` : 'Team';
  if (c.answeredBy) return `${c.answeredBy.userName} · ${c.answeredBy.label}`;
  if (c.status === 'voicemail') return 'Left a voicemail';
  if (c.status === 'ringing') return 'Ringing now';
  if (c.status === 'active') return 'On a call now';
  return 'Nobody answered';
}

export default function CallDetails({ call, onChanged, bare = false }) {
  const me = useStore((s) => s.me);
  const [vm, setVm] = useState(null);
  const [note, setNote] = useState(call?.note || '');
  const [editContact, setEditContact] = useState(false);

  useEffect(() => {
    setNote(call?.note || '');
    setVm(null);
    if (call?.voicemailId) get(`/api/calls/${encodeURIComponent(call.id)}`).then((d) => setVm(d.voicemail)).catch(() => {});
  }, [call?.id, call?.voicemailId]);

  if (!call) {
    return <section className="card" aria-label="Call details"><div className="empty">Pick a call to see the details.</div></section>;
  }
  const kind = callKind(call);
  const title = callTitle(call);
  const saveNote = async () => {
    if (note === (call.note || '')) return;
    try { await patch(`/api/calls/${encodeURIComponent(call.id)}`, { note }); onChanged?.(); } catch (e) { toast(e.message, 'error'); }
  };
  const retryTranscript = async () => {
    try { await post(`/api/calls/${encodeURIComponent(call.id)}/transcribe`); toast('Writing the transcript…', 'info'); onChanged?.(); } catch (e) { toast(e.message, 'error'); }
  };
  const markListened = () => {
    if (vm && !vm.listened) patch(`/api/voicemails/${vm.id}`, { listened: true }).catch(() => {});
  };

  return (
    <section className={bare ? '' : 'card'} aria-label="Call details" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div className="details-top">
        <Avatar name={call.contact?.name} size="lg" />
        <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <h2>{title}</h2>
          <span className="row-sub" style={{ fontSize: 15 }}>{call.contact ? call.numberFormatted : (call.number ? 'Not in your customers' : 'Number withheld')}</span>
        </div>
        <span className={`pill ${kind.key === 'missed' ? 'red' : ''}`}>{kind.label}</span>
      </div>

      <dl className="dl">
        <dt>Customer</dt>
        <dd>{call.contact ? [call.contact.company, call.contact.notes].filter(Boolean).join(' · ') || call.contact.name : 'No match'}</dd>
        <dt>Phone menu</dt><dd>{menuText(call)}</dd>
        <dt>{call.direction === 'out' ? 'Placed by' : 'Handled by'}</dt><dd>{handledText(call)}</dd>
        <dt>Time</dt><dd>{fullTime(call.startedAt)}</dd>
      </dl>

      {call.hasRecording && (
        <AudioPlayer src={`/api/calls/${encodeURIComponent(call.id)}/recording`} label="Call recording" length={call.talk} seed={call.id} />
      )}
      {vm && (
        <div onClick={markListened} role="presentation">
          <AudioPlayer src={`/api/voicemails/${vm.id}/audio`} label="Voicemail" length={vm.duration} seed={`vm${vm.id}`} />
        </div>
      )}
      {call.hasRecording && (call.transcript || call.transcriptStatus) && (
        <div className="transcript">
          <span className="eyebrow">Call transcript</span>
          {call.transcriptStatus === 'done' && call.transcript && (
            <div className="transcript-lines" dir="auto">{call.transcript.split(/(?<=[.!?؟])\s+/).map((line, i) => <p key={i} dir="auto">{line}</p>)}</div>
          )}
          {call.transcriptStatus === 'done' && !call.transcript && <span className="row-sub">No speech was found in this recording.</span>}
          {(call.transcriptStatus === 'pending' || call.transcriptStatus === 'working') && <span className="row-sub">Writing the transcript… it appears here in a minute.</span>}
          {call.transcriptStatus === 'failed' && (
            <span className="row-sub">The transcript couldn’t be made. <button type="button" className="link-btn" onClick={retryTranscript}>Try again</button></span>
          )}
        </div>
      )}
      {call.hasRecording && !call.transcriptStatus && (
        <button type="button" className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={retryTranscript}>Write a transcript</button>
      )}
      {vm?.transcript && (
        <div className="transcript">
          <span className="eyebrow">Transcript{vm.lang === 'fa' ? ' · Farsi' : ''}</span>
          <p dir={vm.lang === 'fa' ? 'rtl' : 'auto'} lang={vm.lang || undefined}>{vm.transcript}</p>
        </div>
      )}

      <label className="field">Team note
        <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} onBlur={saveNote} placeholder="Add a note for the team…" />
      </label>

      <div className="actions">
        {call.number && (
          <button type="button" className="btn primary" onClick={() => dial(call.number)}><IPhone size={16} sw={2} /> Call back</button>
        )}
        {call.number && !call.contact && (
          <button type="button" className="btn" onClick={() => setEditContact(true)}><IUser size={16} /> Save as customer</button>
        )}
        {call.contact && (
          <button type="button" className="btn" onClick={() => setEditContact(true)}><IEdit size={16} /> Edit customer</button>
        )}
      </div>
      {!me?.canHearRecordings && call.direction === 'in' && call.status === 'answered' && (
        <span className="row-sub">Call recordings are visible to admins.</span>
      )}
      {editContact && (
        <ContactModal contact={call.contact} presetPhone={call.number} onClose={() => setEditContact(false)} onSaved={() => onChanged?.()} />
      )}
    </section>
  );
}
