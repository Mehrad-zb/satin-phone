import { useState } from 'react';
import { post, patch, del } from '../api.js';
import { toast } from '../store.js';
import { Modal } from '../ui.jsx';
import { fmtTyping } from '../format.js';

/** Add or edit a customer (name shown when they call). */
export default function ContactModal({ contact, presetPhone = '', onClose, onSaved }) {
  const [f, setF] = useState({
    name: contact?.name || '',
    phone: (contact?.phone || presetPhone || '').replace(/\D/g, '').replace(/^1(\d{10})$/, '$1'),
    company: contact?.company || '',
    notes: contact?.notes || '',
  });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: k === 'phone' ? e.target.value.replace(/\D/g, '').slice(0, 11) : e.target.value });

  const save = async (e) => {
    e?.preventDefault();
    setBusy(true);
    try {
      const res = contact?.id ? await patch(`/api/contacts/${contact.id}`, f) : await post('/api/contacts', f);
      toast(contact?.id ? 'Customer updated' : 'Customer saved — their name will show when they call');
      onSaved?.(res.contact);
      onClose();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };
  const remove = async () => {
    if (!window.confirm(`Remove ${contact.name} from customers?`)) return;
    try { await del(`/api/contacts/${contact.id}`); onSaved?.(null); onClose(); } catch (err) { toast(err.message, 'error'); }
  };

  return (
    <Modal title={contact?.id ? 'Edit customer' : 'New customer'} onClose={onClose}
      footer={<>
        {contact?.id && <button type="button" className="btn" style={{ marginRight: 'auto', color: 'var(--red)' }} onClick={remove}>Remove</button>}
        <button type="button" className="btn" onClick={onClose}>Cancel</button>
        <button type="button" className="btn primary" disabled={busy || !f.name || f.phone.length < 7} onClick={save}>Save</button>
      </>}>
      <form onSubmit={save} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <label className="field">Name<input autoFocus value={f.name} onChange={set('name')} placeholder="e.g. Daniel R." /></label>
        <label className="field">Phone<input inputMode="tel" value={fmtTyping(f.phone)} onChange={set('phone')} placeholder="(416) 555-0148" /></label>
        <label className="field">Company or vehicle <small>(optional)</small><input value={f.company} onChange={set('company')} placeholder="e.g. Tesla Model Y" /></label>
        <label className="field">Notes <small>(optional)</small><textarea rows={3} value={f.notes} onChange={set('notes')} placeholder="Job details, quote, anything the team should know" /></label>
        <button type="submit" hidden />
      </form>
    </Modal>
  );
}
