// Formatting helpers shared by the pages.
export const digits = (s) => String(s ?? '').replace(/[^0-9*#+]/g, '');

export function fmtPhone(input) {
  let d = String(input ?? '').replace(/\D/g, '');
  if (d.length === 11 && d.startsWith('1')) d = d.slice(1);
  if (d.length === 10) return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
  return String(input ?? '');
}

/** Formats while typing: 905 → 905, 9059 → (905) 9, … */
export function fmtTyping(raw) {
  const s = String(raw ?? '');
  if (/[^0-9]/.test(s)) return s;
  if (s.length <= 3) return s;
  if (s.length <= 6) return `(${s.slice(0, 3)}) ${s.slice(3)}`;
  if (s.length <= 10) return `(${s.slice(0, 3)}) ${s.slice(3, 6)}-${s.slice(6)}`;
  return s;
}

export function dur(sec) {
  const s = Math.max(0, Math.round(sec || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = String(s % 60).padStart(2, '0');
  return h ? `${h}:${String(m).padStart(2, '0')}:${r}` : `${m}:${r}`;
}

const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

export function timeLabel(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const now = new Date();
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (sameDay(d, now)) return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  if (sameDay(d, y)) return 'Yesterday';
  if (now - d < 6 * 864e5) return d.toLocaleDateString([], { weekday: 'long' });
  return d.toLocaleDateString([], { month: 'short', day: 'numeric', ...(d.getFullYear() !== now.getFullYear() ? { year: 'numeric' } : {}) });
}

export function fullTime(ts) {
  if (!ts) return '';
  return new Date(ts).toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}

export function dayGroup(ts) {
  const d = new Date(ts);
  const now = new Date();
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (sameDay(d, now)) return 'Today';
  if (sameDay(d, y)) return 'Yesterday';
  return d.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' });
}

export function initials(name) {
  const parts = String(name || '').replace(/[^\p{L}\p{N}\s]/gu, ' ').trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '';
  return (parts[0][0] + (parts[1]?.[0] || '')).toUpperCase();
}

export function callTitle(c) {
  if (c.test) return 'Test call';
  return c.contact?.name || (c.number ? c.numberFormatted : 'Unknown caller');
}

export function callKind(c) {
  if (c.status === 'ringing') return { key: c.direction === 'out' ? 'out' : 'in', label: c.direction === 'out' ? 'Calling…' : 'Ringing now' };
  if (c.status === 'active') return { key: c.direction === 'out' ? 'out' : 'in', label: c.answeredBy ? `On a call · ${c.answeredBy.userName}` : 'On a call now' };
  if (c.direction === 'out') {
    const map = { answered: `Outgoing · ${dur(c.talk)}`, noanswer: 'No answer', busy: 'Busy', cancelled: 'Cancelled', failed: 'Didn’t go through' };
    return { key: 'out', label: map[c.status] || 'Outgoing' };
  }
  if (c.status === 'answered') return { key: 'in', label: `Incoming · ${dur(c.talk)}` };
  if (c.status === 'voicemail') return { key: 'vm', label: 'Voicemail' };
  return { key: 'missed', label: 'Missed' };
}

export const LANG = { en: 'EN', fa: 'FA' };
