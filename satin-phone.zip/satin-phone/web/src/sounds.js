// Ringtone and key-press sounds made with Web Audio (no audio files needed).
let ctx = null;
const audio = () => {
  if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return ctx;
};

/** Call once from a click so browsers allow sound later. */
export function unlockAudio() { try { audio(); } catch { /* not supported */ } }

function tone(freqs, start, length, gain = 0.12) {
  const ac = audio();
  const g = ac.createGain();
  g.gain.setValueAtTime(0, start);
  g.gain.linearRampToValueAtTime(gain, start + 0.02);
  g.gain.setValueAtTime(gain, start + length - 0.05);
  g.gain.linearRampToValueAtTime(0, start + length);
  g.connect(ac.destination);
  for (const f of freqs) {
    const o = ac.createOscillator();
    o.type = 'sine';
    o.frequency.value = f;
    o.connect(g);
    o.start(start);
    o.stop(start + length + 0.02);
  }
}

let ringTimer = null;
export function startRinging() {
  stopRinging();
  const play = () => {
    try {
      const t = audio().currentTime + 0.02;
      // a soft three-note chime, repeated every 3 s
      tone([659.25, 1318.5], t, 0.22, 0.08);
      tone([783.99, 1567.98], t + 0.25, 0.22, 0.08);
      tone([987.77, 1975.5], t + 0.5, 0.4, 0.08);
    } catch { /* ignore */ }
  };
  play();
  ringTimer = setInterval(play, 3000);
}
export function stopRinging() {
  if (ringTimer) clearInterval(ringTimer);
  ringTimer = null;
}

const DTMF = {
  1: [697, 1209], 2: [697, 1336], 3: [697, 1477], 4: [770, 1209], 5: [770, 1336], 6: [770, 1477],
  7: [852, 1209], 8: [852, 1336], 9: [852, 1477], '*': [941, 1209], 0: [941, 1336], '#': [941, 1477],
};
export function keyTone(k) {
  try { if (DTMF[k]) tone(DTMF[k], audio().currentTime + 0.01, 0.12, 0.05); } catch { /* ignore */ }
}
