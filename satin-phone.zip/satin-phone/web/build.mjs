// Builds the web app into ../server/public (the server serves those files).
//   npm install && npm run build
// Optional env: ESBUILD=<path to esbuild package>, EXTRA_NODE_PATH=<dir with react>, SIPJS_SRC=<SIP.js src/index.ts>
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.resolve(here, '../server/public');
const esbuild = await import(process.env.ESBUILD ? pathToFileURL(path.join(process.env.ESBUILD, 'lib/main.js')).href : 'esbuild');
const build = Date.now().toString(36);

fs.mkdirSync(out, { recursive: true });
for (const f of fs.readdirSync(out)) fs.rmSync(path.join(out, f), { recursive: true, force: true });

await esbuild.build({
  entryPoints: [path.join(here, 'src/main.jsx')],
  outfile: path.join(out, 'app.js'),
  bundle: true,
  minify: true,
  sourcemap: false,
  format: 'iife',
  target: ['chrome100', 'safari15', 'firefox100'],
  jsx: 'automatic',
  loader: { '.js': 'jsx' },
  define: { 'process.env.NODE_ENV': '"production"' },
  nodePaths: process.env.EXTRA_NODE_PATH ? [process.env.EXTRA_NODE_PATH] : [],
  alias: process.env.SIPJS_SRC ? { 'sip.js': process.env.SIPJS_SRC } : {},
  legalComments: 'none',
  logLevel: 'info',
});

for (const f of fs.readdirSync(path.join(here, 'public'))) {
  let content = fs.readFileSync(path.join(here, 'public', f));
  if (f === 'index.html') content = content.toString().replaceAll('__BUILD__', build);
  fs.writeFileSync(path.join(out, f), content);
}

// PNG icons for phones / home screen (needs "sharp"; skipped if missing)
try {
  const sharp = (await import(process.env.SHARP ? pathToFileURL(path.join(process.env.SHARP, process.env.SHARP_ENTRY || 'lib/index.js')).href : 'sharp')).default;
  const svg = fs.readFileSync(path.join(here, 'public/icon.svg'));
  for (const size of [180, 192, 512]) await sharp(svg).resize(size, size).png().toFile(path.join(out, `icon-${size}.png`));
  // maskable: extra padding so Android's circle crop keeps the whole glyph
  const pad = Buffer.from(fs.readFileSync(path.join(here, 'public/icon.svg'), 'utf8')
    .replace('rx="112"', 'rx="0"').replace('translate(100 100) scale(13)', 'translate(136 136) scale(10)'));
  await sharp(pad).resize(512, 512).png().toFile(path.join(out, 'icon-maskable-512.png'));
} catch (e) {
  console.warn('icons skipped:', e.message);
}
console.log('built →', out);
