// Run:  npm test   (inside server/)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { ontarioHolidays } from '../src/holidays.js';
import { normalizeNumber, formatNumber, sanitizeCallerName } from '../src/phone.js';
import { parseBlock } from '../src/ami.js';
import { buildMessage } from '../src/mailer.js';
import { openDb, DEFAULT_SETTINGS } from '../src/db.js';
import { generateDialplan, generateDevices, generateTrunk } from '../src/asterisk.js';
import { openNow } from '../src/time.js';

test('Ontario holidays 2026', () => {
  const h = Object.fromEntries(ontarioHolidays(2026).map((x) => [x.name, x.date]));
  assert.equal(h['Family Day'], '2026-02-16');
  assert.equal(h['Good Friday'], '2026-04-03');
  assert.equal(h['Victoria Day'], '2026-05-18');
  assert.equal(h['Labour Day'], '2026-09-07');
  assert.equal(h.Thanksgiving, '2026-10-12');
  assert.equal(Object.keys(h).length, 9);
});

test('phone numbers', () => {
  assert.equal(normalizeNumber('+1 (905) 962-6222'), '9059626222');
  assert.equal(formatNumber('19059626222'), '(905) 962-6222');
  assert.equal(sanitizeCallerName('Ali: BMW, (X5)?'), 'Ali BMW X5');
});

test('AMI block parsing keeps repeated keys', () => {
  const m = parseBlock('Response: Success\r\nOutput: a\r\nOutput: b');
  assert.deepEqual(m.Output, ['a', 'b']);
});

test('voicemail email is valid MIME with UTF-8 subject', () => {
  const msg = buildMessage({ from: 'a@b.ca', to: 'c@d.ca', subject: 'پیام صوتی', text: 'hi', attachments: [{ filename: 'v.mp3', contentType: 'audio/mpeg', content: Buffer.from('x') }] });
  assert.match(msg, /Subject: =\?UTF-8\?B\?/);
  assert.match(msg, /Content-Disposition: attachment; filename="v.mp3"/);
});

function tmpDb() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sp-'));
  const db = openDb(dir);
  db.run("INSERT INTO users(name, username, pass, role, ext, created_at) VALUES('Mehrad','mehrad','x','admin','101',0)");
  db.run("INSERT INTO devices(user_id, kind, label, sip_user, sip_pass, created_at) VALUES(1,'web','App','mehrad_web','pw',0)");
  db.run("INSERT INTO devices(user_id, kind, label, sip_user, sip_pass, ring, created_at) VALUES(1,'mobile','Phone','mehrad_m1','pw2',0,0)");
  return db;
}
const env = { timezone: 'America/Toronto', mainNumber: '9059626222', companyName: 'Satin Auto Wrap',
  dirs: { sounds: '/s', recordings: '/r', voicemail: '/v', coreSounds: '/c' }, voipms: { server: 'toronto1.voip.ms', username: 'u_1', password: 'p' } };
const allPrompts = { greeting: true, closed: true, 'vm-en': true, 'vm-fa': true, 'recnotice-en': true, 'recnotice-fa': true, coreVmIntro: false };

test('dialplan: hours, holidays, ring list, blocking', () => {
  const db = tmpDb();
  const dp = generateDialplan(db, env, { ...DEFAULT_SETTINGS, closedDates: [`${new Date().getFullYear()}-12-24`] }, allPrompts);
  assert.match(dp, /GotoIfTime\(09:00-16:59,mon,\*,\*,America\/Toronto\?satin-open,s,1\)/);
  assert.match(dp, /GotoIfTime\(10:00-14:59,sat/);
  assert.doesNotMatch(dp, /,sun,\*,\*/);
  assert.match(dp, /GotoIfTime\(\*,\*,24,dec,/);
  assert.match(dp, /Gosub\(satin-addcontacts,s,1\(mehrad_web\)\)/);
  assert.doesNotMatch(dp, /satin-ring[\s\S]*addcontacts,s,1\(mehrad_m1\)[\s\S]*satin-closed/); // ring off for that device
  assert.match(dp, /REGEX\("\^1\(900\|976\|242/);
  assert.match(dp, /exten => 911,1/);
});

test('dialplan: forced closed and no greeting', () => {
  const db = tmpDb();
  const dp = generateDialplan(db, env, { ...DEFAULT_SETTINGS, override: 'closed' }, { ...allPrompts, greeting: false });
  assert.match(dp, /Goto\(satin-closed,s,1\)  ; forced CLOSED/);
  assert.match(dp, /no greeting recorded yet/);
});

test('devices and trunk config', () => {
  const db = tmpDb();
  const dev = generateDevices(db);
  assert.match(dev, /\[mehrad_web\]\ntype = endpoint[\s\S]*webrtc = yes/);
  assert.match(dev, /\[mehrad_m1\]\ntype = endpoint[\s\S]*media_encryption = sdes/);
  const trunk = generateTrunk(env);
  assert.match(trunk, /server_uri = sip:toronto1\.voip\.ms:5060/);
  assert.match(trunk, /match = toronto1\.voip\.ms/);
});

test('open now', () => {
  const s = DEFAULT_SETTINGS;
  // Tuesday 2026-10-13 14:00 Toronto = 18:00 UTC
  assert.equal(openNow(s, [], 'America/Toronto', new Date('2026-10-13T18:00:00Z')).open, true);
  // Sunday
  assert.equal(openNow(s, [], 'America/Toronto', new Date('2026-10-18T18:00:00Z')).open, false);
  // holiday
  assert.equal(openNow(s, ['2026-10-12'], 'America/Toronto', new Date('2026-10-12T18:00:00Z')).open, false);
});

test('dialplan: department menu, direct extensions, department tag', () => {
  const db = tmpDb();
  db.run("INSERT INTO users(name, username, pass, role, ext, created_at) VALUES('Parisa','parisa','x','staff','102',0)");
  db.run("INSERT INTO devices(user_id, kind, label, sip_user, sip_pass, created_at) VALUES(2,'web','App','parisa_web','pw',0)");
  const settings = { ...DEFAULT_SETTINGS, departments: [
    { digit: '1', name: 'Sales', members: [1] },
    { digit: '2', name: 'Design team', members: [2] },
    { digit: '3', name: 'Management', members: [] },
  ] };
  const dp = generateDialplan(db, env, settings, { ...allPrompts, 'menu-en': true, 'menu-fa': true });
  // language menu leads to the department menu
  assert.match(dp, /exten => 1,1,Set\(__SATIN_LANG=en\)\n same => n,Goto\(satin-menu,s,1\)/);
  // department digits and extensions are offered in the menu
  const menu = dp.slice(dp.indexOf('[satin-menu]'), dp.indexOf('[satin-ring]'));
  assert.match(menu, /exten => 2,1,Goto\(satin-dept-2,s,1\)/);
  assert.match(menu, /exten => 102,1,Goto\(satin-person-102,s,1\)/);
  assert.match(menu, /Background\(\/s\/menu-fa\)/);
  // design rings only Parisa, management rings everyone
  const design = dp.slice(dp.indexOf('[satin-dept-2]'), dp.indexOf('[satin-dept-3]'));
  assert.match(design, /parisa_web/);
  assert.doesNotMatch(design, /mehrad_web/);
  assert.match(design, /Set\(__SATIN_DEPT=d2\)/);
  const mgmt = dp.slice(dp.indexOf('[satin-dept-3]'), dp.indexOf('[satin-person-101]'));
  assert.match(mgmt, /mehrad_web/);
  assert.match(mgmt, /parisa_web/);
  // the hangup event carries the department
  assert.match(dp, /Dept: \$\{SATIN_DEPT\}/);
});

test('dialplan: no menu recording means ring everyone', () => {
  const db = tmpDb();
  const dp = generateDialplan(db, env, DEFAULT_SETTINGS, allPrompts);
  assert.match(dp, /\[satin-menu\]\nexten => s,1,Goto\(satin-ring,s,1\)/);
});

test('database migration adds transcript columns', () => {
  const db = tmpDb();
  const cols = db.all('PRAGMA table_info(calls)').map((c) => c.name);
  for (const c of ['dept', 'transcript', 'transcript_status']) assert.ok(cols.includes(c));
});
