// Small SMTP client (STARTTLS or implicit TLS, AUTH PLAIN/LOGIN) for voicemail emails.
import net from 'node:net';
import tls from 'node:tls';
import os from 'node:os';
import crypto from 'node:crypto';

class SmtpConn {
  constructor(socket) { this.attach(socket); }
  attach(socket) {
    if (this.socket) this.socket.removeAllListeners('data');
    this.socket = socket;
    this.buf = '';
    this.waiters = [];
    socket.on('data', (d) => { this.buf += d.toString('utf8'); this.#pump(); });
    socket.on('error', (e) => { for (const w of this.waiters) w.reject(e); this.waiters = []; });
  }
  #pump() {
    while (this.waiters.length) {
      const lines = [];
      let rest = this.buf;
      let done = null;
      for (;;) {
        const i = rest.indexOf('\r\n');
        if (i < 0) break;
        const line = rest.slice(0, i);
        rest = rest.slice(i + 2);
        lines.push(line);
        if (/^\d{3} /.test(line) || /^\d{3}$/.test(line)) { done = Number(line.slice(0, 3)); break; }
      }
      if (done === null) return;
      this.buf = rest;
      this.waiters.shift().resolve({ code: done, lines });
    }
  }
  read() { return new Promise((resolve, reject) => { this.waiters.push({ resolve, reject }); this.#pump(); }); }
  async cmd(line, expect) {
    if (line !== null) this.socket.write(line + '\r\n');
    const r = await this.read();
    if (expect && !expect.includes(r.code)) throw new Error(`SMTP "${line?.split(' ')[0] ?? 'greeting'}" failed: ${r.lines.join(' ')}`);
    return r;
  }
}

function connect(opts) {
  return new Promise((resolve, reject) => {
    const s = opts.secure
      ? tls.connect({ host: opts.host, port: opts.port, servername: opts.host })
      : net.connect({ host: opts.host, port: opts.port });
    s.setTimeout(30000, () => s.destroy(new Error('SMTP timeout')));
    s.once(opts.secure ? 'secureConnect' : 'connect', () => resolve(s));
    s.once('error', reject);
  });
}

const b64 = (s) => Buffer.from(s, 'utf8').toString('base64');
const wrap76 = (s) => s.replace(/.{1,76}/g, '$&\r\n');
const encodeHeader = (s) => (/^[\x20-\x7e]*$/.test(s) ? s : `=?UTF-8?B?${b64(s)}?=`);

export function buildMessage({ from, to, subject, text, html, attachments = [] }) {
  const mixed = `mix_${crypto.randomBytes(8).toString('hex')}`;
  const alt = `alt_${crypto.randomBytes(8).toString('hex')}`;
  const domain = (from.match(/@([^>\s]+)/) || [])[1] || 'localhost';
  const lines = [
    `From: ${from}`,
    `To: ${[].concat(to).join(', ')}`,
    `Subject: ${encodeHeader(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    `Message-ID: <${crypto.randomUUID()}@${domain}>`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${mixed}"`,
    '',
    `--${mixed}`,
    `Content-Type: multipart/alternative; boundary="${alt}"`,
    '',
    `--${alt}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap76(b64(text || '')),
    `--${alt}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap76(b64(html || `<pre>${text || ''}</pre>`)),
    `--${alt}--`,
  ];
  for (const a of attachments) {
    lines.push(
      `--${mixed}`,
      `Content-Type: ${a.contentType}; name="${a.filename}"`,
      'Content-Transfer-Encoding: base64',
      `Content-Disposition: attachment; filename="${a.filename}"`,
      '',
      wrap76(Buffer.from(a.content).toString('base64')),
    );
  }
  lines.push(`--${mixed}--`, '');
  return lines.join('\r\n');
}

export async function sendMail(smtp, message) {
  if (!smtp.host) throw new Error('SMTP is not configured');
  const sock = await connect(smtp);
  const c = new SmtpConn(sock);
  try {
    await c.cmd(null, [220]);
    let ehlo = await c.cmd(`EHLO ${os.hostname()}`, [250]);
    if (!smtp.secure && ehlo.lines.some((l) => /STARTTLS/i.test(l))) {
      await c.cmd('STARTTLS', [220]);
      const secured = await new Promise((resolve, reject) => {
        const t = tls.connect({ socket: sock, servername: smtp.host }, () => resolve(t));
        t.once('error', reject);
      });
      c.attach(secured);
      ehlo = await c.cmd(`EHLO ${os.hostname()}`, [250]);
    }
    if (smtp.user) {
      const auth = ehlo.lines.join(' ');
      if (/AUTH[ =][^\r\n]*PLAIN/i.test(auth)) {
        await c.cmd(`AUTH PLAIN ${b64(`\0${smtp.user}\0${smtp.pass}`)}`, [235]);
      } else {
        await c.cmd('AUTH LOGIN', [334]);
        await c.cmd(b64(smtp.user), [334]);
        await c.cmd(b64(smtp.pass), [235]);
      }
    }
    const fromAddr = (smtp.from.match(/<([^>]+)>/) || [null, smtp.from])[1];
    await c.cmd(`MAIL FROM:<${fromAddr}>`, [250]);
    for (const rcpt of [].concat(message.to)) {
      const addr = (rcpt.match(/<([^>]+)>/) || [null, rcpt])[1].trim();
      await c.cmd(`RCPT TO:<${addr}>`, [250, 251]);
    }
    await c.cmd('DATA', [354]);
    const data = buildMessage({ ...message, from: smtp.from }).replace(/\r\n\./g, '\r\n..');
    await c.cmd(`${data}\r\n.`, [250]);
    await c.cmd('QUIT', [221]).catch(() => {});
  } finally {
    c.socket.destroy();
  }
}
