// REST API used by the Satin Phone web app (and, with the API key, by the website admin panel).
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { Router, HttpError, readJson, readBody, sendFile } from './http.js';
import {
  COOKIE, createSession, destroySession, hashPassword, verifyPassword, publicUser, sessionCookie,
  loginAllowed, loginFailed, loginSucceeded, randomSecret,
} from './auth.js';
import { applyConfig, promptStatus, PROMPTS, closedDatesFor, setCallerName, syncCallerNames } from './asterisk.js';
import { callView, voicemailView, contactFor } from './calls.js';
import { normalizeNumber, formatNumber } from './phone.js';
import { convertPrompt } from './audio.js';
import { ontarioHolidays } from './holidays.js';
import { startOfDay, openNow } from './time.js';
import { sendMail } from './mailer.js';

const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
const isTime = (t) => typeof t === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(t);
const isEmailList = (s) => typeof s === 'string' && s.split(',').every((e) => !e.trim() || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e.trim()));
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 20) || 'user';

export function buildApi(ctx) {
  const { db, env, ami } = ctx;
  const r = new Router();
  const admin = { role: 'admin' };
  const pub = { public: true };

  const reconfigure = () => applyConfig(ctx).catch((e) => ctx.log.error?.(`[asterisk] ${e.message}`));
  const thisYear = () => Number(new Intl.DateTimeFormat('en-CA', { timeZone: env.timezone, year: 'numeric' }).format(new Date()));

  function webDevice(user) {
    let d = db.get("SELECT * FROM devices WHERE user_id = ? AND kind = 'web' ORDER BY id LIMIT 1", user.id);
    if (!d) {
      const sipUser = uniqueSipUser(`${slug(user.username)}_web`);
      db.run("INSERT INTO devices(user_id, kind, label, sip_user, sip_pass, created_at) VALUES(?, 'web', 'Satin Phone app', ?, ?, ?)",
        user.id, sipUser, randomSecret(18), Date.now());
      d = db.get("SELECT * FROM devices WHERE user_id = ? AND kind = 'web' ORDER BY id LIMIT 1", user.id);
      reconfigure();
    }
    return d;
  }

  function uniqueSipUser(base) {
    let name = base;
    for (let i = 2; db.get('SELECT 1 FROM devices WHERE sip_user = ?', name); i++) name = `${base}${i}`;
    return name;
  }

  const canHearRecordings = (user) => user.role === 'admin' || db.getSettings().recordingsVisibleTo === 'all';

  // ------------------------------------------------------------ auth
  r.get('/api/health', () => ({ ok: true, asterisk: ami.connected }), pub);

  r.post('/api/auth/login', async ({ req, res }) => {
    const body = await readJson(req);
    // nginx appends the real client address last, so a spoofed header can't dodge the limit
    const ip = String(req.headers['x-forwarded-for'] || '').split(',').pop().trim() || req.socket.remoteAddress;
    const key = `${ip}|${String(body.username || '').toLowerCase()}`;
    if (!loginAllowed(key)) throw new HttpError(429, 'Too many attempts. Try again in 10 minutes.');
    const u = db.get('SELECT * FROM users WHERE username = ? AND active = 1', String(body.username || '').trim());
    if (!u || !verifyPassword(body.password || '', u.pass)) {
      loginFailed(key);
      throw new HttpError(401, 'Wrong username or password');
    }
    loginSucceeded(key);
    const token = createSession(db, u.id, req.headers['user-agent']);
    res.setHeader('Set-Cookie', sessionCookie(token, env.cookieSecure));
    return { user: publicUser(u) };
  }, pub);

  r.post('/api/auth/logout', ({ req, res, cookies }) => {
    destroySession(db, cookies[COOKIE]);
    res.setHeader('Set-Cookie', sessionCookie('', env.cookieSecure, 0));
    return { ok: true };
  }, pub);

  // ------------------------------------------------------------ me
  // Which relay (if any) this request came through: the relay sets X-Satin-Relay to its own host name.
  const relayFor = (req) => {
    const h = String(req.headers['x-satin-relay'] || '').trim().toLowerCase();
    return h && env.relayHosts.includes(h) ? h : null;
  };
  const turnFor = (relay, who) => {
    const username = `${Math.floor(Date.now() / 1000) + env.turnTtlHours * 3600}:${who}`;
    const credential = crypto.createHmac('sha1', env.turnSecret).update(username).digest('base64');
    return [{
      urls: [`turn:${relay}:3478?transport=udp`, `turn:${relay}:3478?transport=tcp`, `turns:${relay}:5349?transport=tcp`],
      username, credential,
    }];
  };

  r.get('/api/me', ({ req, user }) => {
    const d = user.id ? webDevice(user) : null;
    const relay = relayFor(req);
    const viaTurn = !!(relay && env.turnSecret && d);
    const settings = db.getSettings();
    return {
      user: publicUser(user),
      company: env.companyName,
      mainNumber: env.mainNumber,
      mainNumberFormatted: formatNumber(env.mainNumber),
      canHearRecordings: canHearRecordings(user),
      business: openNow(settings, closedDatesFor(settings, thisYear()), env.timezone),
      sip: d ? {
        username: d.sip_user,
        password: d.sip_pass,
        domain: env.sipDomain,
        wsUrl: relay ? `wss://${relay}/sip` : env.sipWsUrl,
        displayName: user.name,
        iceServers: viaTurn ? turnFor(relay, d.sip_user) : env.stunServers.map((u) => ({ urls: u })),
        iceTransportPolicy: viaTurn ? 'relay' : 'all',
      } : null,
      relay,
    };
  });

  r.patch('/api/me', async ({ req, user }) => {
    const body = await readJson(req);
    if (body.status !== undefined) {
      if (!['available', 'dnd'].includes(body.status)) throw new HttpError(400, 'Status must be available or dnd');
      db.run('UPDATE users SET status = ? WHERE id = ?', body.status, user.id);
      reconfigure();
    }
    return { user: publicUser(db.get('SELECT * FROM users WHERE id = ?', user.id)) };
  });

  // Everyone can see the team list (for transfers and internal calls).
  r.get('/api/directory', () => ({
    people: db.all('SELECT * FROM users WHERE active = 1 ORDER BY ext').map((u) => {
      const devs = db.all('SELECT sip_user FROM devices WHERE user_id = ?', u.id);
      return { id: u.id, name: u.name, ext: u.ext, status: u.status, online: devs.some((d) => ctx.presence.online(d.sip_user)) };
    }),
  }));

  r.post('/api/me/password', async ({ req, user }) => {
    const { current, next } = await readJson(req);
    if (!verifyPassword(current || '', user.pass)) throw new HttpError(400, 'Your current password is not right');
    if (!next || String(next).length < 8) throw new HttpError(400, 'Use at least 8 characters');
    db.run('UPDATE users SET pass = ? WHERE id = ?', hashPassword(next), user.id);
    return { ok: true };
  });

  // ------------------------------------------------------------ calls
  r.get('/api/calls', ({ query, user }) => {
    const where = [];
    const p = [];
    const f = query.get('filter') || 'all';
    if (f === 'missed') where.push("c.status = 'missed'");
    else if (f === 'voicemail') where.push("c.status = 'voicemail'");
    else if (f === 'recorded') where.push('c.recording IS NOT NULL');
    else if (f === 'in') where.push("c.direction = 'in'");
    else if (f === 'out') where.push("c.direction = 'out'");
    const q = (query.get('q') || '').trim();
    if (q) {
      const digits = q.replace(/\D/g, '');
      const parts = ['k.name LIKE ?', 'k.company LIKE ?', 'c.note LIKE ?', 'c.dept LIKE ?'];
      p.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`);
      if (canHearRecordings(user)) { parts.push('c.transcript LIKE ?'); p.push(`%${q}%`); }
      if (digits.length >= 3) { parts.push('c.from_num LIKE ?', 'c.to_num LIKE ?'); p.push(`%${digits}%`, `%${digits}%`); }
      where.push(`(${parts.join(' OR ')})`);
    }
    const before = Number(query.get('before')) || 0;
    if (before) { where.push('c.started_at < ?'); p.push(before); }
    const limit = Math.min(Number(query.get('limit')) || 50, 200);
    const rows = db.all(`SELECT c.* FROM calls c
      LEFT JOIN contacts k ON k.phone = CASE c.direction WHEN 'out' THEN c.to_num ELSE c.from_num END
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY c.started_at DESC LIMIT ?`, ...p, limit);
    const calls = rows.map((row) => callView(db, row));
    if (!canHearRecordings(user)) for (const c of calls) { c.hasRecording = false; c.transcript = null; c.transcriptStatus = null; }
    return { calls, counts: counts() };
  });

  function counts() {
    const g = (sql) => db.get(sql).n;
    return {
      all: g('SELECT COUNT(*) n FROM calls'),
      missed: g("SELECT COUNT(*) n FROM calls WHERE status = 'missed'"),
      voicemail: g("SELECT COUNT(*) n FROM calls WHERE status = 'voicemail'"),
      recorded: g('SELECT COUNT(*) n FROM calls WHERE recording IS NOT NULL'),
    };
  }

  r.get('/api/calls/:id', ({ params, user }) => {
    const row = db.get('SELECT * FROM calls WHERE id = ?', params.id);
    if (!row) throw new HttpError(404, 'Call not found');
    const view = callView(db, row);
    if (!canHearRecordings(user)) { view.hasRecording = false; view.transcript = null; view.transcriptStatus = null; }
    const vm = row.voicemail_id ? db.get('SELECT * FROM voicemails WHERE id = ? AND deleted = 0', row.voicemail_id) : null;
    return { call: view, voicemail: voicemailView(db, vm) };
  });

  r.patch('/api/calls/:id', async ({ req, params }) => {
    const body = await readJson(req);
    if (typeof body.note === 'string') db.run('UPDATE calls SET note = ? WHERE id = ?', body.note.slice(0, 2000), params.id);
    const view = callView(db, db.get('SELECT * FROM calls WHERE id = ?', params.id));
    ctx.hub.broadcast('call.updated', view);
    return { call: view };
  });

  r.post('/api/calls/:id/transcribe', async ({ params, user }) => {
    if (!canHearRecordings(user)) throw new HttpError(403, 'Only admins can see call transcripts');
    if (!env.openaiKey) throw new HttpError(400, 'Add an OpenAI API key on the server to turn on transcripts');
    const row = db.get('SELECT recording FROM calls WHERE id = ?', params.id);
    if (!row?.recording) throw new HttpError(404, 'This call has no recording');
    ctx.calls.transcribeCall(params.id).catch((e) => ctx.log.warn?.(`[transcript] ${e.message}`));
    return { ok: true };
  });

  r.get('/api/calls/:id/recording', ({ req, res, params, user }) => {
    if (!canHearRecordings(user)) throw new HttpError(403, 'Only admins can listen to recordings');
    const row = db.get('SELECT recording FROM calls WHERE id = ?', params.id);
    if (!row?.recording) throw new HttpError(404, 'No recording');
    sendFile(req, res, path.join(env.dirs.recordings, path.basename(row.recording)), { type: 'audio/wav' });
  });

  r.post('/api/calls/test', async ({ user }) => {
    if (!user.id) throw new HttpError(400, 'Use a team account for test calls');
    await ami.action({
      Action: 'Originate', Channel: `Local/${user.ext}@satin-users/n`, Context: 'satin-test', Exten: 's', Priority: 1,
      CallerID: `"Test call" <${env.mainNumber}>`, Async: 'true', Timeout: 30000,
    });
    return { ok: true, message: 'Your devices will ring. Answer to hear the call flow as a customer does.' };
  });

  r.get('/api/stats', () => {
    const since = startOfDay(env.timezone);
    const today = db.get(`SELECT COUNT(*) calls, SUM(CASE WHEN status = 'missed' THEN 1 ELSE 0 END) missed,
      COALESCE(SUM(talk), 0) talk FROM calls WHERE started_at >= ? AND test = 0`, since);
    const vm = db.get('SELECT COUNT(*) n FROM voicemails WHERE listened = 0 AND deleted = 0').n;
    return { calls: today.calls || 0, missed: today.missed || 0, talk: today.talk || 0, newVoicemails: vm };
  });

  r.get('/api/live', () => ({ calls: ctx.calls.live(), presence: ctx.presence.snapshot() }));

  // ------------------------------------------------------------ voicemail
  r.get('/api/voicemails', ({ query }) => {
    const onlyNew = query.get('filter') === 'new';
    const rows = db.all(`SELECT * FROM voicemails WHERE deleted = 0 ${onlyNew ? 'AND listened = 0' : ''} ORDER BY created_at DESC LIMIT 200`);
    return { voicemails: rows.map((v) => voicemailView(db, v)) };
  });

  r.get('/api/voicemails/:id/audio', ({ req, res, params }) => {
    const v = db.get('SELECT * FROM voicemails WHERE id = ? AND deleted = 0', Number(params.id));
    if (!v) throw new HttpError(404, 'Voicemail not found');
    sendFile(req, res, path.join(env.dirs.voicemail, path.basename(v.file)), { type: 'audio/wav' });
  });

  r.patch('/api/voicemails/:id', async ({ req, params }) => {
    const body = await readJson(req);
    if (typeof body.listened === 'boolean') db.run('UPDATE voicemails SET listened = ? WHERE id = ?', body.listened ? 1 : 0, Number(params.id));
    const view = voicemailView(db, db.get('SELECT * FROM voicemails WHERE id = ?', Number(params.id)));
    ctx.hub.broadcast('voicemail.updated', view);
    return { voicemail: view };
  });

  r.delete('/api/voicemails/:id', ({ params }) => {
    const v = db.get('SELECT * FROM voicemails WHERE id = ?', Number(params.id));
    if (!v) throw new HttpError(404, 'Voicemail not found');
    fs.rmSync(path.join(env.dirs.voicemail, path.basename(v.file)), { force: true });
    db.run('UPDATE voicemails SET deleted = 1 WHERE id = ?', v.id);
    ctx.hub.broadcast('voicemail.deleted', { id: v.id });
    return { ok: true };
  });

  // ------------------------------------------------------------ customers (contacts)
  const contactBody = (b, partial = false) => {
    const out = {};
    if (!partial || b.name !== undefined) {
      out.name = String(b.name || '').trim().slice(0, 80);
      if (!out.name) throw new HttpError(400, 'Name is required');
    }
    if (!partial || b.phone !== undefined) {
      out.phone = normalizeNumber(b.phone);
      if (out.phone.length < 7) throw new HttpError(400, 'Enter a valid phone number');
    }
    if (b.company !== undefined) out.company = String(b.company || '').trim().slice(0, 80);
    if (b.notes !== undefined) out.notes = String(b.notes || '').slice(0, 2000);
    return out;
  };

  r.get('/api/contacts', ({ query }) => {
    const q = (query.get('q') || '').trim();
    const digits = q.replace(/\D/g, '');
    const rows = q
      ? db.all(`SELECT * FROM contacts WHERE name LIKE ? OR company LIKE ? ${digits.length >= 3 ? 'OR phone LIKE ?' : ''} ORDER BY name LIMIT 300`,
        `%${q}%`, `%${q}%`, ...(digits.length >= 3 ? [`%${digits}%`] : []))
      : db.all('SELECT * FROM contacts ORDER BY name LIMIT 1000');
    return { contacts: rows.map((c) => ({ ...c, phoneFormatted: formatNumber(c.phone) })) };
  });

  r.post('/api/contacts', async ({ req }) => {
    const b = contactBody(await readJson(req));
    if (db.get('SELECT 1 FROM contacts WHERE phone = ?', b.phone)) throw new HttpError(409, 'A customer with this number already exists');
    const res = db.run('INSERT INTO contacts(name, phone, company, notes, updated_at) VALUES(?, ?, ?, ?, ?)',
      b.name, b.phone, b.company || '', b.notes || '', Date.now());
    await setCallerName(ctx, b.phone, b.company ? `${b.name} - ${b.company}` : b.name).catch(() => {});
    return { contact: db.get('SELECT * FROM contacts WHERE id = ?', Number(res.lastInsertRowid)) };
  });

  r.patch('/api/contacts/:id', async ({ req, params }) => {
    const old = db.get('SELECT * FROM contacts WHERE id = ?', Number(params.id));
    if (!old) throw new HttpError(404, 'Customer not found');
    const b = { ...old, ...contactBody(await readJson(req), true) };
    const clash = db.get('SELECT id FROM contacts WHERE phone = ? AND id != ?', b.phone, old.id);
    if (clash) throw new HttpError(409, 'Another customer already has this number');
    db.run('UPDATE contacts SET name = ?, phone = ?, company = ?, notes = ?, updated_at = ? WHERE id = ?',
      b.name, b.phone, b.company, b.notes, Date.now(), old.id);
    if (old.phone !== b.phone) await setCallerName(ctx, old.phone, null).catch(() => {});
    await setCallerName(ctx, b.phone, b.company ? `${b.name} - ${b.company}` : b.name).catch(() => {});
    return { contact: db.get('SELECT * FROM contacts WHERE id = ?', old.id) };
  });

  r.delete('/api/contacts/:id', async ({ params }) => {
    const old = db.get('SELECT * FROM contacts WHERE id = ?', Number(params.id));
    if (!old) throw new HttpError(404, 'Customer not found');
    db.run('DELETE FROM contacts WHERE id = ?', old.id);
    await setCallerName(ctx, old.phone, null).catch(() => {});
    return { ok: true };
  });

  // ------------------------------------------------------------ settings & call flow
  function settingsView() {
    const settings = db.getSettings();
    const year = thisYear();
    return {
      settings,
      prompts: promptStatus(env),
      promptLabels: PROMPTS,
      transcriptsAvailable: !!env.openaiKey,
      team: db.all('SELECT id, name, ext FROM users WHERE active = 1 ORDER BY ext'),
      holidays: ontarioHolidays(year),
      closedDates: closedDatesFor(settings, year),
      business: openNow(settings, closedDatesFor(settings, year), env.timezone),
      timezone: env.timezone,
      mainNumberFormatted: formatNumber(env.mainNumber),
    };
  }

  r.get('/api/settings', () => settingsView());

  r.put('/api/settings', async ({ req }) => {
    const b = await readJson(req);
    const patch = {};
    if (b.hours !== undefined) {
      const hours = {};
      for (const d of DAYS) {
        const h = b.hours?.[d];
        if (!h) throw new HttpError(400, `Missing hours for ${d}`);
        if (!isTime(h.from) || !isTime(h.to)) throw new HttpError(400, `Times for ${d} must look like 09:00`);
        if (h.open && h.to <= h.from) throw new HttpError(400, `Closing time for ${d} must be after opening time`);
        hours[d] = { open: !!h.open, from: h.from, to: h.to };
      }
      patch.hours = hours;
    }
    const bools = ['closeOnHolidays', 'languageMenu', 'recordCalls', 'recordOutgoing', 'recordingNotice', 'transcribe', 'allowInternational',
      'departmentMenu', 'dialByExtension', 'transcribeCalls'];
    for (const k of bools) if (b[k] !== undefined) patch[k] = !!b[k];
    if (b.override !== undefined) {
      if (!['auto', 'open', 'closed'].includes(b.override)) throw new HttpError(400, 'Invalid override');
      patch.override = b.override;
    }
    if (b.defaultLanguage !== undefined) patch.defaultLanguage = b.defaultLanguage === 'fa' ? 'fa' : 'en';
    if (b.ringSeconds !== undefined) patch.ringSeconds = Math.min(Math.max(Number(b.ringSeconds) || 25, 10), 90);
    if (b.menuTimeout !== undefined) patch.menuTimeout = Math.min(Math.max(Number(b.menuTimeout) || 5, 2), 15);
    if (b.retentionDays !== undefined) patch.retentionDays = Math.min(Math.max(Number(b.retentionDays) || 365, 7), 3650);
    if (b.recordingsVisibleTo !== undefined) patch.recordingsVisibleTo = b.recordingsVisibleTo === 'all' ? 'all' : 'admin';
    if (b.voicemailEmail !== undefined) {
      if (!isEmailList(b.voicemailEmail)) throw new HttpError(400, 'Enter a valid email address');
      patch.voicemailEmail = String(b.voicemailEmail).trim();
    }
    if (b.closedDates !== undefined) {
      if (!Array.isArray(b.closedDates) || b.closedDates.length > 200 || !b.closedDates.every((d) => /^\d{4}-\d{2}-\d{2}$/.test(d))) {
        throw new HttpError(400, 'Closed dates must look like 2026-12-24');
      }
      patch.closedDates = [...new Set(b.closedDates)].sort();
    }
    if (b.departments !== undefined) {
      if (!Array.isArray(b.departments) || b.departments.length > 9) throw new HttpError(400, 'Up to 9 menu options');
      const userIds = new Set(db.all('SELECT id FROM users').map((u) => u.id));
      const digits = new Set();
      patch.departments = b.departments.map((d, i) => {
        const digit = String(d?.digit ?? '').trim();
        const name = String(d?.name ?? '').trim().slice(0, 40);
        if (!/^[1-9]$/.test(digit)) throw new HttpError(400, `Option ${i + 1}: pick a key from 1 to 9`);
        if (digits.has(digit)) throw new HttpError(400, `Key ${digit} is used twice`);
        if (!name) throw new HttpError(400, `Key ${digit}: give it a name`);
        digits.add(digit);
        const members = [...new Set((Array.isArray(d.members) ? d.members : []).map(Number))].filter((id) => userIds.has(id));
        return { digit, name, members };
      }).sort((a, b2) => a.digit.localeCompare(b2.digit));
    }
    db.saveSettings(patch);
    await reconfigure();
    const view = settingsView();
    ctx.hub.broadcast('settings.changed', { business: view.business });
    return view;
  }, admin);

  r.get('/api/prompts/:name/audio', ({ req, res, params }) => {
    if (!PROMPTS[params.name]) throw new HttpError(404, 'Unknown prompt');
    sendFile(req, res, path.join(env.dirs.sounds, `${params.name}.wav`), { type: 'audio/wav' });
  });

  r.put('/api/prompts/:name', async ({ req, params }) => {
    if (!PROMPTS[params.name]) throw new HttpError(404, 'Unknown prompt');
    const buf = await readBody(req, 25 * 1024 * 1024);
    if (buf.length < 500) throw new HttpError(400, 'The recording is empty');
    let seconds;
    try {
      seconds = await convertPrompt(env.ffmpeg, buf, path.join(env.dirs.sounds, `${params.name}.wav`));
    } catch (e) {
      throw new HttpError(400, e.message);
    }
    await reconfigure();
    return { ok: true, seconds, ...settingsView() };
  }, admin);

  r.delete('/api/prompts/:name', async ({ params }) => {
    if (!PROMPTS[params.name]) throw new HttpError(404, 'Unknown prompt');
    fs.rmSync(path.join(env.dirs.sounds, `${params.name}.wav`), { force: true });
    await reconfigure();
    return settingsView();
  }, admin);

  // ------------------------------------------------------------ team & devices
  function teamView() {
    const users = db.all('SELECT * FROM users ORDER BY ext');
    const devices = db.all('SELECT * FROM devices ORDER BY id');
    return {
      sipServer: { domain: env.sipDomain, udpPort: 5060, tlsPort: 5061, tls: fs.existsSync(env.tlsCert) },
      users: users.map((u) => ({
        ...publicUser(u),
        devices: devices.filter((d) => d.user_id === u.id).map((d) => ({
          id: d.id, kind: d.kind, label: d.label, ring: !!d.ring, sipUser: d.sip_user,
          online: ctx.presence.online(d.sip_user),
          password: d.kind === 'web' ? undefined : d.sip_pass,
        })),
      })),
    };
  }

  r.get('/api/team', () => teamView(), admin);

  r.post('/api/team/users', async ({ req }) => {
    const b = await readJson(req);
    const name = String(b.name || '').trim().slice(0, 60);
    const username = String(b.username || '').trim().toLowerCase();
    if (!name) throw new HttpError(400, 'Name is required');
    if (!/^[a-z0-9._-]{2,32}$/.test(username)) throw new HttpError(400, 'Username: 2–32 letters, numbers, dots or dashes');
    if (!b.password || String(b.password).length < 8) throw new HttpError(400, 'Password: at least 8 characters');
    if (db.get('SELECT 1 FROM users WHERE username = ?', username)) throw new HttpError(409, 'That username is taken');
    const maxExt = db.get("SELECT MAX(CAST(ext AS INTEGER)) m FROM users").m || 100;
    const ext = String(Math.max(maxExt + 1, 101));
    const res = db.run('INSERT INTO users(name, username, pass, role, ext, created_at) VALUES(?, ?, ?, ?, ?, ?)',
      name, username, hashPassword(b.password), b.role === 'admin' ? 'admin' : 'staff', ext, Date.now());
    webDevice(db.get('SELECT * FROM users WHERE id = ?', Number(res.lastInsertRowid)));
    await reconfigure();
    return teamView();
  }, admin);

  r.patch('/api/team/users/:id', async ({ req, params, user }) => {
    const u = db.get('SELECT * FROM users WHERE id = ?', Number(params.id));
    if (!u) throw new HttpError(404, 'User not found');
    const b = await readJson(req);
    if (b.name !== undefined) db.run('UPDATE users SET name = ? WHERE id = ?', String(b.name).trim().slice(0, 60) || u.name, u.id);
    if (b.role !== undefined) {
      if (u.id === user.id && b.role !== 'admin') throw new HttpError(400, "You can't remove your own admin access");
      db.run('UPDATE users SET role = ? WHERE id = ?', b.role === 'admin' ? 'admin' : 'staff', u.id);
    }
    if (b.active !== undefined) {
      if (u.id === user.id && !b.active) throw new HttpError(400, "You can't turn off your own account");
      db.run('UPDATE users SET active = ? WHERE id = ?', b.active ? 1 : 0, u.id);
      if (!b.active) db.run('DELETE FROM sessions WHERE user_id = ?', u.id);
    }
    if (b.password) {
      if (String(b.password).length < 8) throw new HttpError(400, 'Password: at least 8 characters');
      db.run('UPDATE users SET pass = ? WHERE id = ?', hashPassword(b.password), u.id);
    }
    await reconfigure();
    return teamView();
  }, admin);

  r.delete('/api/team/users/:id', async ({ params, user }) => {
    const id = Number(params.id);
    if (id === user.id) throw new HttpError(400, "You can't delete your own account");
    db.run('DELETE FROM users WHERE id = ?', id);
    await reconfigure();
    return teamView();
  }, admin);

  r.post('/api/team/users/:id/devices', async ({ req, params }) => {
    const u = db.get('SELECT * FROM users WHERE id = ?', Number(params.id));
    if (!u) throw new HttpError(404, 'User not found');
    const b = await readJson(req);
    const kind = b.kind === 'desk' ? 'desk' : 'mobile';
    const label = String(b.label || (kind === 'desk' ? 'Desk phone' : 'Phone')).trim().slice(0, 40);
    const n = db.get('SELECT COUNT(*) n FROM devices WHERE user_id = ?', u.id).n;
    const sipUser = uniqueSipUser(`${slug(u.username)}_${kind === 'desk' ? 'd' : 'm'}${n}`);
    db.run('INSERT INTO devices(user_id, kind, label, sip_user, sip_pass, created_at) VALUES(?, ?, ?, ?, ?, ?)',
      u.id, kind, label, sipUser, randomSecret(18), Date.now());
    await reconfigure();
    return teamView();
  }, admin);

  r.patch('/api/team/devices/:id', async ({ req, params }) => {
    const d = db.get('SELECT * FROM devices WHERE id = ?', Number(params.id));
    if (!d) throw new HttpError(404, 'Device not found');
    const b = await readJson(req);
    if (b.label !== undefined) db.run('UPDATE devices SET label = ? WHERE id = ?', String(b.label).trim().slice(0, 40) || d.label, d.id);
    if (b.ring !== undefined) db.run('UPDATE devices SET ring = ? WHERE id = ?', b.ring ? 1 : 0, d.id);
    if (b.resetPassword) db.run('UPDATE devices SET sip_pass = ? WHERE id = ?', randomSecret(18), d.id);
    await reconfigure();
    return teamView();
  }, admin);

  r.delete('/api/team/devices/:id', async ({ params }) => {
    const d = db.get('SELECT * FROM devices WHERE id = ?', Number(params.id));
    if (!d) throw new HttpError(404, 'Device not found');
    if (d.kind === 'web') throw new HttpError(400, "The app device can't be removed; turn off the person's account instead");
    db.run('DELETE FROM devices WHERE id = ?', d.id);
    await reconfigure();
    return teamView();
  }, admin);

  // ------------------------------------------------------------ system
  r.get('/api/system', () => {
    let disk = null;
    try {
      const s = fs.statfsSync(env.dirs.recordings);
      disk = { freeGb: +(s.bavail * s.bsize / 1e9).toFixed(1), totalGb: +(s.blocks * s.bsize / 1e9).toFixed(1) };
    } catch { /* ignore */ }
    return {
      presence: ctx.presence.snapshot(),
      voipmsConfigured: !!(env.voipms.username && env.voipms.password),
      voipmsServer: env.voipms.server,
      smtpConfigured: !!env.smtp.host,
      transcriptionConfigured: !!env.openaiKey,
      tls: fs.existsSync(env.tlsCert),
      publicUrl: env.publicUrl,
      apiKey: env.apiKey || null,
      disk,
      webhooks: db.all('SELECT id, url, events, active, created_at FROM webhooks ORDER BY id'),
      liveClients: ctx.hub.count(),
    };
  }, admin);

  r.post('/api/system/test-email', async () => {
    const to = db.getSettings().voicemailEmail;
    if (!to) throw new HttpError(400, 'Add a voicemail email address first');
    try {
      await sendMail(env.smtp, {
        to: to.split(',').map((s) => s.trim()).filter(Boolean),
        subject: 'Satin Phone test email',
        text: `This is a test from Satin Phone (${env.publicUrl}). Voicemail emails will look like this.`,
      });
    } catch (e) {
      throw new HttpError(400, `Email failed: ${e.message}`);
    }
    return { ok: true };
  }, admin);

  r.post('/api/webhooks', async ({ req }) => {
    const b = await readJson(req);
    if (!/^https?:\/\/\S+$/.test(b.url || '')) throw new HttpError(400, 'Enter a full URL starting with https://');
    const secret = randomSecret(24);
    db.run('INSERT INTO webhooks(url, secret, events, created_at) VALUES(?, ?, ?, ?)', b.url, secret, String(b.events || '*'), Date.now());
    return { secret, webhooks: db.all('SELECT id, url, events, active, created_at FROM webhooks ORDER BY id') };
  }, admin);

  r.delete('/api/webhooks/:id', ({ params }) => {
    db.run('DELETE FROM webhooks WHERE id = ?', Number(params.id));
    return { webhooks: db.all('SELECT id, url, events, active, created_at FROM webhooks ORDER BY id') };
  }, admin);

  // ------------------------------------------------------------ integrations (website admin panel, API key)
  r.post('/api/integrations/contacts/sync', async ({ req }) => {
    const b = await readJson(req, 5 * 1024 * 1024);
    if (!Array.isArray(b.contacts)) throw new HttpError(400, 'Send { contacts: [...] }');
    let upserted = 0;
    db.tx(() => {
      if (b.replace) db.run("DELETE FROM contacts WHERE source = 'admin'");
      for (const c of b.contacts) {
        const phone = normalizeNumber(c.phone);
        const name = String(c.name || '').trim().slice(0, 80);
        if (phone.length < 7 || !name) continue;
        db.run(`INSERT INTO contacts(name, phone, company, notes, source, external_id, updated_at) VALUES(?, ?, ?, ?, 'admin', ?, ?)
          ON CONFLICT(phone) DO UPDATE SET name = excluded.name, company = excluded.company, source = 'admin',
          external_id = excluded.external_id, updated_at = excluded.updated_at`,
        name, phone, String(c.company || '').slice(0, 80), String(c.notes || '').slice(0, 2000), c.external_id ? String(c.external_id) : null, Date.now());
        upserted++;
      }
    });
    await syncCallerNames(ctx).catch(() => {});
    return { ok: true, upserted };
  }, admin);

  r.post('/api/integrations/originate', async ({ req }) => {
    const b = await readJson(req);
    const u = db.get('SELECT * FROM users WHERE (ext = ? OR username = ?) AND active = 1', String(b.ext || ''), String(b.username || ''));
    if (!u) throw new HttpError(404, 'Team member not found');
    const number = normalizeNumber(b.number);
    if (number.length !== 10) throw new HttpError(400, 'Enter a 10-digit number');
    const dev = webDevice(u);
    const who = contactFor(db, number)?.name || formatNumber(number);
    await ami.action({
      Action: 'Originate', Channel: `Local/${u.ext}@satin-users/n`, Context: 'satin-users', Exten: number, Priority: 1,
      CallerID: `"Calling ${who}" <${number}>`, Variable: [`SATIN_ORIGDEV=${dev.sip_user}`], Async: 'true', Timeout: 30000,
    });
    return { ok: true };
  }, admin);

  r.get('/api/integrations/calls', ({ query }) => {
    const since = Number(query.get('since')) || 0;
    const rows = db.all('SELECT * FROM calls WHERE started_at > ? ORDER BY started_at LIMIT 500', since);
    return { calls: rows.map((row) => callView(db, row)) };
  }, admin);

  return r;
}
