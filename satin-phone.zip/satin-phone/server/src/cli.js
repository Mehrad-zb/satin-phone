// Command-line helper:  npm run cli -- <command>
//   create-user --admin --name "Mehrad" --username mehrad --password "..."
//   reset-password --username mehrad --password "..."
//   list-users
//   write-config        (regenerate /etc/asterisk/satin/*.conf without reloading)
import { env } from './env.js';
import { openDb } from './db.js';
import { hashPassword, randomSecret } from './auth.js';
import { writeConfig } from './asterisk.js';
import readline from 'node:readline/promises';

const args = process.argv.slice(2);
const cmd = args[0];
const flag = (name) => args.includes(`--${name}`);
const opt = (name) => { const i = args.indexOf(`--${name}`); return i >= 0 ? args[i + 1] : undefined; };
const db = openDb(env.dirs.data);

async function ask(question, hidden = false) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
  if (hidden) rl._writeToOutput = (s) => { if (s.includes(question)) process.stdout.write(s); };
  const a = await rl.question(question);
  rl.close();
  if (hidden) process.stdout.write('\n');
  return a.trim();
}

if (cmd === 'create-user') {
  const name = opt('name') || await ask('Full name: ');
  const username = (opt('username') || await ask('Username (for signing in): ')).toLowerCase();
  const password = opt('password') || await ask('Password (8+ characters): ', true);
  if (!/^[a-z0-9._-]{2,32}$/.test(username)) { console.error('Username: 2–32 letters, numbers, dots or dashes'); process.exit(1); }
  if (password.length < 8) { console.error('Password must be at least 8 characters'); process.exit(1); }
  if (db.get('SELECT 1 FROM users WHERE username = ?', username)) { console.error('That username already exists'); process.exit(1); }
  const maxExt = db.get('SELECT MAX(CAST(ext AS INTEGER)) m FROM users').m || 100;
  const ext = String(Math.max(maxExt + 1, 101));
  const r = db.run('INSERT INTO users(name, username, pass, role, ext, created_at) VALUES(?, ?, ?, ?, ?, ?)',
    name, username, hashPassword(password), flag('admin') ? 'admin' : 'staff', ext, Date.now());
  const base = username.replace(/[^a-z0-9]/g, '') || 'user';
  db.run("INSERT INTO devices(user_id, kind, label, sip_user, sip_pass, created_at) VALUES(?, 'web', 'Satin Phone app', ?, ?, ?)",
    Number(r.lastInsertRowid), `${base}_web`, randomSecret(18), Date.now());
  try { writeConfig({ db, env }); } catch (e) { console.warn(`(config not written: ${e.message})`); }
  console.log(`Created ${flag('admin') ? 'admin' : 'staff'} "${name}" (${username}), extension ${ext}.`);
} else if (cmd === 'reset-password') {
  const username = (opt('username') || await ask('Username: ')).toLowerCase();
  const password = opt('password') || await ask('New password (8+ characters): ', true);
  if (password.length < 8) { console.error('Password must be at least 8 characters'); process.exit(1); }
  const r = db.run('UPDATE users SET pass = ? WHERE username = ?', hashPassword(password), username);
  if (!r.changes) { console.error('No such user'); process.exit(1); }
  db.run('DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE username = ?)', username);
  console.log('Password changed.');
} else if (cmd === 'list-users') {
  for (const u of db.all('SELECT id, name, username, role, ext, active FROM users ORDER BY ext')) {
    console.log(`${u.ext}  ${u.username.padEnd(16)} ${u.role.padEnd(6)} ${u.active ? '' : '(off) '}${u.name}`);
  }
} else if (cmd === 'write-config') {
  console.log('Changed:', writeConfig({ db, env }).join(', ') || 'nothing');
} else {
  console.log('Commands: create-user [--admin], reset-password, list-users, write-config');
}
