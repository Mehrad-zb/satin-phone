// Passwords (scrypt), sessions (random token, stored hashed) and API-key auth.
import crypto from 'node:crypto';

const SESSION_DAYS = 30;
export const COOKIE = 'sp_session';

export function randomSecret(bytes = 18) {
  return crypto.randomBytes(bytes).toString('base64url');
}

export function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(password), salt, 32, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('base64url')}$${hash.toString('base64url')}`;
}

export function verifyPassword(password, stored) {
  const [alg, saltB64, hashB64] = String(stored || '').split('$');
  if (alg !== 'scrypt' || !saltB64 || !hashB64) return false;
  const expected = Buffer.from(hashB64, 'base64url');
  const actual = crypto.scryptSync(String(password), Buffer.from(saltB64, 'base64url'), expected.length, { N: 16384, r: 8, p: 1 });
  return crypto.timingSafeEqual(expected, actual);
}

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

export function createSession(db, userId, agent = '') {
  const token = crypto.randomBytes(32).toString('base64url');
  const now = Date.now();
  db.run('INSERT INTO sessions(id, user_id, created_at, expires_at, agent) VALUES(?, ?, ?, ?, ?)',
    sha(token), userId, now, now + SESSION_DAYS * 864e5, String(agent).slice(0, 200));
  db.run('DELETE FROM sessions WHERE expires_at < ?', now);
  return token;
}

export function destroySession(db, token) {
  if (token) db.run('DELETE FROM sessions WHERE id = ?', sha(token));
}

export function userFromSession(db, token) {
  if (!token) return null;
  const row = db.get(`SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.id = ? AND s.expires_at > ? AND u.active = 1`, sha(token), Date.now());
  return row || null;
}

export function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function sessionCookie(token, secure, maxAgeDays = SESSION_DAYS) {
  const parts = [`${COOKIE}=${token}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${Math.round(maxAgeDays * 86400)}`];
  if (secure) parts.push('Secure');
  return parts.join('; ');
}

export function apiKeyMatches(provided, expected) {
  if (!provided || !expected) return false;
  const a = Buffer.from(sha(provided));
  const b = Buffer.from(sha(expected));
  return crypto.timingSafeEqual(a, b);
}

// Very small in-memory rate limiter for login attempts.
const attempts = new Map();
export function loginAllowed(key) {
  const now = Date.now();
  const rec = attempts.get(key) || { n: 0, since: now };
  if (now - rec.since > 10 * 60e3) { rec.n = 0; rec.since = now; }
  attempts.set(key, rec);
  return rec.n < 8;
}
export function loginFailed(key) {
  const rec = attempts.get(key) || { n: 0, since: Date.now() };
  rec.n += 1;
  attempts.set(key, rec);
}
export function loginSucceeded(key) {
  attempts.delete(key);
}

/** Public shape of a user (never includes the password hash). */
export function publicUser(u) {
  if (!u) return null;
  return { id: u.id, name: u.name, username: u.username, role: u.role, ext: u.ext, status: u.status, active: !!u.active };
}
