// Time-zone helpers (the shop runs on America/Toronto time).

function partsIn(tz, date) {
  const p = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hour12: false, year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit', weekday: 'short',
  }).formatToParts(date);
  const g = (t) => p.find((x) => x.type === t)?.value;
  return {
    year: Number(g('year')), month: Number(g('month')), day: Number(g('day')),
    hour: Number(g('hour')) % 24, minute: Number(g('minute')), second: Number(g('second')),
    weekday: g('weekday').toLowerCase().slice(0, 3),
  };
}

export function tzOffsetMs(tz, date = new Date()) {
  const p = partsIn(tz, date);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(date.getTime() / 1000) * 1000;
}

export function startOfDay(tz, date = new Date()) {
  const p = partsIn(tz, date);
  return Date.UTC(p.year, p.month - 1, p.day) - tzOffsetMs(tz, date);
}

export function localDate(tz, date = new Date()) {
  const p = partsIn(tz, date);
  return `${p.year}-${String(p.month).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`;
}

const to12 = (t) => { const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };

/** Is the shop open right now according to the settings? Mirrors the generated dialplan. */
export function openNow(settings, closedDates, tz, date = new Date()) {
  if (settings.override === 'open') return { open: true, reason: 'Forced open' };
  if (settings.override === 'closed') return { open: false, reason: 'Forced closed' };
  const today = localDate(tz, date);
  if (closedDates.includes(today)) return { open: false, reason: 'Closed today (holiday)' };
  const p = partsIn(tz, date);
  const h = settings.hours?.[p.weekday];
  if (!h?.open) return { open: false, reason: 'Closed today' };
  const now = p.hour * 60 + p.minute;
  const [fh, fm] = h.from.split(':').map(Number);
  const [th, tm] = h.to.split(':').map(Number);
  const from = fh * 60 + fm;
  const to = th * 60 + tm;
  if (now < from) return { open: false, reason: `Opens at ${to12(h.from)}` };
  if (now >= to) return { open: false, reason: `Closed since ${to12(h.to)}` };
  return { open: true, reason: `Open until ${to12(h.to)}` };
}
