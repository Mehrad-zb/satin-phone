// Loads settings from a .env-style file (KEY=value) and the process environment.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

function parseEnvFile(file) {
  const out = {};
  if (!file || !fs.existsSync(file)) return out;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    out[key] = val;
  }
  return out;
}

const envFile = process.env.SATIN_ENV_FILE
  || (fs.existsSync('/etc/satin-phone/satin.env') ? '/etc/satin-phone/satin.env' : path.join(here, '..', '.env'));
const fileVars = parseEnvFile(envFile);
const get = (k, d = '') => (process.env[k] ?? fileVars[k] ?? d);
const bool = (k, d = false) => {
  const v = String(get(k, d ? 'true' : 'false')).toLowerCase();
  return v === '1' || v === 'true' || v === 'yes';
};

export const env = {
  envFile,
  port: Number(get('PORT', '3000')),
  host: get('HOST', '127.0.0.1'),
  publicUrl: get('PUBLIC_URL', 'http://localhost:3000').replace(/\/$/, ''),
  sipDomain: get('SIP_DOMAIN', 'localhost'),
  sipWsUrl: get('SIP_WS_URL', ''),            // default: <PUBLIC_URL with wss>/sip
  timezone: get('TIMEZONE', 'America/Toronto'),
  companyName: get('COMPANY_NAME', 'Satin Auto Wrap'),
  mainNumber: get('MAIN_NUMBER', '9059626222').replace(/\D/g, ''),

  voipms: {
    server: get('VOIPMS_SERVER', 'toronto1.voip.ms'),
    username: get('VOIPMS_USERNAME', ''),
    password: get('VOIPMS_PASSWORD', ''),
  },
  publicIp: get('PUBLIC_IP', ''),
  localNet: get('LOCAL_NET', ''),
  tlsCert: get('TLS_CERT', '/etc/asterisk/keys/satin-fullchain.pem'),
  tlsKey: get('TLS_KEY', '/etc/asterisk/keys/satin-privkey.pem'),

  ami: {
    host: get('AMI_HOST', '127.0.0.1'),
    port: Number(get('AMI_PORT', '5038')),
    username: get('AMI_USERNAME', 'satin'),
    secret: get('AMI_SECRET', ''),
  },
  asteriskHttp: get('ASTERISK_HTTP', '127.0.0.1:8088'),

  dirs: {
    data: get('DATA_DIR', path.join(here, '..', 'data')),
    asteriskConf: get('ASTERISK_CONF_DIR', '/etc/asterisk/satin'),
    sounds: get('SOUNDS_DIR', '/var/lib/asterisk/sounds/satin'),
    coreSounds: get('CORE_SOUNDS_DIR', '/var/lib/asterisk/sounds/en'),
    recordings: get('RECORDINGS_DIR', '/var/spool/asterisk/satin/recordings'),
    voicemail: get('VOICEMAIL_DIR', '/var/spool/asterisk/satin/voicemail'),
    publicDir: get('PUBLIC_DIR', path.join(here, '..', 'public')),
  },

  smtp: {
    host: get('SMTP_HOST', ''),
    port: Number(get('SMTP_PORT', '587')),
    secure: bool('SMTP_SECURE', false),   // true = TLS from the start (port 465)
    user: get('SMTP_USER', ''),
    pass: get('SMTP_PASS', ''),
    from: get('SMTP_FROM', ''),
  },
  openaiKey: get('OPENAI_API_KEY', ''),
  transcribeModel: get('TRANSCRIBE_MODEL', 'whisper-1'),

  sessionSecret: get('SESSION_SECRET', ''),
  apiKey: get('API_KEY', ''),
  cookieSecure: bool('COOKIE_SECURE', get('PUBLIC_URL', '').startsWith('https://')),
  applyConfig: bool('APPLY_ASTERISK_CONFIG', true),
  ffmpeg: get('FFMPEG', 'ffmpeg'),
  stunServers: get('STUN_SERVERS', 'stun:stun.l.google.com:19302').split(',').map((s) => s.trim()).filter(Boolean),

  // Relay servers (e.g. a server in Iran for a team member there). When the app is opened
  // through one of these host names, calls go through that host's TURN server.
  relayHosts: get('RELAY_HOSTS', '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean),
  turnSecret: get('TURN_SECRET', ''),
  turnTtlHours: Number(get('TURN_TTL_HOURS', '168')),
};

if (!env.sipWsUrl) {
  env.sipWsUrl = env.publicUrl.replace(/^http/, 'ws') + '/sip';
}
