// Audio helpers built on ffmpeg (installed on the server by the installer).
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

function run(ffmpeg, args, input) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpeg, args, { stdio: ['pipe', 'pipe', 'pipe'] });
    const out = [];
    let err = '';
    p.stdout.on('data', (d) => out.push(d));
    p.stderr.on('data', (d) => { err += d; });
    p.on('error', reject);
    p.on('close', (code) => {
      if (code === 0) resolve(Buffer.concat(out));
      else reject(new Error(`ffmpeg failed (${code}): ${err.split('\n').slice(-4).join(' ')}`));
    });
    if (input) p.stdin.end(input); else p.stdin.end();
  });
}

/** Converts any uploaded/recorded audio into an Asterisk-friendly prompt (8 kHz mono WAV, levelled). */
export async function convertPrompt(ffmpeg, input, outFile) {
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  const tmp = `${outFile}.tmp.wav`;
  await run(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-i', 'pipe:0',
    '-af', 'highpass=f=100,silenceremove=start_periods=1:start_threshold=-50dB,loudnorm=I=-18:TP=-2:LRA=11',
    '-ar', '8000', '-ac', '1', '-c:a', 'pcm_s16le', '-f', 'wav', tmp], input);
  const dur = wavDuration(tmp);
  if (dur < 0.5) { fs.rmSync(tmp, { force: true }); throw new Error('The recording is empty or too short'); }
  if (dur > 180) { fs.rmSync(tmp, { force: true }); throw new Error('The recording is longer than 3 minutes'); }
  fs.renameSync(tmp, outFile);
  return dur;
}

export async function ensureBeep(ffmpeg, dir) {
  const file = path.join(dir, 'beep.wav');
  if (fs.existsSync(file)) return;
  fs.mkdirSync(dir, { recursive: true });
  await run(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', 'sine=frequency=1000:duration=0.45',
    '-af', 'afade=t=in:d=0.02,afade=t=out:st=0.4:d=0.05,volume=0.5', '-ar', '8000', '-ac', '1', '-c:a', 'pcm_s16le', file]);
}

/** MP3 copy for email attachments (falls back to the WAV if ffmpeg has no MP3 encoder). */
export async function toMp3(ffmpeg, wavFile) {
  try {
    const buf = await run(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-i', wavFile, '-ac', '1', '-b:a', '48k', '-f', 'mp3', 'pipe:1']);
    return { content: buf, contentType: 'audio/mpeg', ext: 'mp3' };
  } catch {
    return { content: fs.readFileSync(wavFile), contentType: 'audio/wav', ext: 'wav' };
  }
}

/** Duration in seconds of a PCM WAV file, read from its header. */
export function wavDuration(file) {
  let fd;
  try {
    fd = fs.openSync(file, 'r');
    const head = Buffer.alloc(4096);
    const n = fs.readSync(fd, head, 0, head.length, 0);
    if (n < 44 || head.toString('ascii', 0, 4) !== 'RIFF') return 0;
    let off = 12;
    let byteRate = 0;
    while (off + 8 <= n) {
      const id = head.toString('ascii', off, off + 4);
      const size = head.readUInt32LE(off + 4);
      if (id === 'fmt ') byteRate = head.readUInt32LE(off + 16);
      if (id === 'data') {
        const total = fs.fstatSync(fd).size;
        const dataSize = Math.min(size || Infinity, total - off - 8);
        return byteRate ? dataSize / byteRate : 0;
      }
      off += 8 + size + (size % 2);
    }
    return 0;
  } catch {
    return 0;
  } finally {
    if (fd !== undefined) fs.closeSync(fd);
  }
}
