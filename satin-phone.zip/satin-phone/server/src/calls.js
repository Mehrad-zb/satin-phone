// Turns Asterisk call events into call history, voicemails, emails and live updates.
import fs from 'node:fs';
import path from 'node:path';
import { normalizeNumber, formatNumber } from './phone.js';
import { wavDuration, toMp3 } from './audio.js';
import { transcribe } from './transcribe.js';
import { sendMail } from './mailer.js';

const first = (v) => (Array.isArray(v) ? v[0] : v) ?? '';
const num = (v) => { const n = Number(first(v)); return Number.isFinite(n) && n > 0 ? n : 0; };
const MIN_VOICEMAIL_SECONDS = 1.5;

export function contactFor(db, number) {
  const n = normalizeNumber(number);
  if (!n) return null;
  return db.get('SELECT id, name, company, notes FROM contacts WHERE phone = ?', n) || null;
}

function deviceInfo(db, sipUser) {
  if (!sipUser) return null;
  return db.get(`SELECT d.sip_user, d.label, d.kind, u.id AS user_id, u.name AS user_name FROM devices d
    JOIN users u ON u.id = d.user_id WHERE d.sip_user = ?`, sipUser) || null;
}

/** The shape the web app and the API receive for a call. */
export function callView(db, row) {
  if (!row) return null;
  const other = row.direction === 'out' ? row.to_num : row.from_num;
  const contact = contactFor(db, other);
  const dev = deviceInfo(db, row.answered_device);
  const caller = row.user_id ? db.get('SELECT id, name FROM users WHERE id = ?', row.user_id) : null;
  return {
    id: row.id,
    direction: row.direction,
    startedAt: row.started_at,
    answeredAt: row.answered_at,
    endedAt: row.ended_at,
    number: other || '',
    numberFormatted: other ? formatNumber(other) : 'Unknown number',
    contact,
    lang: row.lang,
    period: row.period,
    status: row.status,
    answeredBy: dev ? { device: dev.sip_user, label: dev.label, kind: dev.kind, userId: dev.user_id, userName: dev.user_name } : null,
    placedBy: caller,
    duration: row.duration,
    talk: row.talk,
    hasRecording: !!row.recording,
    voicemailId: row.voicemail_id,
    note: row.note,
    test: !!row.test,
  };
}

export function voicemailView(db, v) {
  if (!v) return null;
  const call = v.call_id ? db.get('SELECT test FROM calls WHERE id = ?', v.call_id) : null;
  return {
    test: !!call?.test,
    id: v.id,
    callId: v.call_id,
    number: v.from_num,
    numberFormatted: v.from_num ? formatNumber(v.from_num) : 'Unknown number',
    contact: contactFor(db, v.from_num),
    createdAt: v.created_at,
    duration: Math.round(v.duration),
    lang: v.lang,
    transcript: v.transcript,
    listened: !!v.listened,
  };
}

const removeIfEmpty = (file) => {
  try { if (fs.statSync(file).size <= 4096) fs.rmSync(file); } catch { /* none */ }
};

export function createCalls(ctx) {
  const { db, env, ami, hub, log, webhooks } = ctx;
  const live = new Map();

  function onStart(e) {
    const id = first(e.Uniqueid);
    const dir = first(e.Direction) === 'out' ? 'out' : 'in';
    const t0 = num(e.T0) * 1000 || Date.now();
    let row;
    if (dir === 'in') {
      const from = normalizeNumber(first(e.From));
      db.run(`INSERT OR IGNORE INTO calls(id, direction, started_at, from_num, to_num, status, test)
        VALUES(?, 'in', ?, ?, ?, 'ringing', ?)`, id, t0, from, env.mainNumber, first(e.Test) ? 1 : 0);
    } else {
      const dev = deviceInfo(db, first(e.From));
      const to = normalizeNumber(first(e.To));
      db.run(`INSERT OR IGNORE INTO calls(id, direction, started_at, from_num, to_num, status, user_id)
        VALUES(?, 'out', ?, ?, ?, 'ringing', ?)`, id, t0, env.mainNumber, to, dev?.user_id ?? null);
    }
    row = db.get('SELECT * FROM calls WHERE id = ?', id);
    const view = callView(db, row);
    live.set(id, view);
    hub.broadcast('call.started', view);
    webhooks.emit('call.started', view);
  }

  async function onEnd(e) {
    const id = first(e.Uniqueid);
    const dir = first(e.Direction) === 'out' ? 'out' : 'in';
    let row = db.get('SELECT * FROM calls WHERE id = ?', id);
    if (!row) {
      onStart(e);
      row = db.get('SELECT * FROM calls WHERE id = ?', id);
    }
    const t0 = num(e.T0) || Math.round(row.started_at / 1000);
    const ta = num(e.TA);
    const te = num(e.TE) || Math.round(Date.now() / 1000);
    const answered = first(e.Answered);
    const recName = path.basename(first(e.Rec));
    const vmName = path.basename(first(e.Vm));
    const talk = ta ? Math.max(te - ta, 0) : 0;
    let status;
    let answeredDevice = null;
    let voicemailFile = null;

    if (dir === 'in') {
      if (answered && answered !== 'voipms') {
        status = 'answered';
        answeredDevice = answered;
      } else if (first(e.Result) === 'voicemail' && vmName) {
        const f = path.join(env.dirs.voicemail, vmName);
        if (fs.existsSync(f) && wavDuration(f) >= MIN_VOICEMAIL_SECONDS) { status = 'voicemail'; voicemailFile = f; }
        else { status = 'missed'; fs.rmSync(f, { force: true }); }
      } else {
        status = 'missed';
      }
    } else {
      const ds = first(e.DialStatus);
      status = { ANSWER: 'answered', BUSY: 'busy', NOANSWER: 'noanswer', CANCEL: 'cancelled' }[ds] || 'failed';
    }

    let recording = null;
    if (recName) {
      const f = path.join(env.dirs.recordings, recName);
      if (talk > 0 && fs.existsSync(f) && fs.statSync(f).size > 4096) recording = recName;
      else removeIfEmpty(f);
    }
    const dev = deviceInfo(db, answeredDevice);
    db.run(`UPDATE calls SET status = ?, answered_at = ?, ended_at = ?, duration = ?, talk = ?, lang = ?, period = ?,
      answered_device = ?, answered_user = ?, recording = ? WHERE id = ?`,
      status, ta ? ta * 1000 : null, te * 1000, Math.max(te - t0, 0), talk,
      first(e.Lang) || null, first(e.Period) || null, answeredDevice, dev?.user_id ?? null, recording, id);
    live.delete(id);
    row = db.get('SELECT * FROM calls WHERE id = ?', id);
    if (voicemailFile) await saveVoicemail(row, voicemailFile);
    const view = callView(db, db.get('SELECT * FROM calls WHERE id = ?', id));
    hub.broadcast('call.ended', view);
    webhooks.emit('call.ended', view);
  }

  async function saveVoicemail(call, file) {
    const duration = wavDuration(file);
    const r = db.run(`INSERT INTO voicemails(call_id, from_num, created_at, duration, file, lang) VALUES(?, ?, ?, ?, ?, ?)`,
      call.id, call.from_num, call.ended_at || Date.now(), duration, path.basename(file), call.lang);
    const vmId = Number(r.lastInsertRowid);
    db.run('UPDATE calls SET voicemail_id = ? WHERE id = ?', vmId, call.id);
    const view = () => voicemailView(db, db.get('SELECT * FROM voicemails WHERE id = ?', vmId));
    hub.broadcast('voicemail.new', view());
    // Transcribe + email in the background so the call log updates right away.
    (async () => {
      const settings = db.getSettings();
      if (settings.transcribe && env.openaiKey) {
        try {
          const text = await transcribe(env, file, call.lang);
          if (text) {
            db.run('UPDATE voicemails SET transcript = ? WHERE id = ?', text, vmId);
            hub.broadcast('voicemail.updated', view());
          }
        } catch (e) { log.warn?.(`[voicemail] ${e.message}`); }
      }
      webhooks.emit('voicemail.created', view());
      if (settings.voicemailEmail && env.smtp.host) {
        try { await emailVoicemail(settings.voicemailEmail, view(), file); } catch (e) { log.warn?.(`[voicemail] email failed: ${e.message}`); }
      }
    })();
  }

  async function emailVoicemail(to, vm, file) {
    const who = vm.contact ? `${vm.contact.name} (${vm.numberFormatted})` : vm.numberFormatted;
    const when = new Date(vm.createdAt).toLocaleString('en-CA', { timeZone: env.timezone, dateStyle: 'medium', timeStyle: 'short' });
    const mins = `${Math.floor(vm.duration / 60)}:${String(vm.duration % 60).padStart(2, '0')}`;
    const audio = await toMp3(env.ffmpeg, file);
    const rtl = vm.lang === 'fa';
    const transcript = vm.transcript
      ? `<p style="margin:16px 0 4px;color:#6E6E73;font-size:12px;text-transform:uppercase;letter-spacing:.08em">Transcript</p>
         <p dir="${rtl ? 'rtl' : 'ltr'}" style="margin:0;font-size:16px;line-height:1.7">${escapeHtml(vm.transcript)}</p>`
      : '';
    await sendMail(env.smtp, {
      to: to.split(',').map((s) => s.trim()).filter(Boolean),
      subject: `New voicemail from ${who} · ${mins}`,
      text: `New voicemail on ${formatNumber(env.mainNumber)}\nFrom: ${who}\nWhen: ${when}\nLength: ${mins}\n\n${vm.transcript || ''}\n\nOpen Satin Phone: ${env.publicUrl}/#/voicemail`,
      html: `<div style="font-family:-apple-system,Segoe UI,Inter,Arial,sans-serif;color:#1D1D1F;max-width:560px">
        <p style="margin:0 0 4px;color:#6E6E73;font-size:12px;text-transform:uppercase;letter-spacing:.08em">New voicemail · ${escapeHtml(formatNumber(env.mainNumber))}</p>
        <h2 style="margin:0 0 8px;font-size:22px">${escapeHtml(who)}</h2>
        <p style="margin:0;color:#55555A">${escapeHtml(when)} · ${mins}</p>${transcript}
        <p style="margin:24px 0 0"><a href="${env.publicUrl}/#/voicemail" style="background:#2B4C6F;color:#fff;padding:12px 18px;border-radius:12px;text-decoration:none;font-weight:600">Open in Satin Phone</a></p>
        <p style="margin:16px 0 0;color:#6E6E73;font-size:13px">The recording is attached.</p></div>`,
      attachments: [{ filename: `voicemail-${vm.number || 'unknown'}.${audio.ext}`, contentType: audio.contentType, content: audio.content }],
    });
  }

  function onAnswered(e) {
    const id = first(e.CallId);
    const row = id && db.get('SELECT * FROM calls WHERE id = ?', id);
    if (!row || row.status !== 'ringing') return;
    const device = first(e.Device);
    const dev = device && device !== 'voipms' ? deviceInfo(db, device) : null;
    db.run('UPDATE calls SET status = ?, answered_at = ?, answered_device = ?, answered_user = ? WHERE id = ?',
      'active', Date.now(), dev ? device : null, dev?.user_id ?? null, id);
    const view = callView(db, db.get('SELECT * FROM calls WHERE id = ?', id));
    live.set(id, view);
    hub.broadcast('call.updated', view);
  }

  ami.on('UserEvent', (e) => {
    const name = first(e.UserEvent);
    try {
      if (name === 'SatinCallAnswered') onAnswered(e);
      else if (name === 'SatinCallStart') onStart(e);
      else if (name === 'SatinCallEnd') onEnd(e).catch((err) => log.error?.(`[calls] ${err.stack}`));
    } catch (err) {
      log.error?.(`[calls] ${err.stack}`);
    }
  });

  // Calls left "ringing" (e.g. the server restarted mid-call) are closed out.
  db.run(`UPDATE calls SET status = CASE direction WHEN 'in' THEN 'missed' ELSE 'failed' END
    WHERE status IN ('ringing', 'active') AND started_at < ?`, Date.now() - 3 * 3600e3);

  return {
    live: () => [...live.values()],
    emailVoicemail,
  };
}

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
