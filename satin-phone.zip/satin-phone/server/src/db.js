// SQLite storage (Node's built-in node:sqlite, no extra packages).
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

export const DEFAULT_SETTINGS = {
  hours: {
    mon: { open: true, from: '09:00', to: '17:00' },
    tue: { open: true, from: '09:00', to: '17:00' },
    wed: { open: true, from: '09:00', to: '17:00' },
    thu: { open: true, from: '09:00', to: '17:00' },
    fri: { open: true, from: '09:00', to: '17:00' },
    sat: { open: true, from: '10:00', to: '15:00' },
    sun: { open: false, from: '10:00', to: '15:00' },
  },
  closeOnHolidays: true,
  closedDates: [],
  override: 'auto',
  languageMenu: true,
  defaultLanguage: 'en',
  menuTimeout: 5,
  ringSeconds: 25,
  recordCalls: true,
  recordOutgoing: false,
  recordingNotice: true,
  recordingsVisibleTo: 'admin',
  voicemailEmail: '',
  transcribe: true,
  allowInternational: false,
  retentionDays: 365,
  // Phone menu after the greeting: "for sales press 1 ...". Empty members = everyone.
  departmentMenu: true,
  departments: [
    { digit: '1', name: 'Sales', members: [] },
    { digit: '2', name: 'Design team', members: [] },
    { digit: '3', name: 'Management', members: [] },
    { digit: '4', name: 'Production', members: [] },
    { digit: '5', name: 'Support', members: [] },
  ],
  dialByExtension: true,
  transcribeCalls: true,
};

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'staff',
  ext TEXT NOT NULL UNIQUE,
  active INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'available',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  label TEXT NOT NULL,
  sip_user TEXT NOT NULL UNIQUE,
  sip_pass TEXT NOT NULL,
  ring INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  agent TEXT
);
CREATE TABLE IF NOT EXISTS contacts (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  company TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT 'local',
  external_id TEXT,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS calls (
  id TEXT PRIMARY KEY,
  direction TEXT NOT NULL,
  started_at INTEGER NOT NULL,
  answered_at INTEGER,
  ended_at INTEGER,
  from_num TEXT,
  to_num TEXT,
  lang TEXT,
  period TEXT,
  status TEXT NOT NULL DEFAULT 'ringing',
  answered_device TEXT,
  answered_user INTEGER,
  user_id INTEGER,
  duration INTEGER NOT NULL DEFAULT 0,
  talk INTEGER NOT NULL DEFAULT 0,
  recording TEXT,
  voicemail_id INTEGER,
  note TEXT NOT NULL DEFAULT '',
  test INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS calls_started ON calls(started_at DESC);
CREATE INDEX IF NOT EXISTS calls_from ON calls(from_num);
CREATE INDEX IF NOT EXISTS calls_to ON calls(to_num);
CREATE TABLE IF NOT EXISTS voicemails (
  id INTEGER PRIMARY KEY,
  call_id TEXT,
  from_num TEXT,
  created_at INTEGER NOT NULL,
  duration INTEGER NOT NULL DEFAULT 0,
  file TEXT NOT NULL,
  lang TEXT,
  transcript TEXT,
  listened INTEGER NOT NULL DEFAULT 0,
  deleted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS webhooks (
  id INTEGER PRIMARY KEY,
  url TEXT NOT NULL,
  secret TEXT NOT NULL,
  events TEXT NOT NULL DEFAULT '*',
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL
);
`;

export function openDb(dataDir) {
  fs.mkdirSync(dataDir, { recursive: true });
  const db = new DatabaseSync(path.join(dataDir, 'satin-phone.db'));
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');
  db.exec(SCHEMA);
  migrate(db);
  return wrap(db);
}

/** Adds columns introduced after the first release (safe to run on every start). */
function migrate(db) {
  const has = (table, col) => db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === col);
  const add = (table, col, type) => { if (!has(table, col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`); };
  add('calls', 'dept', 'TEXT');
  add('calls', 'transcript', 'TEXT');
  add('calls', 'transcript_status', 'TEXT');
}

function wrap(db) {
  const cache = new Map();
  const stmt = (sql) => {
    let s = cache.get(sql);
    if (!s) { s = db.prepare(sql); cache.set(sql, s); }
    return s;
  };
  const api = {
    raw: db,
    all: (sql, ...p) => stmt(sql).all(...p),
    get: (sql, ...p) => stmt(sql).get(...p),
    run: (sql, ...p) => stmt(sql).run(...p),
    tx(fn) {
      db.exec('BEGIN');
      try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
    },
    getSettings() {
      const rows = api.all('SELECT key, value FROM settings');
      const out = structuredClone(DEFAULT_SETTINGS);
      for (const r of rows) {
        try { out[r.key] = JSON.parse(r.value); } catch { /* ignore bad row */ }
      }
      // fill missing days if hours was saved partially
      out.hours = { ...DEFAULT_SETTINGS.hours, ...(out.hours || {}) };
      return out;
    },
    saveSettings(patch) {
      api.tx(() => {
        for (const [k, v] of Object.entries(patch)) {
          if (!(k in DEFAULT_SETTINGS)) continue;
          api.run('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value', k, JSON.stringify(v));
        }
      });
      return api.getSettings();
    },
  };
  return api;
}
