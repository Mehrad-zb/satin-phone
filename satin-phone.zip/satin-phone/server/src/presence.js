// Tracks which team devices are online (registered) and whether the VoIP.ms line is registered.
export function createPresence({ ami, hub, log }) {
  const contacts = new Map(); // aor -> Set(uri)
  const state = { trunk: 'unknown', trunkDetail: '', asterisk: false, version: '' };

  const snapshot = () => {
    const devices = {};
    for (const [aor, set] of contacts) devices[aor] = set.size;
    return { devices, trunk: state.trunk, trunkDetail: state.trunkDetail, asterisk: state.asterisk, version: state.version };
  };
  const push = () => hub.broadcast('presence', snapshot());

  async function refresh() {
    if (!ami.connected) return;
    try {
      const res = await ami.action({ Action: 'PJSIPShowContacts' }, { list: true });
      contacts.clear();
      for (const e of res.events || []) {
        if (e.Event !== 'ContactList') continue;
        const aor = e.Aor || e.AOR;
        if (!aor) continue;
        const status = String(e.Status || '').toLowerCase();
        if (status === 'unavailable' || status === 'removed') continue;
        if (!contacts.has(aor)) contacts.set(aor, new Set());
        contacts.get(aor).add(e.Uri || e.URI || e.ObjectName);
      }
      const regs = await ami.action({ Action: 'PJSIPShowRegistrationsOutbound' }, { list: true });
      const reg = (regs.events || []).find((e) => e.Event === 'OutboundRegistrationDetail' && e.ObjectName === 'voipms');
      state.trunk = reg ? String(reg.Status || 'unknown').toLowerCase() : 'not-configured';
      const ver = await ami.command('core show version').catch(() => '');
      state.version = (ver.match(/Asterisk (\S+)/) || [])[1] || '';
    } catch (e) {
      log.warn?.(`[presence] ${e.message}`);
    }
    push();
  }

  ami.on('connected', () => { state.asterisk = true; setTimeout(refresh, 1500); });
  ami.on('disconnected', () => { state.asterisk = false; contacts.clear(); state.trunk = 'unknown'; push(); });

  ami.on('ContactStatus', (e) => {
    const aor = e.AOR || e.Aor;
    const uri = e.URI || e.Uri;
    if (!aor) return;
    const st = String(e.ContactStatus || '').toLowerCase();
    if (!contacts.has(aor)) contacts.set(aor, new Set());
    const set = contacts.get(aor);
    if (st === 'removed' || st === 'unreachable') set.delete(uri);
    else set.add(uri);
    if (!set.size) contacts.delete(aor);
    push();
  });

  // Only one outbound registration exists (VoIP.ms), so any PJSIP Registry event is about it.
  ami.on('Registry', (e) => {
    if (!/pjsip/i.test(String(e.ChannelType || ''))) return;
    state.trunk = String(e.Status || '').toLowerCase();
    state.trunkDetail = e.Cause || '';
    push();
  });

  setInterval(refresh, 60000).unref();

  return {
    snapshot,
    refresh,
    online: (sipUser) => (contacts.get(sipUser)?.size || 0) > 0,
  };
}
