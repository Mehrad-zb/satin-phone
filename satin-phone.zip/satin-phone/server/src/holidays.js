// Ontario statutory holidays (Employment Standards Act): 9 days a year.

function easterSunday(year) {
  // Anonymous Gregorian algorithm
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(Date.UTC(year, month - 1, day));
}

const iso = (dt) => dt.toISOString().slice(0, 10);
const utc = (y, m, d) => new Date(Date.UTC(y, m - 1, d));

/** n-th weekday (0=Sun..6=Sat) of a month, n=1.. */
function nthWeekday(year, month, weekday, n) {
  const first = utc(year, month, 1);
  const offset = (weekday - first.getUTCDay() + 7) % 7;
  return utc(year, month, 1 + offset + (n - 1) * 7);
}

/** Monday before May 25 (Victoria Day). */
function victoriaDay(year) {
  const d = utc(year, 5, 24);
  const back = (d.getUTCDay() + 6) % 7; // days since Monday
  return utc(year, 5, 24 - back);
}

export function ontarioHolidays(year) {
  const good = easterSunday(year);
  good.setUTCDate(good.getUTCDate() - 2);
  return [
    { date: iso(utc(year, 1, 1)), name: "New Year's Day" },
    { date: iso(nthWeekday(year, 2, 1, 3)), name: 'Family Day' },
    { date: iso(good), name: 'Good Friday' },
    { date: iso(victoriaDay(year)), name: 'Victoria Day' },
    { date: iso(utc(year, 7, 1)), name: 'Canada Day' },
    { date: iso(nthWeekday(year, 9, 1, 1)), name: 'Labour Day' },
    { date: iso(nthWeekday(year, 10, 1, 2)), name: 'Thanksgiving' },
    { date: iso(utc(year, 12, 25)), name: 'Christmas Day' },
    { date: iso(utc(year, 12, 26)), name: 'Boxing Day' },
  ];
}
