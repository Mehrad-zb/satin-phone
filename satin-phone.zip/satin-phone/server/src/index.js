// Satin Phone backend — entry point.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { env } from './env.js';
import { openDb } from './db.js';
import { Ami } from './ami.js';
import { createHub } from './hub.js';
import { createPresence } from './presence.js';
import { createCalls } from './calls.js';
import { createWebhooks } from './webhooks.js';
import { buildApi } from './api.js';
import { applyConfig, syncCallerNames } from './asterisk.js';
import { ensureBeep } from './audio.js';
import { HttpError, sendJson, serveStatic } from './http.js';
import { COOKIE, parseCookies, userFromSession, apiKeyMatches } from './auth.js';
import { acceptWebSocket, rejectUpgrade, proxyWebSocket } from './ws.js';

const log = {
  info: (...a) => console.log(new Date().toISOString(), ...a),
  warn: (...a) => console.warn(new Date().toISOString(), 'WARN', ...a),
  error: (...a) => console.error(new Date().toISOString(), 'ERROR', ...a),
};

for (const d of [env.dirs.data, env.dirs.recordings, env.dirs.voicemail, env.dirs.sounds, env.dirs.asteriskConf]) {
  try { fs.mkdirSync(d, { recursive: true }); } catch (e) { log.warn(`can't create ${d}: ${e.message}`); }
}

const db = openDb(env.dirs.data);
const ami = new Ami({ ...env.ami, log });
const hub = createHub();
const ctx = { db, env, ami, hub, log };
ctx.webhooks = createWebhooks(ctx);
ctx.presence = createPresence(ctx);
ctx.calls = createCalls(ctx);
const api = buildApi(ctx);

if (!db.get('SELECT 1 FROM users LIMIT 1')) {
  log.warn('No team accounts yet. Create the first admin with:  npm run cli -- create-user --admin');
}

await ensureBeep(env.ffmpeg, env.dirs.sounds).catch((e) => log.warn(`beep prompt: ${e.message}`));
if (env.applyConfig) {
  try { applyConfig(ctx); } catch (e) { log.error(`writing Asterisk config: ${e.message}`); }
}

ami.on('connected', async () => {
  if (!env.applyConfig) return;
  try {
    await applyConfig(ctx, { force: true });
    const n = await syncCallerNames(ctx);
    log.info(`[asterisk] config applied, ${n} customer names synced`);
  } catch (e) {
    log.error(`[asterisk] ${e.message}`);
  }
});
ami.start();

// ------------------------------------------------------------ auth for each request
const API_KEY_USER = { id: 0, name: 'API', username: 'api', role: 'admin', ext: '', status: 'available', active: 1 };

function authenticate(req) {
  const authz = String(req.headers.authorization || '');
  const bearer = authz.startsWith('Bearer ') ? authz.slice(7) : req.headers['x-api-key'];
  if (bearer && apiKeyMatches(String(bearer), env.apiKey)) return { user: API_KEY_USER, viaKey: true };
  const cookies = parseCookies(req.headers.cookie);
  return { user: userFromSession(db, cookies[COOKIE]), viaKey: false, cookies };
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://local');
  try {
    if (!url.pathname.startsWith('/api/')) {
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed');
      return serveStatic(req, res, env.dirs.publicDir, url.pathname);
    }
    const m = api.match(req.method, url.pathname);
    if (!m) throw new HttpError(404, 'Not found');
    if (m.methodNotAllowed) throw new HttpError(405, 'Method not allowed');
    const { user, viaKey, cookies = parseCookies(req.headers.cookie) } = authenticate(req);
    const opts = m.route.opts;
    if (!opts.public) {
      if (!user) throw new HttpError(401, 'Please sign in');
      if (opts.role === 'admin' && user.role !== 'admin') throw new HttpError(403, 'Only admins can do this');
      // CSRF guard: browsers can't send this header cross-site without CORS approval.
      if (!viaKey && req.method !== 'GET' && req.method !== 'HEAD' && req.headers['x-requested-with'] !== 'SatinPhone') {
        throw new HttpError(403, 'Missing request header');
      }
    }
    const result = await m.route.handler({ req, res, params: m.params, query: url.searchParams, user, cookies, viaKey });
    if (!res.headersSent && result !== undefined) sendJson(res, 200, result);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 500;
    if (status >= 500) log.error(req.method, url.pathname, e.stack || e.message);
    if (!res.headersSent) sendJson(res, status, { error: status >= 500 ? 'Something went wrong on the server' : e.message, ...(e.extra || {}) });
    else res.end();
  }
});

server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url, 'http://local');
  if (url.pathname === '/sip') {
    // WebRTC SIP signaling → Asterisk (nginx normally routes this directly; this is the fallback).
    return proxyWebSocket(req, socket, head, env.asteriskHttp, '/ws');
  }
  if (url.pathname === '/api/live') {
    const { user } = authenticate(req);
    if (!user) return rejectUpgrade(socket);
    const client = acceptWebSocket(req, socket);
    if (!client) return;
    hub.add(client, user);
    client.send({ type: 'hello', data: { presence: ctx.presence.snapshot(), calls: ctx.calls.live() } });
    return;
  }
  rejectUpgrade(socket, 404, 'Not Found');
});

server.listen(env.port, env.host, () => log.info(`Satin Phone listening on http://${env.host}:${env.port} (public: ${env.publicUrl})`));

// ------------------------------------------------------------ housekeeping
let lastDay = '';
setInterval(() => {
  const day = new Date().toLocaleDateString('en-CA', { timeZone: env.timezone });
  if (day === lastDay) return;
  lastDay = day;
  // New day: holidays for a new year, closed dates, etc.
  if (env.applyConfig) applyConfig(ctx).catch((e) => log.error(`[asterisk] ${e.message}`));
  // Delete recordings and voicemails older than the retention period.
  const keepDays = db.getSettings().retentionDays || 365;
  const cutoff = Date.now() - keepDays * 864e5;
  for (const c of db.all('SELECT id, recording FROM calls WHERE recording IS NOT NULL AND started_at < ?', cutoff)) {
    fs.rmSync(path.join(env.dirs.recordings, path.basename(c.recording)), { force: true });
    db.run('UPDATE calls SET recording = NULL WHERE id = ?', c.id);
  }
  for (const v of db.all('SELECT id, file FROM voicemails WHERE deleted = 0 AND created_at < ?', cutoff)) {
    fs.rmSync(path.join(env.dirs.voicemail, path.basename(v.file)), { force: true });
    db.run('UPDATE voicemails SET deleted = 1 WHERE id = ?', v.id);
  }
}, 60_000).unref();

const shutdown = () => { log.info('shutting down'); ami.stop(); server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); };
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
