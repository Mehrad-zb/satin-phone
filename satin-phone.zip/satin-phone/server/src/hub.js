// Live-update hub: every logged-in browser keeps one WebSocket open to receive events.
export function createHub() {
  const clients = new Set();
  return {
    add(client, user) {
      const entry = { client, user };
      clients.add(entry);
      client.on('close', () => clients.delete(entry));
      return entry;
    },
    broadcast(type, data, { adminOnly = false, userId = null } = {}) {
      const msg = JSON.stringify({ type, data });
      for (const { client, user } of clients) {
        if (adminOnly && user.role !== 'admin') continue;
        if (userId !== null && user.id !== userId) continue;
        client.send(msg);
      }
    },
    count: () => clients.size,
  };
}
