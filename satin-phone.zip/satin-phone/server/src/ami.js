// Minimal Asterisk Manager Interface (AMI) client with auto-reconnect.
import net from 'node:net';
import { EventEmitter } from 'node:events';

export class Ami extends EventEmitter {
  constructor({ host, port, username, secret, log = console }) {
    super();
    this.opts = { host, port, username, secret };
    this.log = log;
    this.socket = null;
    this.buffer = '';
    this.connected = false;
    this.seq = 0;
    this.pending = new Map();
    this.backoff = 1000;
    this.stopped = false;
  }

  start() {
    this.stopped = false;
    this.#connect();
  }

  stop() {
    this.stopped = true;
    this.socket?.destroy();
  }

  #connect() {
    if (this.stopped) return;
    const sock = net.createConnection({ host: this.opts.host, port: this.opts.port });
    this.socket = sock;
    this.buffer = '';
    sock.setEncoding('utf8');
    sock.setKeepAlive(true, 15000);
    sock.on('data', (chunk) => this.#onData(chunk));
    sock.on('error', (err) => {
      if (this.connected) this.log.warn?.(`[ami] ${err.message}`);
    });
    sock.on('close', () => {
      const was = this.connected;
      this.connected = false;
      for (const [, p] of this.pending) p.reject(new Error('AMI disconnected'));
      this.pending.clear();
      if (was) this.emit('disconnected');
      if (!this.stopped) {
        setTimeout(() => this.#connect(), this.backoff);
        this.backoff = Math.min(this.backoff * 2, 15000);
      }
    });
    sock.on('connect', async () => {
      try {
        const res = await this.action({ Action: 'Login', Username: this.opts.username, Secret: this.opts.secret, Events: 'on' }, { force: true });
        if (res.Response !== 'Success') throw new Error(res.Message || 'login failed');
        this.connected = true;
        this.backoff = 1000;
        this.log.info?.('[ami] connected to Asterisk');
        this.emit('connected');
      } catch (e) {
        this.log.error?.(`[ami] login failed: ${e.message}`);
        sock.destroy();
      }
    });
  }

  #onData(chunk) {
    this.buffer += chunk;
    // The greeting line has no blank line after it.
    if (this.buffer.startsWith('Asterisk Call Manager')) {
      const nl = this.buffer.indexOf('\r\n');
      if (nl === -1) return;
      this.buffer = this.buffer.slice(nl + 2);
    }
    let idx;
    while ((idx = this.buffer.indexOf('\r\n\r\n')) !== -1) {
      const block = this.buffer.slice(0, idx);
      this.buffer = this.buffer.slice(idx + 4);
      if (block.trim()) this.#onMessage(parseBlock(block));
    }
  }

  #onMessage(msg) {
    const id = msg.ActionID;
    const p = id ? this.pending.get(id) : null;
    if (p) {
      if (msg.Event) {
        p.events.push(msg);
        if (msg.EventList === 'Complete') { this.pending.delete(id); p.resolve({ ...p.response, events: p.events }); }
        return;
      }
      if (msg.Response !== undefined) {
        if (p.list && msg.Response === 'Success' && /start/i.test(msg.EventList || '')) { p.response = msg; return; }
        if (p.list && msg.Response === 'Success' && /will follow/i.test(msg.Message || '')) { p.response = msg; return; }
        this.pending.delete(id);
        p.resolve(p.list ? { ...msg, events: p.events } : msg);
        return;
      }
    }
    if (msg.Event) {
      this.emit('event', msg);
      this.emit(msg.Event, msg);
    }
  }

  action(fields, { list = false, timeout = 10000, force = false } = {}) {
    if (!force && !this.connected) return Promise.reject(new Error('Asterisk is not connected'));
    const id = `sp${++this.seq}`;
    let text = '';
    for (const [k, v] of Object.entries({ ...fields, ActionID: id })) {
      if (v === undefined || v === null) continue;
      for (const item of Array.isArray(v) ? v : [v]) text += `${k}: ${String(item).replace(/[\r\n]+/g, ' ')}\r\n`;
    }
    text += '\r\n';
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`AMI ${fields.Action} timed out`));
      }, timeout);
      this.pending.set(id, {
        list,
        events: [],
        response: null,
        resolve: (r) => { clearTimeout(timer); resolve(r); },
        reject: (e) => { clearTimeout(timer); reject(e); },
      });
      this.socket.write(text);
    });
  }

  /** Runs a CLI command and returns its output as text. */
  async command(cmd) {
    const res = await this.action({ Action: 'Command', Command: cmd });
    const out = res.Output;
    return Array.isArray(out) ? out.join('\n') : (out || res.Message || '');
  }
}

export function parseBlock(block) {
  const msg = {};
  for (const line of block.split('\r\n')) {
    const i = line.indexOf(':');
    if (i < 0) continue;
    const key = line.slice(0, i).trim();
    const val = line.slice(i + 1).replace(/^ /, '');
    if (key in msg) {
      msg[key] = Array.isArray(msg[key]) ? [...msg[key], val] : [msg[key], val];
    } else {
      msg[key] = val;
    }
  }
  return msg;
}
