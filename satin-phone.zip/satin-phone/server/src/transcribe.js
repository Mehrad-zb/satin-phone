// Optional voicemail transcription (English or Farsi) with OpenAI's speech-to-text API.
import fs from 'node:fs';
import path from 'node:path';

export async function transcribe(env, file, lang) {
  if (!env.openaiKey) return null;
  const form = new FormData();
  form.append('file', new Blob([fs.readFileSync(file)], { type: 'audio/wav' }), path.basename(file));
  form.append('model', env.transcribeModel);
  if (lang === 'fa' || lang === 'en') form.append('language', lang);
  form.append('response_format', 'text');
  const res = await fetch('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.openaiKey}` },
    body: form,
    signal: AbortSignal.timeout(90000),
  });
  if (!res.ok) throw new Error(`Transcription failed: ${res.status} ${(await res.text()).slice(0, 200)}`);
  return (await res.text()).trim();
}
