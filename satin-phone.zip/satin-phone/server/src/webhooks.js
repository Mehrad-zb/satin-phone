// Outgoing webhooks: lets the website admin panel react to calls and voicemails.
// Each POST carries X-Satin-Event and X-Satin-Signature: sha256=<HMAC of the body>.
import crypto from 'node:crypto';

export function createWebhooks({ db, log }) {
  async function deliver(hook, event, payload, attempt = 1) {
    const body = JSON.stringify({ event, at: new Date().toISOString(), data: payload });
    const sig = crypto.createHmac('sha256', hook.secret).update(body).digest('hex');
    try {
      const res = await fetch(hook.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Satin-Event': event, 'X-Satin-Signature': `sha256=${sig}` },
        body,
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
    } catch (e) {
      if (attempt < 4) setTimeout(() => deliver(hook, event, payload, attempt + 1), attempt * 15000);
      else log.warn?.(`[webhook] ${hook.url} gave up on ${event}: ${e.message}`);
    }
  }
  return {
    emit(event, payload) {
      const hooks = db.all('SELECT * FROM webhooks WHERE active = 1');
      for (const h of hooks) {
        const events = h.events === '*' ? null : h.events.split(',').map((s) => s.trim());
        if (!events || events.includes(event)) deliver(h, event, payload);
      }
    },
  };
}
