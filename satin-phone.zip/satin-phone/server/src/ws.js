// Minimal WebSocket server (RFC 6455) for live updates, plus a raw proxy that
// forwards the browser's SIP-over-WebSocket connection to Asterisk.
import crypto from 'node:crypto';
import net from 'node:net';
import { EventEmitter } from 'node:events';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

export class WsClient extends EventEmitter {
  constructor(socket) {
    super();
    this.socket = socket;
    this.buf = Buffer.alloc(0);
    this.fragments = [];
    this.alive = true;
    this.closed = false;
    socket.setNoDelay(true);
    socket.on('data', (d) => this.#onData(d));
    socket.on('close', () => this.#closed());
    socket.on('error', () => this.#closed());
    this.timer = setInterval(() => {
      if (!this.alive) { this.socket.destroy(); return; }
      this.alive = false;
      this.#frame(0x9, Buffer.alloc(0));
    }, 25000);
  }

  send(obj) {
    if (this.closed) return;
    this.#frame(0x1, Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj)));
  }

  close(code = 1000) {
    if (this.closed) return;
    const b = Buffer.alloc(2);
    b.writeUInt16BE(code);
    this.#frame(0x8, b);
    this.socket.end();
  }

  #closed() {
    if (this.closed) return;
    this.closed = true;
    clearInterval(this.timer);
    this.emit('close');
  }

  #frame(opcode, payload) {
    const len = payload.length;
    let header;
    if (len < 126) {
      header = Buffer.from([0x80 | opcode, len]);
    } else if (len < 65536) {
      header = Buffer.alloc(4);
      header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(len, 2);
    } else {
      header = Buffer.alloc(10);
      header[0] = 0x80 | opcode; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2);
    }
    try { this.socket.write(Buffer.concat([header, payload])); } catch { /* closed */ }
  }

  #onData(data) {
    this.buf = Buffer.concat([this.buf, data]);
    while (this.buf.length >= 2) {
      const fin = (this.buf[0] & 0x80) !== 0;
      const opcode = this.buf[0] & 0x0f;
      const masked = (this.buf[1] & 0x80) !== 0;
      let len = this.buf[1] & 0x7f;
      let off = 2;
      if (len === 126) { if (this.buf.length < 4) return; len = this.buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (this.buf.length < 10) return; len = Number(this.buf.readBigUInt64BE(2)); off = 10; }
      if (len > 1024 * 1024) { this.socket.destroy(); return; }
      const maskOff = off;
      if (masked) off += 4;
      if (this.buf.length < off + len) return;
      const payload = Buffer.from(this.buf.subarray(off, off + len));
      if (masked) for (let i = 0; i < len; i++) payload[i] ^= this.buf[maskOff + (i % 4)];
      this.buf = this.buf.subarray(off + len);
      this.alive = true;
      if (opcode === 0x8) { this.close(); return; }
      if (opcode === 0x9) { this.#frame(0xA, payload); continue; }
      if (opcode === 0xA) continue;
      if (opcode === 0x0 || opcode === 0x1 || opcode === 0x2) {
        this.fragments.push(payload);
        if (!fin) continue;
        const msg = Buffer.concat(this.fragments).toString('utf8');
        this.fragments = [];
        let parsed = msg;
        try { parsed = JSON.parse(msg); } catch { /* plain text */ }
        this.emit('message', parsed);
      }
    }
  }
}

export function acceptWebSocket(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket') {
    socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
    return null;
  }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n'
    + `Sec-WebSocket-Accept: ${accept}\r\n\r\n`);
  return new WsClient(socket);
}

export function rejectUpgrade(socket, status = 401, text = 'Unauthorized') {
  socket.end(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
}

/** Pipes a WebSocket upgrade straight through to Asterisk's /ws endpoint. */
export function proxyWebSocket(req, socket, head, target, targetPath = '/ws') {
  const [host, portStr] = target.split(':');
  const upstream = net.connect(Number(portStr || 8088), host || '127.0.0.1');
  const kill = () => { socket.destroy(); upstream.destroy(); };
  upstream.on('error', kill);
  socket.on('error', kill);
  upstream.on('connect', () => {
    let out = `GET ${targetPath} HTTP/1.1\r\n`;
    for (let i = 0; i < req.rawHeaders.length; i += 2) {
      const k = req.rawHeaders[i];
      const v = req.rawHeaders[i + 1];
      if (k.toLowerCase() === 'host') out += `Host: ${target}\r\n`;
      else out += `${k}: ${v}\r\n`;
    }
    out += `X-Forwarded-For: ${req.socket.remoteAddress}\r\n\r\n`;
    upstream.write(out);
    if (head?.length) upstream.write(head);
    socket.pipe(upstream).pipe(socket);
  });
}
