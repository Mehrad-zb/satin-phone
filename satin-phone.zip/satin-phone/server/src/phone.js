// North American phone number helpers.

/** Normalizes any input to 10 digits (NANP) when possible, else returns digits only. */
export function normalizeNumber(input) {
  let d = String(input ?? '').replace(/\D/g, '');
  if (d.length === 11 && d.startsWith('1')) d = d.slice(1);
  return d;
}

export function formatNumber(input) {
  const d = normalizeNumber(input);
  if (d.length === 10) return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
  return d || String(input ?? '');
}

/** Safe text for Asterisk caller ID / AstDB (no characters that dialplan parsing treats specially). */
export function sanitizeCallerName(name) {
  return String(name ?? '')
    .replace(/[,|:;?()"'\\^\r\n\t<>{}$[\]]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 40);
}

// High-cost North American area codes (Caribbean and others billed as international).
export const PREMIUM_AREA_CODES = [
  '900', '976',
  '242', '246', '264', '268', '284', '345', '441', '473', '649', '658', '664',
  '721', '758', '767', '784', '809', '829', '849', '868', '869', '876',
];
