#!/usr/bin/env bash
# Update Satin Phone to the version in this folder (keeps settings, calls, recordings).
#   cd satin-phone && sudo bash scripts/update.sh
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP=/opt/satin-phone
[ "$(id -u)" = 0 ] || { echo "Run as root: sudo bash scripts/update.sh"; exit 1; }
cp -r "$SRC/server" "$APP/server.new"
rm -rf "$APP/server.new/data" "$APP/server.new/.env"
rm -rf "$APP/server.old" && mv "$APP/server" "$APP/server.old" && mv "$APP/server.new" "$APP/server"
cp -r "$SRC/scripts" "$SRC/asterisk" "$APP/"
for f in "$SRC"/asterisk/etc/*.conf; do install -o asterisk -g asterisk -m 644 "$f" /etc/asterisk/; done
systemctl restart satin-phone
asterisk -rx "core reload" >/dev/null
echo "Updated. (Previous version kept in $APP/server.old)"
