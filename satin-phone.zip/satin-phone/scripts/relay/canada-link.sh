#!/bin/bash
# Run on the Canadian Satin Phone server (after install.sh) to accept the Iranian relay.
#   IRAN_IP=194.110.24.81 IRAN_KEY=<key printed by iran-relay.sh> bash canada-link.sh
set -euo pipefail
: "${IRAN_IP:?set IRAN_IP}"; : "${IRAN_KEY:?set IRAN_KEY}"
RELAY_HOST=${RELAY_HOST:-phone-ir.satingraphic.ca}
WG_PORT=${WG_PORT:-51820}
ENVF=/etc/satin-phone/satin.env
command -v wg >/dev/null || DEBIAN_FRONTEND=noninteractive apt-get -yq install wireguard-tools
umask 077
[ -f /etc/wireguard/satin.key ] || wg genkey > /etc/wireguard/satin.key
cat > /etc/wireguard/satin.conf <<WG
[Interface]
Address = 10.77.0.1/30
ListenPort = $WG_PORT
PrivateKey = $(cat /etc/wireguard/satin.key)
MTU = 1380

[Peer]
PublicKey = $IRAN_KEY
AllowedIPs = 10.77.0.2/32
WG
umask 022
systemctl enable --now wg-quick@satin >/dev/null 2>&1 || true
systemctl restart wg-quick@satin
ufw allow from "$IRAN_IP" to any port "$WG_PORT" proto udp >/dev/null
ufw allow in on satin to any port 443 proto tcp >/dev/null
ufw allow in on satin to any port 10000:20000 proto udp >/dev/null

secret=$(grep -s '^TURN_SECRET=' "$ENVF" | cut -d= -f2- || true)
[ -n "$secret" ] || secret=$(openssl rand -hex 24)
python3 - "$ENVF" "$RELAY_HOST" "$secret" <<'PY'
import sys,re
f,host,sec=sys.argv[1:]
s=open(f).read()
for k,v in (("RELAY_HOSTS",host),("TURN_SECRET",sec)):
    s=re.sub(rf"^{k}=.*$",f"{k}={v}",s,flags=re.M) if re.search(rf"^{k}=",s,re.M) else s.rstrip("\n")+f"\n{k}={v}\n"
open(f,"w").write(s)
PY
systemctl restart satin-phone
echo
echo "Run this on the Iranian server:"
echo "  CANADA_IP=$(curl -s4 https://ifconfig.me) CANADA_KEY=$(wg pubkey < /etc/wireguard/satin.key) TURN_SECRET=$secret bash iran-relay.sh"
