#!/bin/bash
# Satin Phone relay for a team member in Iran. Run on the Iranian server (Ubuntu), as root.
# She opens https://RELAY_HOST (a server inside Iran, so filtering doesn't touch her side);
# this server carries the app, SIP and call audio to the main server in Canada through a WireGuard tunnel.
#   Step 1 (no args):      bash iran-relay.sh          -> prints this server's tunnel key
#   Step 2 (after Canada): CANADA_IP=... CANADA_KEY=... TURN_SECRET=... bash iran-relay.sh
set -euo pipefail
RELAY_HOST=${RELAY_HOST:-phone-ir.satingraphic.ca}
MAIN_HOST=${MAIN_HOST:-phone.satingraphic.ca}
WG_PORT=${WG_PORT:-51820}
EMAIL=${EMAIL:-admin@satingraphic.ca}
export DEBIAN_FRONTEND=noninteractive

command -v wg >/dev/null || apt-get -yq install wireguard-tools
command -v nginx >/dev/null || apt-get -yq install nginx
command -v turnserver >/dev/null || apt-get -yq install coturn
command -v certbot >/dev/null || apt-get -yq install certbot python3-certbot-nginx

umask 077
mkdir -p /etc/wireguard
[ -f /etc/wireguard/satin.key ] || wg genkey > /etc/wireguard/satin.key
MYKEY=$(wg pubkey < /etc/wireguard/satin.key)
if [ -z "${CANADA_IP:-}" ] || [ -z "${CANADA_KEY:-}" ] || [ -z "${TURN_SECRET:-}" ]; then
  echo "This server's tunnel key: $MYKEY"
  echo "Next: run canada-link.sh on the Canadian server, then rerun this with CANADA_IP, CANADA_KEY and TURN_SECRET."
  exit 0
fi
umask 022

# --- firewall
ufw allow 22/tcp >/dev/null; ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
ufw allow 3478 >/dev/null; ufw allow 5349/tcp >/dev/null
ufw --force enable >/dev/null

# --- tunnel to Canada (10.77.0.2 here, 10.77.0.1 there)
cat > /etc/wireguard/satin.conf <<WG
[Interface]
Address = 10.77.0.2/30
PrivateKey = $(cat /etc/wireguard/satin.key)
MTU = 1380

[Peer]
PublicKey = $CANADA_KEY
Endpoint = $CANADA_IP:$WG_PORT
AllowedIPs = 10.77.0.1/32
PersistentKeepalive = 20
WG
chmod 600 /etc/wireguard/satin.conf
systemctl enable --now wg-quick@satin >/dev/null 2>&1 || true
systemctl restart wg-quick@satin
grep -q "10.77.0.1 $MAIN_HOST" /etc/hosts || echo "10.77.0.1 $MAIN_HOST" >> /etc/hosts

# --- HTTPS certificate for the relay name
mkdir -p /var/www/acme
cat > /etc/nginx/sites-available/satin-relay <<NG
server {
  listen 80; listen [::]:80;
  server_name $RELAY_HOST;
  location /.well-known/acme-challenge/ { root /var/www/acme; }
  location / { return 301 https://\$host\$request_uri; }
}
NG
ln -sf /etc/nginx/sites-available/satin-relay /etc/nginx/sites-enabled/satin-relay
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
[ -d /etc/letsencrypt/live/$RELAY_HOST ] || certbot certonly --webroot -w /var/www/acme -d $RELAY_HOST -m $EMAIL --agree-tos -n
CERT=/etc/letsencrypt/live/$RELAY_HOST

# --- nginx: everything goes to the Canadian server through the tunnel
cat > /etc/nginx/sites-available/satin-relay <<NG
map \$http_upgrade \$conn_upgrade { default upgrade; '' close; }
server {
  listen 80; listen [::]:80;
  server_name $RELAY_HOST;
  location /.well-known/acme-challenge/ { root /var/www/acme; }
  location / { return 301 https://\$host\$request_uri; }
}
server {
  listen 443 ssl; listen [::]:443 ssl;
  http2 on;
  server_name $RELAY_HOST;
  ssl_certificate $CERT/fullchain.pem;
  ssl_certificate_key $CERT/privkey.pem;
  client_max_body_size 30m;
  location / {
    proxy_pass https://10.77.0.1;
    proxy_ssl_server_name on;
    proxy_ssl_name $MAIN_HOST;
    proxy_set_header Host $MAIN_HOST;
    proxy_set_header X-Satin-Relay $RELAY_HOST;
    proxy_set_header X-Forwarded-For \$remote_addr;
    proxy_set_header X-Forwarded-Proto https;
    proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection \$conn_upgrade;
    proxy_buffering off;
    proxy_read_timeout 1h;
    proxy_send_timeout 1h;
  }
}
NG
nginx -t && systemctl reload nginx

# --- TURN server: call audio from her browser, relayed only to the phone server
cat > /etc/turnserver.conf <<TC
listening-port=3478
tls-listening-port=5349
relay-ip=10.77.0.2
min-port=49152
max-port=65535
realm=$RELAY_HOST
use-auth-secret
static-auth-secret=$TURN_SECRET
cert=$CERT/fullchain.pem
pkey=$CERT/privkey.pem
fingerprint
no-cli
no-multicast-peers
denied-peer-ip=0.0.0.0-255.255.255.255
allowed-peer-ip=10.77.0.1
user-quota=12
total-quota=60
log-file=syslog
TC
mkdir -p /etc/systemd/system/coturn.service.d
cat > /etc/systemd/system/coturn.service.d/satin.conf <<SD
[Unit]
After=wg-quick@satin.service
[Service]
Group=ssl-cert
SD
getent group ssl-cert >/dev/null || groupadd ssl-cert
chgrp -R ssl-cert /etc/letsencrypt/live /etc/letsencrypt/archive; chmod -R g+rX /etc/letsencrypt/live /etc/letsencrypt/archive
cat > /etc/letsencrypt/renewal-hooks/deploy/satin-relay.sh <<'HK'
#!/bin/sh
chgrp -R ssl-cert /etc/letsencrypt/live /etc/letsencrypt/archive; chmod -R g+rX /etc/letsencrypt/live /etc/letsencrypt/archive
systemctl reload nginx; systemctl restart coturn
HK
chmod +x /etc/letsencrypt/renewal-hooks/deploy/satin-relay.sh
systemctl daemon-reload
systemctl enable --now coturn >/dev/null 2>&1 || true
systemctl restart coturn

echo
ping -c2 -W2 10.77.0.1 >/dev/null && echo "Tunnel to Canada: OK" || echo "Tunnel to Canada: NOT connected yet"
curl -sk -o /dev/null -w "Phone app through tunnel: HTTP %{http_code}\n" --resolve $MAIN_HOST:443:10.77.0.1 https://$MAIN_HOST/ || true
echo "Relay ready: https://$RELAY_HOST"
