#!/usr/bin/env bash
# Satin Phone firewall (ufw). Safe to re-run — e.g. after changing VOIPMS_SERVER.
#   • SSH, web (80/443) and secure phones (SIP-TLS 5061) open to everyone
#   • plain SIP (UDP 5060) only from your VoIP.ms server, so scanners can't reach it
#   • voice audio (RTP, UDP 10000–20000) open, as calls need it
set -euo pipefail
ENV_FILE=${SATIN_ENV_FILE:-/etc/satin-phone/satin.env}
VOIPMS_SERVER=$(grep -E '^VOIPMS_SERVER=' "$ENV_FILE" 2>/dev/null | cut -d= -f2- | cut -d: -f1)
VOIPMS_SERVER=${VOIPMS_SERVER:-toronto1.voip.ms}

ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
# keep whatever port SSH listens on
for p in $(ss -tlnpH 2>/dev/null | awk '/sshd/{n=split($4,a,":"); print a[n]}' | sort -u) 22; do
  ufw allow "$p"/tcp comment 'ssh' >/dev/null
done
ufw allow 80/tcp comment 'web' >/dev/null
ufw allow 443/tcp comment 'web' >/dev/null
ufw allow 5061/tcp comment 'sip-tls phones' >/dev/null
ufw allow 10000:20000/udp comment 'rtp audio' >/dev/null

# remove old VoIP.ms rules, then add the current server's addresses
while ufw status numbered | grep -q 'satin-voipms'; do
  n=$(ufw status numbered | grep 'satin-voipms' | head -1 | sed -E 's/^\[ *([0-9]+)\].*/\1/')
  yes | ufw delete "$n" >/dev/null
done
for ip in $(getent ahostsv4 "$VOIPMS_SERVER" | awk '{print $1}' | sort -u); do
  ufw allow from "$ip" to any port 5060 proto udp comment 'satin-voipms' >/dev/null
  echo "allowed SIP from $VOIPMS_SERVER ($ip)"
done
ufw --force enable >/dev/null
ufw status verbose
