#!/usr/bin/env bash
# Runs after the HTTPS certificate is issued/renewed: gives Asterisk a copy for
# secure phones (SIP over TLS, port 5061) and reloads the phone config.
set -e
LIVE="${RENEWED_LINEAGE:-}"
[ -n "$LIVE" ] || LIVE=$(ls -d /etc/letsencrypt/live/*/ 2>/dev/null | grep -v README | head -1)
LIVE=${LIVE%/}
[ -f "$LIVE/fullchain.pem" ] || exit 0
install -o asterisk -g asterisk -m 644 "$LIVE/fullchain.pem" /etc/asterisk/keys/satin-fullchain.pem
install -o asterisk -g asterisk -m 600 "$LIVE/privkey.pem" /etc/asterisk/keys/satin-privkey.pem
# the app regenerates the transports (adds TLS) and reloads Asterisk when it starts
systemctl restart satin-phone || true
