#!/usr/bin/env bash
# Back up everything you'd need to rebuild the phone system:
# settings, team, call history, customers, voicemail, recordings, greetings.
#   sudo bash /opt/satin-phone/scripts/backup.sh   → /root/satin-phone-backup-<date>.tar.gz
set -euo pipefail
OUT=/root/satin-phone-backup-$(date +%Y%m%d-%H%M).tar.gz
sqlite_copy=/tmp/satin-phone-db-copy.db
node -e "const {DatabaseSync}=require('node:sqlite');const d=new DatabaseSync('/var/lib/satin-phone/satin-phone.db');d.exec(\"VACUUM INTO '$sqlite_copy'\")" 2>/dev/null || cp /var/lib/satin-phone/satin-phone.db "$sqlite_copy"
tar czf "$OUT" /etc/satin-phone /etc/asterisk/satin /var/lib/asterisk/sounds/satin /var/spool/asterisk/satin "$sqlite_copy" 2>/dev/null
rm -f "$sqlite_copy"
echo "Backup saved: $OUT  ($(du -h "$OUT" | cut -f1))"
