#!/usr/bin/env bash
# =============================================================================
#  Satin Phone — one-command installer for a fresh Ubuntu 24.04 server (VPS)
#
#  What it sets up:
#    • Asterisk 22 (phone server, built from source — the version tested)
#    • The Satin Phone app (Node.js) + its web app
#    • nginx + free HTTPS certificate (Let's Encrypt)
#    • Firewall, fail2ban, automatic security updates, time zone
#
#  Usage (as root, from inside the satin-phone folder):
#      sudo bash install.sh
#  You can pre-answer the questions with environment variables, e.g.
#      DOMAIN=phone.satingraphic.ca LE_EMAIL=you@example.com \
#      ADMIN_NAME=Mehrad ADMIN_USER=mehrad ADMIN_PASS='...' sudo -E bash install.sh
#  Re-running is safe: existing settings and data are kept.
# =============================================================================
set -euo pipefail

ASTERISK_VERSION="${ASTERISK_VERSION:-22.9.0}"
NODE_MAJOR="${NODE_MAJOR:-22}"
APP_DIR=/opt/satin-phone
ENV_DIR=/etc/satin-phone
ENV_FILE=$ENV_DIR/satin.env
DATA_DIR=/var/lib/satin-phone
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG=/var/log/satin-phone-install.log

bold() { printf '\n\033[1m%s\033[0m\n' "$*"; }
ok()   { printf '  \033[32m✓\033[0m %s\n' "$*"; }
warn() { printf '  \033[33m!\033[0m %s\n' "$*"; }
die()  { printf '\n\033[31mERROR:\033[0m %s\n(see %s)\n' "$*" "$LOG"; exit 1; }
ask()  { # ask VAR "Question" [default] [secret]
  local var=$1 q=$2 def=${3:-} secret=${4:-} val
  if [ -n "${!var:-}" ]; then return; fi
  if [ -n "$secret" ]; then read -r -s -p "  $q: " val; echo; else read -r -p "  $q${def:+ [$def]}: " val; fi
  printf -v "$var" '%s' "${val:-$def}"
}
rand() { head -c 48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c "${1:-32}"; }
get_env() { grep -E "^$1=" "$ENV_FILE" 2>/dev/null | head -1 | cut -d= -f2- || true; }
set_env() { # set_env KEY VALUE  (safe for any characters in VALUE)
  python3 - "$ENV_FILE" "$1" "$2" <<'PY'
import sys, re
path, key, val = sys.argv[1:4]
lines = open(path).read().splitlines()
out, done = [], False
for l in lines:
    if l.startswith(key + "="):
        out.append(f"{key}={val}"); done = True
    else:
        out.append(l)
if not done: out.append(f"{key}={val}")
open(path, "w").write("\n".join(out) + "\n")
PY
}

[ "$(id -u)" = 0 ] || die "Run this as root:  sudo bash install.sh"
. /etc/os-release
[ "${ID:-}" = ubuntu ] || warn "This was tested on Ubuntu 24.04 — you have ${PRETTY_NAME:-unknown}."
: > "$LOG"

bold "Satin Phone installer"
echo "  This takes about 20–40 minutes (most of it is building Asterisk)."

# ----------------------------------------------------------------- questions
EXISTING=0
if [ -f "$ENV_FILE" ]; then
  EXISTING=1
  DOMAIN="${DOMAIN:-$(get_env SIP_DOMAIN)}"
  VOIPMS_USERNAME="${VOIPMS_USERNAME:-$(get_env VOIPMS_USERNAME)}"
  [ -n "$VOIPMS_USERNAME" ] && VOIPMS_PASSWORD="${VOIPMS_PASSWORD:-$(get_env VOIPMS_PASSWORD)}" && VOIPMS_SERVER="${VOIPMS_SERVER:-$(get_env VOIPMS_SERVER)}"
  MAIN_NUMBER="${MAIN_NUMBER:-$(get_env MAIN_NUMBER)}"
fi
bold "1/9  A few questions"
ask DOMAIN   "Web address for the phone app (e.g. phone.satingraphic.ca)"
ask LE_EMAIL "Email for the HTTPS certificate notices"
if [ "$EXISTING" = 0 ]; then
  ask ADMIN_NAME "Your name (first admin)" "Mehrad"
  ask ADMIN_USER "Username to sign in" "mehrad"
  ask ADMIN_PASS "Password (8+ characters)" "" secret
  [ ${#ADMIN_PASS} -ge 8 ] || die "The password must be at least 8 characters."
fi
ask VOIPMS_USERNAME "VoIP.ms SIP sub-account username, e.g. 123456_satin (Enter to add later)" ""
if [ -n "$VOIPMS_USERNAME" ]; then
  ask VOIPMS_PASSWORD "VoIP.ms sub-account password" "" secret
  ask VOIPMS_SERVER "VoIP.ms server" "toronto1.voip.ms"
fi
ask MAIN_NUMBER "Main phone number" "9059626222"

PUBLIC_IP=$(curl -4 -fsS --max-time 10 https://api.ipify.org || true)
DNS_IP=$(getent ahostsv4 "$DOMAIN" | awk 'NR==1{print $1}' || true)
if [ -n "$PUBLIC_IP" ] && [ "$DNS_IP" != "$PUBLIC_IP" ]; then
  warn "$DOMAIN points to '${DNS_IP:-nothing}', but this server is $PUBLIC_IP."
  warn "Add an A record:  ${DOMAIN%%.*}  →  $PUBLIC_IP  (in your domain's DNS), wait a few minutes, then run this again."
  read -r -p "  Continue anyway (HTTPS will fail until DNS is right)? [y/N] " yn
  [ "${yn:-n}" = y ] || exit 1
fi

# ----------------------------------------------------------------- base system
bold "2/9  Updating Ubuntu and installing tools"
export DEBIAN_FRONTEND=noninteractive
timedatectl set-timezone America/Toronto >>"$LOG" 2>&1 || true
apt-get update >>"$LOG" 2>&1
apt-get -y upgrade >>"$LOG" 2>&1
apt-get -y install build-essential git curl wget ca-certificates xz-utils bzip2 patch pkg-config \
  libedit-dev libjansson-dev libxml2-dev uuid-dev libsqlite3-dev libssl-dev libsrtp2-dev libcurl4-openssl-dev \
  ffmpeg nginx certbot python3-certbot-nginx ufw fail2ban unattended-upgrades logrotate >>"$LOG" 2>&1 || die "apt install failed"
dpkg-reconfigure -f noninteractive unattended-upgrades >>"$LOG" 2>&1 || true
ok "System packages installed"

# A little swap makes building Asterisk safe on 1–2 GB servers
if ! swapon --show | grep -q . && [ "$(awk '/MemTotal/{print $2}' /proc/meminfo)" -lt 3500000 ]; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile >>"$LOG" && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  ok "Added 2 GB swap"
fi

# ----------------------------------------------------------------- Asterisk
bold "3/9  Asterisk $ASTERISK_VERSION (phone server)"
id asterisk >/dev/null 2>&1 || useradd -r -d /var/lib/asterisk -s /usr/sbin/nologin -c "Asterisk PBX" asterisk
if /usr/sbin/asterisk -V 2>/dev/null | grep -q "$ASTERISK_VERSION"; then
  ok "Already installed"
else
  cd /usr/src
  if [ ! -d "asterisk-$ASTERISK_VERSION" ]; then
    wget -q "https://downloads.asterisk.org/pub/telephony/asterisk/releases/asterisk-$ASTERISK_VERSION.tar.gz" -O ast.tgz \
      || wget -q "https://github.com/asterisk/asterisk/releases/download/$ASTERISK_VERSION/asterisk-$ASTERISK_VERSION.tar.gz" -O ast.tgz \
      || die "Couldn't download Asterisk $ASTERISK_VERSION"
    tar xzf ast.tgz && rm ast.tgz
  fi
  cd "asterisk-$ASTERISK_VERSION"
  echo "  Building (this is the long part)…"
  ./configure --with-pjproject-bundled >>"$LOG" 2>&1 || die "Asterisk configure failed"
  make menuselect.makeopts >>"$LOG" 2>&1
  menuselect/menuselect --disable BUILD_NATIVE \
    --enable CORE-SOUNDS-EN-WAV --disable CORE-SOUNDS-EN-GSM --enable MOH-OPSOUND-WAV \
    --enable res_srtp --enable chan_pjsip --enable res_http_websocket --enable res_pjsip_transport_websocket \
    --enable app_mixmonitor --enable app_record --enable func_db --enable codec_ulaw --enable codec_alaw --enable codec_g722 \
    --enable format_wav menuselect.makeopts >>"$LOG" 2>&1
  make -j"$(nproc)" >>"$LOG" 2>&1 || die "Asterisk build failed"
  make install >>"$LOG" 2>&1 || die "Asterisk install failed"
  ok "Asterisk $ASTERISK_VERSION installed"
fi

mkdir -p /etc/asterisk/satin /etc/asterisk/keys /var/lib/asterisk/sounds/satin /var/lib/asterisk/moh \
  /var/spool/asterisk/satin/recordings /var/spool/asterisk/satin/voicemail /var/log/asterisk
for f in "$SRC_DIR"/asterisk/etc/*.conf; do install -m 644 "$f" /etc/asterisk/; done
if [ ! -f /etc/asterisk/satin/manager_satin.conf ]; then
  AMI_SECRET=${AMI_SECRET:-$(rand 32)}
  cat > /etc/asterisk/satin/manager_satin.conf <<EOF
[satin]
secret = $AMI_SECRET
deny = 0.0.0.0/0.0.0.0
permit = 127.0.0.1/255.255.255.255
read = system,call,agent,user,config,dtmf,reporting,cdr,dialplan,originate
write = system,call,agent,user,config,command,reporting,originate
writetimeout = 5000
EOF
else
  AMI_SECRET=$(awk -F' = ' '/^secret/{print $2}' /etc/asterisk/satin/manager_satin.conf)
fi
chown -R asterisk:asterisk /etc/asterisk /var/lib/asterisk /var/spool/asterisk /var/log/asterisk
chmod 750 /etc/asterisk/satin

cat > /etc/systemd/system/asterisk.service <<'EOF'
[Unit]
Description=Asterisk phone server (Satin Phone)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=asterisk
Group=asterisk
ExecStart=/usr/sbin/asterisk -f -q
ExecReload=/usr/sbin/asterisk -rx "core reload"
ExecStop=/usr/sbin/asterisk -rx "core stop gracefully"
RuntimeDirectory=asterisk
RuntimeDirectoryMode=0755
Restart=always
RestartSec=3
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF
cat > /etc/logrotate.d/asterisk <<'EOF'
/var/log/asterisk/messages.log /var/log/asterisk/full.log /var/log/asterisk/security.log {
  weekly
  rotate 8
  missingok
  compress
  delaycompress
  notifempty
  sharedscripts
  postrotate
    /usr/sbin/asterisk -rx 'logger reload' >/dev/null 2>&1 || true
  endscript
}
EOF
ok "Asterisk configured"

# ----------------------------------------------------------------- Node.js
bold "4/9  Node.js $NODE_MAJOR"
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt "$NODE_MAJOR" ]; then
  NODE_FILE=$(curl -fsS "https://nodejs.org/dist/latest-v$NODE_MAJOR.x/SHASUMS256.txt" | awk '/linux-x64.tar.xz$/{print $2}')
  curl -fsS "https://nodejs.org/dist/latest-v$NODE_MAJOR.x/$NODE_FILE" -o /tmp/node.tar.xz || die "Couldn't download Node.js"
  tar -xJf /tmp/node.tar.xz -C /usr/local --strip-components=1 && rm /tmp/node.tar.xz
fi
ok "Node $(node -v)"

# ----------------------------------------------------------------- the app
bold "5/9  Satin Phone app"
mkdir -p "$APP_DIR" "$ENV_DIR" "$DATA_DIR"
rm -rf "$APP_DIR/server.new"
cp -r "$SRC_DIR/server" "$APP_DIR/server.new"
rm -rf "$APP_DIR/server.new/data" "$APP_DIR/server.new/.env"
rm -rf "$APP_DIR/server" && mv "$APP_DIR/server.new" "$APP_DIR/server"
cp -r "$SRC_DIR/asterisk" "$SRC_DIR/scripts" "$APP_DIR/" 2>/dev/null || true
chown -R root:root "$APP_DIR"

if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
# Satin Phone settings. After editing:  sudo systemctl restart satin-phone
PUBLIC_URL=https://$DOMAIN
SIP_DOMAIN=$DOMAIN
SIP_WS_URL=wss://$DOMAIN/sip
COMPANY_NAME=Satin Auto Wrap
MAIN_NUMBER=$MAIN_NUMBER
TIMEZONE=America/Toronto

# VoIP.ms (SIP sub-account). Leave empty until you have it.
VOIPMS_SERVER=${VOIPMS_SERVER:-toronto1.voip.ms}
VOIPMS_USERNAME=${VOIPMS_USERNAME:-}
VOIPMS_PASSWORD=${VOIPMS_PASSWORD:-}

# Email for voicemail (e.g. your HostPapa mailbox: mail.satingraphic.ca, port 587)
SMTP_HOST=
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=
SMTP_PASS=
SMTP_FROM=Satin Phone <phone@${DOMAIN#*.}>

# Optional: voicemail transcripts (English & Farsi) via OpenAI
OPENAI_API_KEY=

# Internal — generated, keep secret
AMI_USERNAME=satin
AMI_SECRET=$AMI_SECRET
SESSION_SECRET=$(rand 40)
API_KEY=$(rand 40)
DATA_DIR=$DATA_DIR
PORT=3000
HOST=127.0.0.1
EOF
else
  # keep existing values; fill in VoIP.ms details if they were given now
  if [ -n "${VOIPMS_USERNAME:-}" ]; then
    set_env VOIPMS_USERNAME "$VOIPMS_USERNAME"
    set_env VOIPMS_PASSWORD "${VOIPMS_PASSWORD:-}"
    set_env VOIPMS_SERVER "${VOIPMS_SERVER:-toronto1.voip.ms}"
  fi
fi
chown root:asterisk "$ENV_FILE" && chmod 640 "$ENV_FILE"
chown -R asterisk:asterisk "$DATA_DIR"

cat > /etc/systemd/system/satin-phone.service <<EOF
[Unit]
Description=Satin Phone app
After=network-online.target asterisk.service
Wants=asterisk.service

[Service]
Type=simple
User=asterisk
Group=asterisk
Environment=SATIN_ENV_FILE=$ENV_FILE
Environment=NODE_ENV=production
WorkingDirectory=$APP_DIR/server
ExecStart=/usr/local/bin/node --disable-warning=ExperimentalWarning $APP_DIR/server/src/index.js
Restart=always
RestartSec=3
NoNewPrivileges=true
ProtectSystem=full
ReadWritePaths=/etc/asterisk/satin /var/lib/asterisk/sounds/satin /var/spool/asterisk/satin $DATA_DIR
ProtectHome=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

if [ "$EXISTING" = 0 ]; then
  sudo -u asterisk SATIN_ENV_FILE="$ENV_FILE" /usr/local/bin/node --disable-warning=ExperimentalWarning \
    "$APP_DIR/server/src/cli.js" create-user --admin --name "$ADMIN_NAME" --username "$ADMIN_USER" --password "$ADMIN_PASS" \
    || warn "Admin account not created (maybe it exists already)"
fi
sudo -u asterisk SATIN_ENV_FILE="$ENV_FILE" /usr/local/bin/node --disable-warning=ExperimentalWarning "$APP_DIR/server/src/cli.js" write-config >>"$LOG" 2>&1 || true
systemctl daemon-reload
systemctl enable --now asterisk >>"$LOG" 2>&1
sleep 4
systemctl enable satin-phone >>"$LOG" 2>&1
systemctl restart satin-phone
ok "App installed and running"

# ----------------------------------------------------------------- nginx + HTTPS
bold "6/9  Web server and HTTPS for $DOMAIN"
sed "s/__DOMAIN__/$DOMAIN/g" "$SRC_DIR/scripts/nginx-satin-phone.conf" > /etc/nginx/sites-available/satin-phone
ln -sf /etc/nginx/sites-available/satin-phone /etc/nginx/sites-enabled/satin-phone
rm -f /etc/nginx/sites-enabled/default
nginx -t >>"$LOG" 2>&1 && systemctl reload nginx

install -m 755 "$SRC_DIR/scripts/certbot-deploy-hook.sh" /etc/letsencrypt/renewal-hooks/deploy/satin-asterisk.sh 2>/dev/null || {
  mkdir -p /etc/letsencrypt/renewal-hooks/deploy
  install -m 755 "$SRC_DIR/scripts/certbot-deploy-hook.sh" /etc/letsencrypt/renewal-hooks/deploy/satin-asterisk.sh
}
if certbot --nginx -d "$DOMAIN" -m "$LE_EMAIL" --agree-tos -n --redirect >>"$LOG" 2>&1; then
  RENEWED_LINEAGE=/etc/letsencrypt/live/$DOMAIN /etc/letsencrypt/renewal-hooks/deploy/satin-asterisk.sh
  ok "HTTPS certificate installed (renews automatically)"
else
  warn "Couldn't get the HTTPS certificate yet (check DNS). Run later:  sudo certbot --nginx -d $DOMAIN"
fi

# ----------------------------------------------------------------- firewall
bold "7/9  Firewall"
bash "$SRC_DIR/scripts/firewall.sh" >>"$LOG" 2>&1 && ok "Firewall on (web, secure phones, VoIP.ms only for plain SIP)" || warn "Firewall step had a problem (see log)"

# ----------------------------------------------------------------- fail2ban
bold "8/9  Break-in protection (fail2ban)"
cat > /etc/fail2ban/jail.d/satin-phone.conf <<'EOF'
[sshd]
enabled = true
maxretry = 5
bantime = 1h

[asterisk]
enabled  = true
filter   = asterisk
port     = 5060,5061
protocol = all
logpath  = /var/log/asterisk/messages.log
maxretry = 5
findtime = 10m
bantime  = 24h
EOF
systemctl enable --now fail2ban >>"$LOG" 2>&1 && systemctl restart fail2ban
ok "fail2ban watching SSH and SIP"

# ----------------------------------------------------------------- done
bold "9/9  Checking"
sleep 3
systemctl is-active --quiet asterisk && ok "Asterisk running" || warn "Asterisk isn't running: journalctl -u asterisk"
systemctl is-active --quiet satin-phone && ok "Satin Phone running" || warn "App isn't running: journalctl -u satin-phone"
REG=$(/usr/sbin/asterisk -rx "pjsip show registrations" 2>/dev/null | grep voipms || true)
if [ -n "$REG" ]; then echo "  VoIP.ms line: $(echo "$REG" | awk '{print $(NF-2)}')"; else warn "VoIP.ms line not set up yet — add it later (see the guide)"; fi

bold "Done!"
echo "  Open:   https://$DOMAIN"
[ "$EXISTING" = 0 ] && echo "  Sign in as:  $ADMIN_USER"
echo "  Settings file:  $ENV_FILE   (then: sudo systemctl restart satin-phone)"
echo "  Logs:   journalctl -u satin-phone -f      sudo asterisk -rvvv"
