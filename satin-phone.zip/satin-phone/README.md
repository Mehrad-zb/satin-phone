# Satin Phone

A custom business phone system for **Satin Auto Wrap** — the shop line **(905) 962-6222** rings in a web app on computers and phones, with a bilingual (English/Farsi) menu, business hours, voicemail with email and transcripts, call recording, and an API for the website admin panel.

```
 Customer ──► VoIP.ms (carrier, holds the number) ──SIP──► Asterisk 22 on your VPS ◄── AMI (localhost) ──► Satin Phone app (Node.js)
                                                             │  WebRTC (wss://…/sip)                           │  REST + live WebSocket
                                                             ├──────────────► Browser app (computer / phone)  ◄┘
                                                             └──────────────► Groundwire (iPhone/Android, rings when locked)
```

- **Asterisk** does the telephony. Its call flow is *generated* from the app's settings, so calls keep working even if the app restarts.
- **The app** (no npm dependencies; Node 22 built-ins only) keeps call history, voicemail, customers, team and settings in SQLite, and serves the web app.
- **The web app** (React + SIP.js, prebuilt in `server/public`) is the softphone: answer, call, mute, hold, keypad, transfer.

## Features

- Main line rings every online device at once (browser tabs, Groundwire, desk phones); per-device ring on/off; personal *Do not disturb*.
- Greeting + language menu (1 English, 2 فارسی), business hours per day, Ontario statutory holidays, extra closed days, *Force open/closed*.
- After-hours message → voicemail. No answer → voicemail. Voicemail saved in the app, emailed (MP3 attached), optional transcript (OpenAI, English & Farsi).
- Call recording (answered part only) with optional recording notice in each language; access limited to admins by default; automatic retention cleanup.
- Greetings recorded straight in the browser or uploaded (any audio format; converted and levelled with ffmpeg).
- Caller ID names from saved customers (pushed into Asterisk), shown on every device.
- Outgoing calls show (905) 962-6222; premium (900/976) and Caribbean/international numbers blocked unless allowed; 911 routed to VoIP.ms (E911 address).
- Team accounts (admin / team member), extensions (101, 102, …) for internal calls and transfers, "Place a test call" button.
- Live updates (WebSocket), installable as a phone home-screen app (PWA).

## Install (Ubuntu 24.04 VPS)

1. Point a DNS **A record** (e.g. `phone.satingraphic.ca`) at the VPS IP.
2. Copy this folder to the server and run:
   ```bash
   sudo bash install.sh
   ```
   It builds Asterisk 22.9.0 (tested version), installs Node 22, nginx, a Let's Encrypt certificate, ufw firewall, fail2ban and automatic security updates, creates the first admin, and starts everything. Re-running is safe.
3. Settings live in `/etc/satin-phone/satin.env` (VoIP.ms account, SMTP, OpenAI key, generated secrets). After editing: `sudo systemctl restart satin-phone`. If you change `VOIPMS_SERVER`, also run `sudo bash /opt/satin-phone/scripts/firewall.sh`.

The Farsi step-by-step guide (VoIP.ms, test number, porting the number, Groundwire, email): [`docs/راهنمای-راه‌اندازی.md`](docs/راهنمای-راه‌اندازی.md).

### VoIP.ms settings

Create a **SIP sub-account** (e.g. `123456_satin`), set its Caller ID to the main number, route your DID(s) to it, register the **E911 address**, and put the sub-account and server (e.g. `toronto1.voip.ms`) in `satin.env`. The trunk registers to VoIP.ms; plain SIP (UDP 5060) is only accepted from that server.

### Phones that ring while locked

Add a device under **Team & devices → Add a phone**, then enter the shown username/password/domain in **Groundwire** (SIP over TLS, port 5061, SRTP optional, push notifications on).

## Operations

| Task | Command |
|---|---|
| App logs | `journalctl -u satin-phone -f` |
| Asterisk console | `sudo asterisk -rvvv` |
| VoIP.ms line status | `sudo asterisk -rx "pjsip show registrations"` |
| Who's online | `sudo asterisk -rx "pjsip show contacts"` |
| Create / reset a user | `sudo -u asterisk SATIN_ENV_FILE=/etc/satin-phone/satin.env node /opt/satin-phone/server/src/cli.js create-user` (or `reset-password`) |
| Backup | `sudo bash /opt/satin-phone/scripts/backup.sh` |
| Update to a new version | `cd satin-phone && sudo bash scripts/update.sh` |

Data: `/var/lib/satin-phone/satin-phone.db` (SQLite), recordings & voicemail in `/var/spool/asterisk/satin/`, greetings in `/var/lib/asterisk/sounds/satin/`, generated Asterisk config in `/etc/asterisk/satin/` (don't edit by hand).

## Website admin panel integration

Authenticate with `Authorization: Bearer <API_KEY>` (from `satin.env`, also shown in **Settings → System**).

| Endpoint | Purpose |
|---|---|
| `POST /api/integrations/contacts/sync` `{contacts:[{external_id,name,phone,company,notes}], replace?:bool}` | Sync customers → caller ID names |
| `POST /api/integrations/originate` `{username or ext, number}` | Click-to-call: rings the team member's devices, then dials the customer |
| `GET /api/integrations/calls?since=<ms>` | Call history since a timestamp |
| `GET /api/calls`, `GET /api/voicemails`, `GET /api/stats` | Same data the app uses |

**Webhooks** (add in **Settings → System**): `POST` JSON `{event, at, data}` for `call.started`, `call.ended`, `voicemail.created`, with header `X-Satin-Signature: sha256=<HMAC-SHA256(body, secret)>`. Retries 3 times.

```php
// PHP example (admin panel) — verify a webhook
$body = file_get_contents('php://input');
$ok = hash_equals('sha256=' . hash_hmac('sha256', $body, $SECRET), $_SERVER['HTTP_X_SATIN_SIGNATURE'] ?? '');
```

## Security notes

- Asterisk HTTP/WebSocket and AMI listen on localhost only; nginx terminates TLS.
- Unknown SIP requests are rejected; fail2ban bans repeated SIP/SSH failures; UDP 5060 is limited to VoIP.ms.
- Toll-fraud limits: premium/Caribbean/international blocked by default, max 6 simultaneous outgoing calls. Also set a low balance alert and IP restriction in the VoIP.ms portal.
- Team logins: scrypt password hashes, HttpOnly session cookies, login rate limiting, CSRF header check.
- Canadian privacy: keep the recording notice on if you record calls.

## Development

```
server/   Node.js backend (src/), tests (npm test), prebuilt web app (public/)
web/      React + SIP.js source → npm install && npm run build  (outputs to ../server/public)
asterisk/ static Asterisk config (the dynamic part is generated by the backend)
scripts/  nginx site, firewall, certbot hook, backup, update
```

Run locally against a dev Asterisk: copy `server/.env.example` to `server/.env`, then `cd server && npm start`.

The system was tested end to end with Asterisk 22.9.0 and a simulated VoIP.ms carrier: trunk registration with auth, inbound calls (menu, DTMF 1/2, hours, holidays), ring-all to browsers, two-way WebRTC audio, hold/mute/DTMF, blind transfer, click-to-call, do-not-disturb, voicemail + email + signed webhooks, recordings, greeting upload.
